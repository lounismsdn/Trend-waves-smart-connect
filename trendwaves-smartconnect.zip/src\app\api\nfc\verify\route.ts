import { NextRequest } from "next/server";
import { fail, guardRateLimit, handleApiError, ok } from "@/lib/api";
import { getAuthUser } from "@/lib/auth";
import { verifyNfcPayload } from "@/services/nfc";
import { nfcVerifySchema } from "@/lib/validation";

export const runtime = "nodejs";

export async function POST(request: NextRequest) {
  const limited = guardRateLimit(request, "nfc:verify", 160);
  if (limited) return limited;

  try {
    const user = await getAuthUser(request);
    if (!user) return fail("Unauthorized", 401);

    const input = nfcVerifySchema.parse(await request.json());
    const verification = await verifyNfcPayload({
      user,
      selector: { tagId: input.tagId, chipUid: input.chipUid },
      payload: input.payload,
    });

    return ok(verification);
  } catch (error) {
    return handleApiError(error);
  }
}
