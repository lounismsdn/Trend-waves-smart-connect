import { AppShell } from "@/components/smartconnect/app-shell";
import { QRCustomizerView } from "@/components/smartconnect/views";
import { requirePageAuth } from "@/lib/server-auth";

export default async function QRCustomizerPage() {
  await requirePageAuth("/qr-customizer");

  return (
    <AppShell>
      <QRCustomizerView />
    </AppShell>
  );
}
