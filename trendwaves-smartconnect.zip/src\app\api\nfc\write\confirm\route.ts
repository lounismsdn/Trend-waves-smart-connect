import { NextRequest } from "next/server";
import { fail, guardRateLimit, handleApiError, ok } from "@/lib/api";
import { getAuthUser } from "@/lib/auth";
import { confirmNfcWrite } from "@/services/nfc";
import { nfcWriteConfirmSchema } from "@/lib/validation";

export const runtime = "nodejs";

export async function POST(request: NextRequest) {
  const limited = guardRateLimit(request, "nfc:write:confirm", 120);
  if (limited) return limited;

  try {
    const user = await getAuthUser(request);
    if (!user) return fail("Unauthorized", 401);

    const input = nfcWriteConfirmSchema.parse(await request.json());
    const result = await confirmNfcWrite({
      user,
      writeLogId: input.writeLogId,
      success: input.success,
      payload: input.payload,
      errorMessage: input.errorMessage,
    });

    return ok(result);
  } catch (error) {
    return handleApiError(error);
  }
}
