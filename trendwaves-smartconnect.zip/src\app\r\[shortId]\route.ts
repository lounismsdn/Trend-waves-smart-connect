import { randomUUID } from "crypto";
import { NextRequest, NextResponse } from "next/server";
import { fail, guardRateLimit } from "@/lib/api";
import { verifyRedirectSignature } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { extractScanMetadata } from "@/lib/request-meta";

export const runtime = "nodejs";

type RouteContext = { params: Promise<{ shortId: string }> };

export async function GET(request: NextRequest, context: RouteContext) {
  const limited = guardRateLimit(request, "redirect", 360);
  if (limited) return limited;

  const { shortId } = await context.params;

  if (process.env.REQUIRE_SIGNED_REDIRECTS === "true") {
    const signature = request.nextUrl.searchParams.get("s");
    const validSignature = await verifyRedirectSignature(shortId, signature);
    if (!validSignature) {
      return fail("Invalid redirect signature", 403);
    }
  }

  const qrCode = await prisma.qrCode.findUnique({ where: { shortId } });
  const nfcTag = qrCode ? null : await prisma.nfcTag.findUnique({ where: { shortId } });
  const asset = qrCode ?? nfcTag;

  if (!asset || asset.status !== "ACTIVE") {
    return fail("Destination unavailable", 404);
  }

  const metadata = extractScanMetadata(request);
  const visitorId = request.cookies.get("tw_visitor")?.value ?? randomUUID();
  const destinationUrl = asset.destinationUrl;
  const isQr = Boolean(qrCode);

  const existingVisitor = await prisma.scanEvent.findFirst({
    where: isQr
      ? { visitorId, qrCodeId: asset.id }
      : { visitorId, nfcTagId: asset.id },
    select: { id: true },
  });

  await prisma.$transaction([
    prisma.scanEvent.create({
      data: {
        kind: isQr ? "QR" : "NFC",
        shortId,
        visitorId,
        ipHash: metadata.ipHash,
        userAgent: metadata.userAgent,
        referrer: metadata.referrer,
        deviceType: metadata.deviceType,
        browser: metadata.browser,
        country: metadata.country,
        city: metadata.city,
        clientId: asset.clientId,
        campaignId: asset.campaignId,
        qrCodeId: isQr ? asset.id : undefined,
        nfcTagId: isQr ? undefined : asset.id,
      },
    }),
    isQr
      ? prisma.qrCode.update({
          where: { id: asset.id },
          data: {
            scanCount: { increment: 1 },
            uniqueVisitors: existingVisitor ? undefined : { increment: 1 },
            lastScanAt: new Date(),
          },
        })
      : prisma.nfcTag.update({
          where: { id: asset.id },
          data: {
            tapCount: { increment: 1 },
            uniqueVisitors: existingVisitor ? undefined : { increment: 1 },
            lastTapAt: new Date(),
          },
        }),
  ]);

  const response = NextResponse.redirect(destinationUrl, 307);
  response.cookies.set("tw_visitor", visitorId, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    maxAge: 60 * 60 * 24 * 365,
  });

  return response;
}
