import PDFDocument from "pdfkit";
import QRCode from "qrcode";
import { nanoid } from "nanoid";

export function createShortId() {
  return nanoid(8);
}

export async function createQrSvg(url: string, dark = "#101318", light = "#ffffff") {
  return QRCode.toString(url, {
    type: "svg",
    color: { dark, light },
    margin: 2,
    width: 900,
  });
}

export async function createQrPngBuffer(url: string, dark = "#101318", light = "#ffffff") {
  return QRCode.toBuffer(url, {
    type: "png",
    color: { dark, light },
    margin: 2,
    width: 1000,
  });
}

export async function createQrPdfBuffer(url: string, title = "Trend waves SmartConnect QR") {
  const qrBuffer = await createQrPngBuffer(url);

  return new Promise<Buffer>((resolve) => {
    const doc = new PDFDocument({ size: "A4", margin: 56 });
    const chunks: Buffer[] = [];

    doc.on("data", (chunk: Buffer) => chunks.push(chunk));
    doc.on("end", () => resolve(Buffer.concat(chunks)));

    doc.fontSize(22).text(title, { align: "center" });
    doc.moveDown();
    doc.fontSize(10).fillColor("#64748b").text(url, { align: "center" });
    doc.image(qrBuffer, 175, 180, { width: 245 });
    doc.end();
  });
}
