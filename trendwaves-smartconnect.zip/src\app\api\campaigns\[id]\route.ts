import { NextRequest } from "next/server";
import { Prisma } from "@prisma/client";
import { fail, guardRateLimit, handleApiError, ok } from "@/lib/api";
import { getAuthUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { campaignUpdateSchema } from "@/lib/validation";

export const runtime = "nodejs";

type RouteContext = { params: Promise<{ id: string }> };

export async function GET(request: NextRequest, context: RouteContext) {
  const limited = guardRateLimit(request, "campaigns:get", 240);
  if (limited) return limited;

  try {
    const user = await getAuthUser(request);
    if (!user) return fail("Unauthorized", 401);

    const { id } = await context.params;
    const campaign = await prisma.campaign.findUnique({
      where: { id },
      include: { client: true, qrCodes: true, nfcTags: true },
    });

    if (!campaign) return fail("Campaign not found", 404);
    return ok(campaign);
  } catch (error) {
    return handleApiError(error);
  }
}

export async function PUT(request: NextRequest, context: RouteContext) {
  const limited = guardRateLimit(request, "campaigns:update", 120);
  if (limited) return limited;

  try {
    const user = await getAuthUser(request);
    if (!user) return fail("Unauthorized", 401);

    const { id } = await context.params;
    const input = campaignUpdateSchema.parse(await request.json());
    const campaign = await prisma.campaign.update({
      where: { id },
      data: {
        ...input,
        startAt: input.startAt ? new Date(input.startAt) : undefined,
        endAt: input.endAt ? new Date(input.endAt) : undefined,
      },
    });

    await prisma.auditLog.create({
      data: {
        actorId: user.sub,
        action: "CAMPAIGN_UPDATED",
        entity: "Campaign",
        entityId: id,
        metadata: input as Prisma.InputJsonValue,
      },
    });

    return ok(campaign);
  } catch (error) {
    return handleApiError(error);
  }
}

export async function DELETE(request: NextRequest, context: RouteContext) {
  const limited = guardRateLimit(request, "campaigns:delete", 60);
  if (limited) return limited;

  try {
    const user = await getAuthUser(request);
    if (!user) return fail("Unauthorized", 401);

    const { id } = await context.params;
    await prisma.campaign.delete({ where: { id } });

    await prisma.auditLog.create({
      data: {
        actorId: user.sub,
        action: "CAMPAIGN_DELETED",
        entity: "Campaign",
        entityId: id,
      },
    });

    return ok({ deleted: true });
  } catch (error) {
    return handleApiError(error);
  }
}
