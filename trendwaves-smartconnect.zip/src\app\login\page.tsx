import { AuthPanel } from "@/components/smartconnect/auth-panel";

export default function LoginPage() {
  return <AuthPanel mode="login" />;
}
