import { NextRequest } from "next/server";
import { Prisma } from "@prisma/client";
import { fail, guardRateLimit, handleApiError } from "@/lib/api";
import { getAuthUser, signRedirect } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { createStyledQrPdfBuffer, createStyledQrPngBuffer, createStyledQrSvg, validateQrStyleReliability } from "@/lib/qr-style";

export const runtime = "nodejs";

type RouteContext = { params: Promise<{ id: string }> };

export async function GET(request: NextRequest, context: RouteContext) {
  const limited = guardRateLimit(request, "qr:export", 80);
  if (limited) return limited;

  try {
    const user = await getAuthUser(request);
    if (!user) return fail("Unauthorized", 401);

    const { id } = await context.params;
    const qrCode = await prisma.qrCode.findUnique({ where: { id } });
    if (!qrCode) return fail("QR code not found", 404);

    const format = request.nextUrl.searchParams.get("format") ?? "png";
    const origin = process.env.APP_URL ?? new URL(request.url).origin;
    const signature = await signRedirect(qrCode.shortId);
    const redirectUrl = `${origin}/r/${qrCode.shortId}?s=${signature}`;
    const reliability = validateQrStyleReliability(qrCode.design as Record<string, unknown> | null);
    if (!reliability.valid) return fail("QR style is not export-safe", 422, reliability);

    if (format === "svg") {
      const svg = createStyledQrSvg(redirectUrl, qrCode.design as Record<string, unknown> | null);
      await prisma.exportJob.create({
        data: {
          type: "QR_ASSET",
          format: "svg",
          status: "COMPLETED",
          assetType: "QR",
          assetId: qrCode.id,
          qrCodeId: qrCode.id,
          clientId: qrCode.clientId,
          requesterId: user.sub,
          completedAt: new Date(),
          metadata: { reliability } as Prisma.InputJsonValue,
        },
      });
      return new Response(svg, {
        headers: {
          "content-type": "image/svg+xml",
          "content-disposition": `attachment; filename="${qrCode.shortId}.svg"`,
        },
      });
    }

    if (format === "pdf") {
      const pdf = await createStyledQrPdfBuffer(redirectUrl, qrCode.name, qrCode.design as Record<string, unknown> | null);
      await prisma.exportJob.create({
        data: {
          type: "QR_ASSET",
          format: "pdf",
          status: "COMPLETED",
          assetType: "QR",
          assetId: qrCode.id,
          qrCodeId: qrCode.id,
          clientId: qrCode.clientId,
          requesterId: user.sub,
          completedAt: new Date(),
          metadata: { reliability } as Prisma.InputJsonValue,
        },
      });
      return new Response(new Uint8Array(pdf), {
        headers: {
          "content-type": "application/pdf",
          "content-disposition": `attachment; filename="${qrCode.shortId}.pdf"`,
        },
      });
    }

    const png = await createStyledQrPngBuffer(redirectUrl, qrCode.design as Record<string, unknown> | null);
    await prisma.exportJob.create({
      data: {
        type: "QR_ASSET",
        format: "png",
        status: "COMPLETED",
        assetType: "QR",
        assetId: qrCode.id,
        qrCodeId: qrCode.id,
        clientId: qrCode.clientId,
        requesterId: user.sub,
        completedAt: new Date(),
        metadata: { reliability } as Prisma.InputJsonValue,
      },
    });
    return new Response(new Uint8Array(png), {
      headers: {
        "content-type": "image/png",
        "content-disposition": `attachment; filename="${qrCode.shortId}.png"`,
      },
    });
  } catch (error) {
    return handleApiError(error);
  }
}
