export { GET } from "@/app/api/qr/[id]/analytics/route";
