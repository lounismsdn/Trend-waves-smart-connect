import { NextRequest } from "next/server";
import { fail, guardRateLimit, handleApiError, ok } from "@/lib/api";
import { getAuthUser } from "@/lib/auth";
import { prepareNfcWrite } from "@/services/nfc";
import { nfcWriteSchema } from "@/lib/validation";

export const runtime = "nodejs";

export async function POST(request: NextRequest) {
  const limited = guardRateLimit(request, "nfc:write", 80);
  if (limited) return limited;

  try {
    const user = await getAuthUser(request);
    if (!user) return fail("Unauthorized", 401);

    const input = nfcWriteSchema.parse(await request.json());
    const prepared = await prepareNfcWrite({
      user,
      selector: { tagId: input.tagId, chipUid: input.chipUid },
      requestUrl: request.url,
      destinationUrl: input.destinationUrl,
      directWrite: input.directWrite,
      payload: input.payload,
    });

    return ok(prepared);
  } catch (error) {
    return handleApiError(error);
  }
}
