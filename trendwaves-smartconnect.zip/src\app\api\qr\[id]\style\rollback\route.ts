import { NextRequest } from "next/server";
import { Prisma } from "@prisma/client";
import { fail, guardRateLimit, handleApiError, ok } from "@/lib/api";
import { getAuthUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { checksumDesign } from "@/lib/qr-style";
import { qrRollbackSchema } from "@/lib/validation";

export const runtime = "nodejs";

type RouteContext = { params: Promise<{ id: string }> };

export async function POST(request: NextRequest, context: RouteContext) {
  const limited = guardRateLimit(request, "qr:style:rollback", 60);
  if (limited) return limited;

  try {
    const user = await getAuthUser(request);
    if (!user) return fail("Unauthorized", 401);

    const { id } = await context.params;
    const input = qrRollbackSchema.parse(await request.json());

    const updated = await prisma.$transaction(async (tx) => {
      const [current, version] = await Promise.all([
        tx.qrCode.findUnique({ where: { id } }),
        tx.qrDesignVersion.findUnique({ where: { qrCodeId_version: { qrCodeId: id, version: input.version } } }),
      ]);

      if (!current) throw new Error("QR code not found");
      if (!version) throw new Error("Design version not found");
      if (user.role === "CLIENT" && user.clientId && current.clientId !== user.clientId) throw new Error("Forbidden");

      const nextVersion = current.designVersion + 1;
      const qrCode = await tx.qrCode.update({
        where: { id },
        data: {
          design: version.design as Prisma.InputJsonValue,
          designVersion: nextVersion,
          designChecksum: checksumDesign(version.design),
        },
      });

      await tx.qrDesignVersion.create({
        data: {
          qrCodeId: id,
          version: nextVersion,
          design: version.design as Prisma.InputJsonValue,
          changes: { rollbackFrom: current.designVersion, rollbackTo: input.version } as Prisma.InputJsonValue,
          editorId: user.sub,
        },
      });

      return qrCode;
    });

    return ok(updated);
  } catch (error) {
    if (error instanceof Error && error.message === "Forbidden") return fail("Forbidden", 403);
    return handleApiError(error);
  }
}
