import { AppShell } from "@/components/smartconnect/app-shell";
import { ClientDashboardView } from "@/components/smartconnect/client-dashboard";
import { requirePageAuth } from "@/lib/server-auth";

export default async function ClientDashboardPage() {
  await requirePageAuth("/client");

  return (
    <AppShell>
      <ClientDashboardView />
    </AppShell>
  );
}
