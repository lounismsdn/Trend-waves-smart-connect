import { Prisma, type NFCTagType } from "@prisma/client";
import { fail } from "@/lib/api";
import { signRedirect } from "@/lib/auth";
import { buildNdefUrlRecord, detectNfcCapability, normalizeChipUid, payloadMatchesShortId } from "@/lib/nfc";
import { prisma } from "@/lib/prisma";
import { createShortId } from "@/lib/qr";

type AuthUser = {
  sub: string;
  role: "ADMIN" | "AGENCY" | "CLIENT";
  clientId?: string | null;
};

type TagSelector = {
  tagId?: string;
  chipUid?: string;
};

export async function createUniqueNfcShortId() {
  let shortId = createShortId();

  while (await prisma.nfcTag.findUnique({ where: { shortId } })) {
    shortId = createShortId();
  }

  return shortId;
}

export async function signedNfcRedirectUrl(shortId: string, requestUrl: string) {
  const origin = process.env.APP_URL ?? new URL(requestUrl).origin;
  const signature = await signRedirect(shortId);
  return `${origin}/r/${shortId}?s=${signature}`;
}

async function findAuthorizedTag(user: AuthUser, selector: TagSelector) {
  const where = selector.tagId
    ? { id: selector.tagId }
    : selector.chipUid
      ? { chipUid: normalizeChipUid(selector.chipUid) }
      : null;

  if (!where) throw new Error("tagId or chipUid is required");

  const tag = await prisma.nfcTag.findFirst({
    where: {
      ...where,
      ...(user.role === "CLIENT" && user.clientId ? { clientId: user.clientId } : {}),
    },
    include: { client: true, campaign: true },
  });

  if (!tag) throw new Error("NFC tag not found");
  return tag;
}

export async function registerNfcTag({
  user,
  input,
}: {
  user: AuthUser;
  input: {
    chipUid: string;
    name: string;
    destinationUrl: string;
    clientId?: string;
    campaignId?: string;
    tagType?: NFCTagType;
    memorySize?: number;
    isWritable?: boolean;
  };
}) {
  const tagType = input.tagType ?? "NTAG213";
  const capability = detectNfcCapability(tagType, input.memorySize);
  const chipUid = normalizeChipUid(input.chipUid);
  const shortId = await createUniqueNfcShortId();
  const isWritable = input.isWritable ?? capability.writable;

  const tag = await prisma.nfcTag.create({
    data: {
      shortId,
      chipUid,
      name: input.name,
      destinationUrl: input.destinationUrl,
      clientId: input.clientId ?? user.clientId ?? undefined,
      campaignId: input.campaignId,
      tagType,
      memorySize: capability.memorySize,
      isWritable,
      operationalStatus: isWritable ? "WRITABLE" : "REGISTERED",
    },
    include: { client: true, campaign: true },
  });

  await prisma.auditLog.create({
    data: {
      actorId: user.sub,
      action: "NFC_REGISTERED",
      entity: "NfcTag",
      entityId: tag.id,
      metadata: { chipUid, shortId, tagType, memorySize: capability.memorySize },
    },
  });

  return tag;
}

export async function prepareNfcWrite({
  user,
  selector,
  requestUrl,
  destinationUrl,
  directWrite,
  payload,
}: {
  user: AuthUser;
  selector: TagSelector;
  requestUrl: string;
  destinationUrl?: string;
  directWrite?: boolean;
  payload?: string;
}) {
  const tag = await findAuthorizedTag(user, selector);

  if (tag.isLocked || tag.operationalStatus === "LOCKED") throw new Error("NFC tag is locked");
  if (!tag.isWritable) throw new Error("NFC tag is not writable");

  const redirectPayload = payload ?? (directWrite && destinationUrl ? destinationUrl : await signedNfcRedirectUrl(tag.shortId, requestUrl));
  const record = buildNdefUrlRecord(redirectPayload);
  const capability = detectNfcCapability(tag.tagType, tag.memorySize);

  if (record.byteLength > capability.maxUrlBytes) {
    throw new Error(`NFC payload is too large for ${tag.tagType}`);
  }

  const writeLog = await prisma.nFCWriteLog.create({
    data: {
      tagId: tag.id,
      writerId: user.sub,
      payload: redirectPayload,
      previousPayload: tag.writtenPayload,
      status: "PENDING",
      metadata: {
        ndef: record,
        directWrite: Boolean(directWrite),
        requestedDestinationUrl: destinationUrl,
      } as Prisma.InputJsonValue,
    },
  });

  await prisma.nfcTag.update({
    where: { id: tag.id },
    data: {
      destinationUrl: destinationUrl ?? tag.destinationUrl,
      operationalStatus: "WRITABLE",
    },
  });

  return {
    tag,
    writeLog,
    payload: redirectPayload,
    ndefRecord: record,
    capability,
  };
}

export async function confirmNfcWrite({
  user,
  writeLogId,
  success,
  payload,
  errorMessage,
}: {
  user: AuthUser;
  writeLogId: string;
  success: boolean;
  payload?: string;
  errorMessage?: string;
}) {
  const writeLog = await prisma.nFCWriteLog.findUnique({
    where: { id: writeLogId },
    include: { tag: true },
  });

  if (!writeLog) throw new Error("NFC write log not found");
  if (user.role === "CLIENT" && user.clientId && writeLog.tag.clientId !== user.clientId) {
    throw new Error("Forbidden");
  }

  const verified = success && payloadMatchesShortId(payload ?? writeLog.payload, writeLog.tag.shortId);
  const nextStatus = success ? (verified ? "VERIFIED" : "WRITTEN") : "FAILED";

  const updated = await prisma.$transaction(async (tx) => {
    const log = await tx.nFCWriteLog.update({
      where: { id: writeLogId },
      data: {
        status: nextStatus,
        errorMessage,
        verificationResult: {
          verified,
          payload: payload ?? writeLog.payload,
          checkedAt: new Date().toISOString(),
        } as Prisma.InputJsonValue,
      },
    });

    const tag = await tx.nfcTag.update({
      where: { id: writeLog.tagId },
      data: {
        writtenPayload: success ? payload ?? writeLog.payload : writeLog.tag.writtenPayload,
        writeCount: success ? { increment: 1 } : undefined,
        lastWriteAt: success ? new Date() : undefined,
        operationalStatus: success ? (verified ? "VERIFIED" : "WRITTEN") : "ERROR",
      },
    });

    return { log, tag };
  });

  return updated;
}

export async function verifyNfcPayload({
  user,
  selector,
  payload,
}: {
  user: AuthUser;
  selector: TagSelector;
  payload: string;
}) {
  const tag = await findAuthorizedTag(user, selector);
  const payloadValid = payloadMatchesShortId(payload, tag.shortId);
  const databaseMatch = tag.writtenPayload ? tag.writtenPayload === payload : payloadValid;
  const verified = payloadValid && databaseMatch && tag.status === "ACTIVE";

  return {
    verified,
    tag,
    checks: {
      readable: true,
      payloadValid,
      redirectExists: Boolean(tag.shortId),
      databaseMatch,
      active: tag.status === "ACTIVE",
      locked: tag.isLocked,
    },
  };
}

export async function lockNfcTag({
  user,
  tagId,
}: {
  user: AuthUser;
  tagId: string;
}) {
  if (user.role !== "ADMIN") throw new Error("Admin role required to lock NFC tags");

  const tag = await prisma.nfcTag.update({
    where: { id: tagId },
    data: {
      isLocked: true,
      isWritable: false,
      operationalStatus: "LOCKED",
    },
  });

  await prisma.nFCWriteLog.create({
    data: {
      tagId,
      writerId: user.sub,
      payload: tag.writtenPayload ?? tag.destinationUrl,
      previousPayload: tag.writtenPayload,
      status: "LOCKED",
      verificationResult: { locked: true, lockedAt: new Date().toISOString() } as Prisma.InputJsonValue,
    },
  });

  await prisma.auditLog.create({
    data: {
      actorId: user.sub,
      action: "NFC_LOCKED",
      entity: "NfcTag",
      entityId: tagId,
    },
  });

  return tag;
}

export async function batchPrepareNfcWrites({
  user,
  requestUrl,
  input,
}: {
  user: AuthUser;
  requestUrl: string;
  input: {
    clientId?: string;
    campaignId?: string;
    destinationUrl: string;
    tags: Array<{ chipUid: string; name?: string; tagType?: NFCTagType; memorySize?: number }>;
  };
}) {
  const progress = [];

  for (const [index, rawTag] of input.tags.entries()) {
    const chipUid = normalizeChipUid(rawTag.chipUid);
    const existing = await prisma.nfcTag.findUnique({ where: { chipUid } });
    const tag = existing
      ? await prisma.nfcTag.update({
          where: { id: existing.id },
          data: {
            name: rawTag.name ?? existing.name,
            destinationUrl: input.destinationUrl,
            clientId: input.clientId ?? existing.clientId,
            campaignId: input.campaignId ?? existing.campaignId,
            tagType: rawTag.tagType ?? existing.tagType,
            memorySize: rawTag.memorySize ?? existing.memorySize,
          },
        })
      : await registerNfcTag({
          user,
          input: {
            chipUid,
            name: rawTag.name ?? `Batch tag ${index + 1}`,
            destinationUrl: input.destinationUrl,
            clientId: input.clientId,
            campaignId: input.campaignId,
            tagType: rawTag.tagType,
            memorySize: rawTag.memorySize,
          },
        });

    const prepared = await prepareNfcWrite({
      user,
      selector: { tagId: tag.id },
      requestUrl,
      destinationUrl: input.destinationUrl,
    });

    progress.push({
      order: index + 1,
      tagId: tag.id,
      chipUid,
      writeLogId: prepared.writeLog.id,
      payload: prepared.payload,
      status: "PENDING_WRITE",
    });
  }

  return progress;
}

export function forbiddenResponse(error: unknown) {
  if (error instanceof Error && error.message === "Forbidden") return fail("Forbidden", 403);
  return null;
}
