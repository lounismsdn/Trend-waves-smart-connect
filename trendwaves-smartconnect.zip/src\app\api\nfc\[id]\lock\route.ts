import { NextRequest } from "next/server";
import { fail, guardRateLimit, handleApiError, ok } from "@/lib/api";
import { getAuthUser } from "@/lib/auth";
import { lockNfcTag } from "@/services/nfc";
import { nfcLockSchema } from "@/lib/validation";

export const runtime = "nodejs";

type RouteContext = { params: Promise<{ id: string }> };

export async function POST(request: NextRequest, context: RouteContext) {
  const limited = guardRateLimit(request, "nfc:lock", 40);
  if (limited) return limited;

  try {
    const user = await getAuthUser(request);
    if (!user) return fail("Unauthorized", 401);

    nfcLockSchema.parse(await request.json());
    const { id } = await context.params;
    const tag = await lockNfcTag({ user, tagId: id });

    return ok(tag);
  } catch (error) {
    return handleApiError(error);
  }
}
