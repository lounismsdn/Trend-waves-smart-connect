import { NextRequest } from "next/server";
import { Prisma } from "@prisma/client";
import { fail, guardRateLimit, handleApiError, ok } from "@/lib/api";
import { getAuthUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { qrStylePresetSchema } from "@/lib/validation";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const limited = guardRateLimit(request, "qr:style-presets:list", 200);
  if (limited) return limited;

  try {
    const user = await getAuthUser(request);
    if (!user) return fail("Unauthorized", 401);

    const clientId = request.nextUrl.searchParams.get("clientId") ?? user.clientId ?? undefined;
    const presets = await prisma.qRStylePreset.findMany({
      where: {
        OR: [
          { isSystem: true },
          ...(clientId ? [{ clientId }] : []),
        ],
      },
      orderBy: [{ isSystem: "desc" }, { updatedAt: "desc" }],
    });

    return ok(presets);
  } catch (error) {
    return handleApiError(error);
  }
}

export async function POST(request: NextRequest) {
  const limited = guardRateLimit(request, "qr:style-presets:create", 80);
  if (limited) return limited;

  try {
    const user = await getAuthUser(request);
    if (!user) return fail("Unauthorized", 401);

    const input = qrStylePresetSchema.parse(await request.json());
    const clientId = input.clientId ?? user.clientId ?? null;
    if (user.role === "CLIENT" && user.clientId && clientId !== user.clientId) return fail("Forbidden", 403);

    const existing = await prisma.qRStylePreset.findFirst({
      where: { clientId, name: input.name },
    });

    const preset = existing
      ? await prisma.qRStylePreset.update({
          where: { id: existing.id },
          data: {
            description: input.description,
            design: input.design as Prisma.InputJsonValue,
          },
        })
      : await prisma.qRStylePreset.create({
        data: {
        name: input.name,
        description: input.description,
        clientId,
        design: input.design as Prisma.InputJsonValue,
        isSystem: user.role === "ADMIN" ? input.isSystem ?? false : false,
      },
      });

    return ok(preset, { status: 201 });
  } catch (error) {
    return handleApiError(error);
  }
}
