import type { NFCTagType } from "@prisma/client";

export type NfcCapability = {
  tagType: NFCTagType;
  memorySize: number;
  writable: boolean;
  maxUrlBytes: number;
};

const capabilityMap: Record<NFCTagType, Omit<NfcCapability, "tagType">> = {
  NTAG213: { memorySize: 144, writable: true, maxUrlBytes: 132 },
  NTAG215: { memorySize: 504, writable: true, maxUrlBytes: 492 },
  NTAG216: { memorySize: 888, writable: true, maxUrlBytes: 876 },
  MIFARE_ULTRALIGHT: { memorySize: 48, writable: true, maxUrlBytes: 40 },
  UNKNOWN: { memorySize: 144, writable: true, maxUrlBytes: 132 },
};

export function detectNfcCapability(tagType: NFCTagType = "NTAG213", memorySize?: number): NfcCapability {
  const fallback = capabilityMap[tagType] ?? capabilityMap.UNKNOWN;
  const size = memorySize ?? fallback.memorySize;

  return {
    tagType,
    memorySize: size,
    writable: fallback.writable && size > 0,
    maxUrlBytes: Math.max(32, size - 12),
  };
}

export function normalizeChipUid(uid: string) {
  return uid.trim().toUpperCase().replace(/[^A-F0-9]/g, "").match(/.{1,2}/g)?.join(":") ?? uid.trim().toUpperCase();
}

export function buildNdefUrlRecord(url: string) {
  const payload = new TextEncoder().encode(url);
  return {
    recordType: "url",
    data: url,
    byteLength: payload.byteLength,
  };
}

export function payloadMatchesShortId(payload: string, shortId: string) {
  try {
    const parsed = new URL(payload);
    return parsed.pathname === `/r/${shortId}`;
  } catch {
    return payload.includes(`/r/${shortId}`);
  }
}
