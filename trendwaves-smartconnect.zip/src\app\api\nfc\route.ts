import { NextRequest } from "next/server";
import { fail, guardRateLimit, handleApiError, ok } from "@/lib/api";
import { getAuthUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { signedNfcRedirectUrl } from "@/services/nfc";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const limited = guardRateLimit(request, "nfc:list", 240);
  if (limited) return limited;

  try {
    const user = await getAuthUser(request);
    if (!user) return fail("Unauthorized", 401);

    const nfcTags = await prisma.nfcTag.findMany({
      where: user.role === "CLIENT" && user.clientId ? { clientId: user.clientId } : undefined,
      orderBy: { updatedAt: "desc" },
      include: {
        client: { select: { id: true, name: true, slug: true } },
        campaign: { select: { id: true, name: true, status: true } },
      },
    });

    const signedTags = await Promise.all(
      nfcTags.map(async (tag) => ({
        ...tag,
        shortUrl: await signedNfcRedirectUrl(tag.shortId, request.url),
      })),
    );

    return ok(signedTags);
  } catch (error) {
    return handleApiError(error);
  }
}
