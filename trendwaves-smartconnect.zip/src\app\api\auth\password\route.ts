import { z } from "zod";
import { NextRequest } from "next/server";
import { fail, guardRateLimit, handleApiError, ok } from "@/lib/api";
import { getAuthUser, hashPassword, verifyPassword } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export const runtime = "nodejs";

const passwordSchema = z.object({
  currentPassword: z.string().min(8),
  newPassword: z.string().min(10),
});

export async function POST(request: NextRequest) {
  const limited = guardRateLimit(request, "auth:password", 40);
  if (limited) return limited;

  try {
    const session = await getAuthUser(request);
    if (!session) return fail("Unauthorized", 401);

    const input = passwordSchema.parse(await request.json());
    const user = await prisma.user.findUnique({ where: { id: session.sub } });
    if (!user) return fail("User not found", 404);

    const valid = await verifyPassword(input.currentPassword, user.passwordHash);
    if (!valid) return fail("Current password is incorrect", 400);

    await prisma.user.update({
      where: { id: user.id },
      data: { passwordHash: await hashPassword(input.newPassword) },
    });

    await prisma.auditLog.create({
      data: {
        actorId: user.id,
        action: "PASSWORD_UPDATED",
        entity: "User",
        entityId: user.id,
      },
    });

    return ok({ updated: true });
  } catch (error) {
    return handleApiError(error);
  }
}
