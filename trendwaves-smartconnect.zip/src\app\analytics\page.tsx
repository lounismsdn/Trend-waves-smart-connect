import { AnalyticsView } from "@/components/smartconnect/views";
import { AppShell } from "@/components/smartconnect/app-shell";
import { requirePageAuth } from "@/lib/server-auth";

export default async function AnalyticsPage() {
  await requirePageAuth("/analytics");

  return (
    <AppShell>
      <AnalyticsView />
    </AppShell>
  );
}
