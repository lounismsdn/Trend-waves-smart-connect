"use client";

import { motion } from "framer-motion";
import { ArrowLeft, Download, FileDown, Globe2, MousePointerClick, Smartphone, Users } from "lucide-react";
import Link from "next/link";
import * as React from "react";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Pie,
  PieChart,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { formatNumber } from "@/lib/utils";

type AnalyticsPayload = {
  asset: {
    id: string;
    name: string;
    shortId: string;
    destinationUrl: string;
    status: string;
    client?: { name?: string } | null;
    campaign?: { name?: string } | null;
  };
  totals: { scans: number; unique: number; lastScanAt: string | null };
  dailyScans: Array<{ date: string; scans: number; unique: number }>;
  weeklyTrends: Array<{ week: string; scans: number; unique: number }>;
  devices: Array<{ name: string; value: number }>;
  locations: Array<{ name: string; value: number }>;
  browsers: Array<{ name: string; value: number }>;
  sources: Array<{ name: string; value: number }>;
  recentScans: Array<{
    id: string;
    timestamp: string;
    city: string;
    country: string;
    device: string;
    browser: string;
    referrer: string;
    converted: boolean;
  }>;
};

const chartColors = ["#1500f5", "#ff7900", "#f8fafc", "#c2c8d2"];

function ChartTooltip({
  active,
  payload,
  label,
}: {
  active?: boolean;
  payload?: Array<{ name: string; value: number; color?: string }>;
  label?: string;
}) {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-2xl border border-white/10 bg-slate-950/95 p-3 shadow-2xl">
      <p className="mb-2 text-xs text-slate-400">{label}</p>
      {payload.map((item) => (
        <p key={item.name} className="text-sm text-white">
          <span style={{ color: item.color }}>{item.name}</span>: {formatNumber(item.value)}
        </p>
      ))}
    </div>
  );
}

function downloadUrl(url: string, filename: string) {
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.click();
}

function MeasuredChart({
  children,
}: {
  children: (size: { width: number; height: number }) => React.ReactNode;
}) {
  const ref = React.useRef<HTMLDivElement | null>(null);
  const [size, setSize] = React.useState({ width: 0, height: 0 });

  React.useEffect(() => {
    if (!ref.current) return;

    const element = ref.current;
    const update = () => {
      setSize({
        width: Math.max(element.clientWidth, 1),
        height: Math.max(element.clientHeight, 1),
      });
    };
    const observer = new ResizeObserver(update);

    update();
    observer.observe(element);
    return () => observer.disconnect();
  }, []);

  return (
    <div ref={ref} className="h-full w-full">
      {size.width > 1 && size.height > 1 ? children(size) : <Skeleton className="h-full w-full rounded-[18px]" />}
    </div>
  );
}

export function QRAnalyticsDetailView({ id }: { id: string }) {
  const [data, setData] = React.useState<AnalyticsPayload | null>(null);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    fetch(`/api/qr/${id}/analytics`, { credentials: "include" })
      .then((response) => (response.ok ? response.json() : Promise.reject(new Error("Analytics failed to load"))))
      .then((body) => setData(body.data))
      .catch((error) => toast.error("Could not load QR analytics", { description: error.message }))
      .finally(() => setLoading(false));
  }, [id]);

  function exportAnalytics(format: "csv" | "pdf") {
    downloadUrl(`/api/qr/${id}/analytics/export?format=${format}`, `qr-analytics.${format}`);
    toast.success(`${format.toUpperCase()} analytics export started`);
  }

  if (loading) {
    return (
      <div className="space-y-5">
        <Skeleton className="h-40" />
        <div className="grid gap-5 lg:grid-cols-3">
          <Skeleton className="h-44" />
          <Skeleton className="h-44" />
          <Skeleton className="h-44" />
        </div>
        <Skeleton className="h-96" />
      </div>
    );
  }

  if (!data) {
    return (
      <Card>
        <CardContent className="grid min-h-72 place-items-center p-8 text-center">
          <div>
            <p className="font-display text-2xl font-black text-white">Analytics unavailable</p>
            <p className="mt-2 text-sm text-slate-400">Refresh the page or return to QR Manager.</p>
            <Button asChild className="mt-5">
              <Link href="/qr-manager">Back to QR Manager</Link>
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div>
      <div className="mb-7 flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
        <div>
          <Button asChild variant="secondary" className="mb-5">
            <Link href="/qr-manager">
              <ArrowLeft className="h-4 w-4" />
              QR Manager
            </Link>
          </Button>
          <p className="mb-3 text-xs font-semibold uppercase tracking-[0.28em] text-[#ff7900]">QR statistics</p>
          <h2 className="font-display text-3xl font-black leading-tight text-white sm:text-5xl">{data.asset.name}</h2>
          <p className="mt-4 max-w-2xl text-sm leading-6 text-slate-400">
            /r/{data.asset.shortId} · {data.asset.client?.name ?? "Unassigned"} · {data.asset.destinationUrl}
          </p>
        </div>
        <div className="flex flex-wrap gap-3">
          <Button variant="secondary" onClick={() => exportAnalytics("csv")}>
            <Download className="h-4 w-4" />
            CSV
          </Button>
          <Button onClick={() => exportAnalytics("pdf")}>
            <FileDown className="h-4 w-4" />
            PDF
          </Button>
        </div>
      </div>

      <div className="grid gap-4 sm:grid-cols-3">
        {[
          { label: "Total scans", value: data.totals.scans, icon: MousePointerClick },
          { label: "Unique visitors", value: data.totals.unique, icon: Users },
          { label: "Device groups", value: data.devices.length, icon: Smartphone },
        ].map((metric, index) => {
          const Icon = metric.icon;
          return (
            <motion.div key={metric.label} initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.06 }}>
              <Card>
                <CardContent className="p-5">
                  <Icon className="mb-8 h-5 w-5 text-[#ff7900]" />
                  <p className="text-sm text-slate-400">{metric.label}</p>
                  <p className="mt-2 font-display text-3xl font-black text-white">{formatNumber(metric.value)}</p>
                </CardContent>
              </Card>
            </motion.div>
          );
        })}
      </div>

      <div className="mt-5 grid gap-5 xl:grid-cols-[1.25fr_0.75fr]">
        <Card>
          <CardHeader>
            <CardTitle>Daily scans</CardTitle>
            <CardDescription>Scan and unique visitor trend</CardDescription>
          </CardHeader>
          <CardContent className="h-[340px]">
            <MeasuredChart>
              {({ width, height }) => (
                <AreaChart width={width} height={height} data={data.dailyScans}>
                  <CartesianGrid stroke="rgba(255,255,255,0.07)" vertical={false} />
                  <XAxis dataKey="date" stroke="#64748b" tickLine={false} axisLine={false} />
                  <YAxis stroke="#64748b" tickLine={false} axisLine={false} />
                  <Tooltip content={<ChartTooltip />} />
                  <Area type="monotone" dataKey="scans" stroke="#1500f5" fill="#1500f555" strokeWidth={3} />
                  <Area type="monotone" dataKey="unique" stroke="#ff7900" fill="#ff790033" strokeWidth={2} />
                </AreaChart>
              )}
            </MeasuredChart>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Device analytics</CardTitle>
            <CardDescription>Traffic split by scanner device</CardDescription>
          </CardHeader>
          <CardContent className="h-[340px]">
            <MeasuredChart>
              {({ width, height }) => (
                <PieChart width={width} height={height}>
                  <Pie data={data.devices} dataKey="value" nameKey="name" innerRadius={72} outerRadius={118} paddingAngle={4}>
                    {data.devices.map((entry, index) => (
                      <Cell key={entry.name} fill={chartColors[index % chartColors.length]} />
                    ))}
                  </Pie>
                  <Tooltip content={<ChartTooltip />} />
                </PieChart>
              )}
            </MeasuredChart>
          </CardContent>
        </Card>
      </div>

      <div className="mt-5 grid gap-5 xl:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Weekly trends</CardTitle>
            <CardDescription>Scan lift by week</CardDescription>
          </CardHeader>
          <CardContent className="h-[300px]">
            <MeasuredChart>
              {({ width, height }) => (
                <BarChart width={width} height={height} data={data.weeklyTrends}>
                  <CartesianGrid stroke="rgba(255,255,255,0.07)" vertical={false} />
                  <XAxis dataKey="week" stroke="#64748b" tickLine={false} axisLine={false} />
                  <YAxis stroke="#64748b" tickLine={false} axisLine={false} />
                  <Tooltip content={<ChartTooltip />} />
                  <Bar dataKey="scans" fill="#1500f5" radius={[10, 10, 0, 0]} />
                  <Bar dataKey="unique" fill="#ff7900" radius={[10, 10, 0, 0]} />
                </BarChart>
              )}
            </MeasuredChart>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Geographic map</CardTitle>
            <CardDescription>Top scan locations by volume</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {data.locations.slice(0, 7).map((location, index) => (
              <div key={location.name} className="rounded-2xl border border-white/10 bg-white/[0.045] p-4">
                <div className="flex items-center justify-between gap-3">
                  <span className="flex items-center gap-2 text-sm text-white">
                    <Globe2 className="h-4 w-4 text-[#ff7900]" />
                    {location.name}
                  </span>
                  <Badge variant={index === 0 ? "cyan" : "muted"}>{formatNumber(location.value)}</Badge>
                </div>
                <div className="mt-3 h-2 overflow-hidden rounded-full bg-white/10">
                  <div
                    className="h-full rounded-full bg-gradient-to-r from-[#1500f5] to-[#ff7900]"
                    style={{ width: `${Math.max(12, (location.value / Math.max(data.locations[0]?.value ?? 1, 1)) * 100)}%` }}
                  />
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      <div className="mt-5 grid gap-5 xl:grid-cols-[1.2fr_0.8fr]">
        <Card className="overflow-hidden">
          <CardHeader>
            <CardTitle>Recent scans</CardTitle>
            <CardDescription>Latest redirect events for this QR code</CardDescription>
          </CardHeader>
          <div className="overflow-x-auto">
            <table className="w-full min-w-[820px] text-left text-sm">
              <thead className="border-y border-white/10 text-xs uppercase tracking-[0.16em] text-slate-500">
                <tr>
                  <th className="px-5 py-4">Timestamp</th>
                  <th className="px-5 py-4">Location</th>
                  <th className="px-5 py-4">Device</th>
                  <th className="px-5 py-4">Browser</th>
                  <th className="px-5 py-4">Source</th>
                  <th className="px-5 py-4">Conversion</th>
                </tr>
              </thead>
              <tbody>
                {data.recentScans.map((scan) => (
                  <tr key={scan.id} className="border-b border-white/5">
                    <td className="px-5 py-4 text-white">{new Date(scan.timestamp).toLocaleString()}</td>
                    <td className="px-5 py-4 text-slate-400">{scan.city}, {scan.country}</td>
                    <td className="px-5 py-4 text-slate-400">{scan.device}</td>
                    <td className="px-5 py-4 text-slate-400">{scan.browser}</td>
                    <td className="px-5 py-4 text-slate-400">{scan.referrer}</td>
                    <td className="px-5 py-4">
                      <Badge variant={scan.converted ? "success" : "muted"}>{scan.converted ? "Yes" : "No"}</Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Traffic source and browser data</CardTitle>
          </CardHeader>
          <CardContent className="space-y-5">
            <div>
              <p className="mb-3 text-xs uppercase tracking-[0.18em] text-slate-500">Sources</p>
              {data.sources.slice(0, 5).map((source) => (
                <div key={source.name} className="mb-2 flex justify-between rounded-2xl border border-white/10 bg-white/[0.045] p-3 text-sm">
                  <span className="text-white">{source.name}</span>
                  <span className="text-slate-400">{formatNumber(source.value)}</span>
                </div>
              ))}
            </div>
            <div>
              <p className="mb-3 text-xs uppercase tracking-[0.18em] text-slate-500">Browsers</p>
              {data.browsers.slice(0, 5).map((browser) => (
                <div key={browser.name} className="mb-2 flex justify-between rounded-2xl border border-white/10 bg-white/[0.045] p-3 text-sm">
                  <span className="text-white">{browser.name}</span>
                  <span className="text-slate-400">{formatNumber(browser.value)}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
