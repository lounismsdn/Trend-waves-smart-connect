import { NextRequest } from "next/server";
import { Prisma } from "@prisma/client";
import { fail, guardRateLimit, handleApiError, ok } from "@/lib/api";
import { getAuthUser, signRedirect } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { checksumDesign, validateQrStyleReliability } from "@/lib/qr-style";
import { qrStyleSchema } from "@/lib/validation";

export const runtime = "nodejs";

type RouteContext = { params: Promise<{ id: string }> };

export async function GET(request: NextRequest, context: RouteContext) {
  const limited = guardRateLimit(request, "qr:style:get", 200);
  if (limited) return limited;

  try {
    const user = await getAuthUser(request);
    if (!user) return fail("Unauthorized", 401);

    const { id } = await context.params;
    const qrCode = await prisma.qrCode.findUnique({
      where: { id },
      include: { designVersions: { orderBy: { version: "desc" } }, stylePreset: true },
    });

    if (!qrCode) return fail("QR code not found", 404);
    if (user.role === "CLIENT" && user.clientId && qrCode.clientId !== user.clientId) return fail("Forbidden", 403);

    return ok({
      design: qrCode.design,
      designVersion: qrCode.designVersion,
      stylePreset: qrCode.stylePreset,
      history: qrCode.designVersions,
      reliability: validateQrStyleReliability(qrCode.design as Record<string, unknown> | null),
    });
  } catch (error) {
    return handleApiError(error);
  }
}

export async function PUT(request: NextRequest, context: RouteContext) {
  const limited = guardRateLimit(request, "qr:style:update", 100);
  if (limited) return limited;

  try {
    const user = await getAuthUser(request);
    if (!user) return fail("Unauthorized", 401);

    const { id } = await context.params;
    const input = qrStyleSchema.parse(await request.json());
    const reliability = validateQrStyleReliability(input.design);
    if (!reliability.valid) return fail("QR style is not export-safe", 422, reliability);

    const updated = await prisma.$transaction(async (tx) => {
      const current = await tx.qrCode.findUnique({ where: { id } });
      if (!current) throw new Error("QR code not found");
      if (user.role === "CLIENT" && user.clientId && current.clientId !== user.clientId) throw new Error("Forbidden");

      const nextVersion = current.designVersion + 1;
      const qrCode = await tx.qrCode.update({
        where: { id },
        data: {
          design: input.design as Prisma.InputJsonValue,
          designVersion: nextVersion,
          designChecksum: checksumDesign(input.design),
        },
        include: {
          client: { select: { id: true, name: true, slug: true } },
          campaign: { select: { id: true, name: true, status: true } },
        },
      });

      await tx.qrDesignVersion.create({
        data: {
          qrCodeId: id,
          version: nextVersion,
          design: input.design as Prisma.InputJsonValue,
          changes: (input.changes ?? { updated: true }) as Prisma.InputJsonValue,
          editorId: user.sub,
        },
      });

      return qrCode;
    });

    const signature = await signRedirect(updated.shortId);
    const origin = process.env.APP_URL ?? new URL(request.url).origin;

    return ok({
      ...updated,
      shortUrl: `${origin}/r/${updated.shortId}?s=${signature}`,
      reliability,
    });
  } catch (error) {
    if (error instanceof Error && error.message === "Forbidden") return fail("Forbidden", 403);
    return handleApiError(error);
  }
}
