import { NextRequest } from "next/server";
import { Prisma } from "@prisma/client";
import { fail, guardRateLimit, handleApiError, ok } from "@/lib/api";
import { getAuthUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { nfcUpdateSchema } from "@/lib/validation";

export const runtime = "nodejs";

type RouteContext = { params: Promise<{ id: string }> };

export async function PUT(request: NextRequest, context: RouteContext) {
  const limited = guardRateLimit(request, "nfc:update", 120);
  if (limited) return limited;

  try {
    const user = await getAuthUser(request);
    if (!user) return fail("Unauthorized", 401);

    const { id } = await context.params;
    const input = nfcUpdateSchema.parse(await request.json());
    const { clientId, campaignId, ...tagUpdate } = input;
    const nfcTag = await prisma.$transaction(async (tx) => {
      const current = await tx.nfcTag.findUnique({ where: { id } });
      if (!current) throw new Error("NFC tag not found");
      if (current.isLocked && input.destinationUrl) throw new Error("NFC tag is locked");

      const updated = await tx.nfcTag.update({
        where: { id },
        data: {
          ...tagUpdate,
          client: clientId ? { connect: { id: clientId } } : undefined,
          campaign: campaignId ? { connect: { id: campaignId } } : undefined,
          operationalStatus: input.isLocked ? "LOCKED" : input.destinationUrl ? "WRITTEN" : input.operationalStatus,
          writeCount: input.destinationUrl ? { increment: 1 } : undefined,
          lastWriteAt: input.destinationUrl ? new Date() : undefined,
        },
      });

      if (input.destinationUrl) {
        await tx.nFCWriteLog.create({
          data: {
            tagId: id,
            writerId: user.sub,
            payload: input.destinationUrl,
            previousPayload: current.destinationUrl,
            status: "WRITTEN",
            metadata: { updateMode: "DYNAMIC_REDIRECT" } as Prisma.InputJsonValue,
          },
        });
      }

      return updated;
    });

    await prisma.auditLog.create({
      data: {
        actorId: user.sub,
        action: "NFC_UPDATED",
        entity: "NfcTag",
        entityId: id,
        metadata: input as Prisma.InputJsonValue,
      },
    });

    return ok(nfcTag);
  } catch (error) {
    return handleApiError(error);
  }
}
