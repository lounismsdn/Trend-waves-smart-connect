"use client";

import { motion } from "framer-motion";
import { ArrowRight, LockKeyhole, Mail, UserRound } from "lucide-react";
import { useRouter } from "next/navigation";
import * as React from "react";
import { TrendWavesLogo } from "@/components/smartconnect/brand-logo";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

type Mode = "login" | "register";

export function AuthPanel({ mode }: { mode: Mode }) {
  const router = useRouter();
  const [error, setError] = React.useState("");
  const [loading, setLoading] = React.useState(false);

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    setLoading(true);

    const formData = new FormData(event.currentTarget);
    const payload =
      mode === "login"
        ? {
            email: String(formData.get("email")),
            password: String(formData.get("password")),
          }
        : {
            name: String(formData.get("name")),
            email: String(formData.get("email")),
            password: String(formData.get("password")),
            role: String(formData.get("role") ?? "AGENCY"),
            agencyName: "Trend Waves",
          };

    try {
      const response = await fetch(`/api/auth/${mode}`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(payload),
        credentials: "include",
      });
      const body = await response.json();

      if (!response.ok) {
        throw new Error(body.error ?? "Authentication failed");
      }

      const next =
        typeof window !== "undefined"
          ? new URLSearchParams(window.location.search).get("next") ?? "/dashboard"
          : "/dashboard";
      router.push(next);
      router.refresh();
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Authentication failed");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen overflow-hidden bg-[#050505] text-white">
      <div className="pointer-events-none fixed inset-0 wave-field opacity-80" />
      <div className="pointer-events-none fixed inset-0 bg-[radial-gradient(circle_at_16%_12%,rgba(21,0,245,0.22),transparent_30%),radial-gradient(circle_at_82%_24%,rgba(255,121,0,0.13),transparent_28%)]" />
      <main className="relative z-10 grid min-h-screen place-items-center px-4 py-10">
        <motion.div
          className="w-full max-w-xl"
          initial={{ opacity: 0, y: 18 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45 }}
        >
          <div className="mb-8 text-center">
            <div className="mx-auto mb-5 grid h-[72px] w-36 place-items-center rounded-[22px] border border-[#c2c8d2]/20 bg-white px-3 py-2 shadow-[0_0_34px_rgba(21,0,245,0.20)]">
              <TrendWavesLogo withText={false} tone="blue" markClassName="h-11 w-32" />
            </div>
            <p className="mb-3 text-xs font-semibold uppercase tracking-[0.28em] text-[#ff7900]">Trend waves</p>
            <h1 className="font-display text-4xl font-black leading-tight">
              {mode === "login" ? "Enter SmartConnect." : "Create an agency account."}
            </h1>
            <p className="mx-auto mt-4 max-w-md text-sm leading-6 text-slate-400">
              {mode === "login"
                ? "Use your agency, admin, or client account to manage dynamic QR and NFC assets."
                : "Register the first workspace user, then connect clients, campaigns, QR codes, and NFC tags."}
            </p>
          </div>

          <Card>
            <CardContent className="p-6">
              <form className="space-y-4" onSubmit={submit}>
                {mode === "register" ? (
                  <label className="space-y-2">
                    <span className="text-sm text-slate-400">Name</span>
                    <div className="flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.05] px-4">
                      <UserRound className="h-4 w-4 text-slate-500" />
                      <Input name="name" className="border-0 bg-transparent px-0 focus:bg-transparent" required />
                    </div>
                  </label>
                ) : null}

                <label className="space-y-2">
                  <span className="text-sm text-slate-400">Email</span>
                  <div className="flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.05] px-4">
                    <Mail className="h-4 w-4 text-[#c2c8d2]/60" />
                    <Input
                      name="email"
                      className="border-0 bg-transparent px-0 focus:bg-transparent"
                      type="email"
                      defaultValue={mode === "login" ? "admin@trendwaves.app" : ""}
                      required
                    />
                  </div>
                </label>

                <label className="space-y-2">
                  <span className="text-sm text-slate-400">Password</span>
                  <div className="flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.05] px-4">
                    <LockKeyhole className="h-4 w-4 text-[#c2c8d2]/60" />
                    <Input
                      name="password"
                      className="border-0 bg-transparent px-0 focus:bg-transparent"
                      type="password"
                      defaultValue={mode === "login" ? "TrendWaves123!" : ""}
                      minLength={8}
                      required
                    />
                  </div>
                </label>

                {mode === "register" ? (
                  <Select name="role" defaultValue="AGENCY">
                    <SelectTrigger className="w-full">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ADMIN">Admin</SelectItem>
                      <SelectItem value="AGENCY">Agency team</SelectItem>
                      <SelectItem value="CLIENT">Client sub-account</SelectItem>
                    </SelectContent>
                  </Select>
                ) : null}

                {error ? (
                  <div className="rounded-[18px] border border-rose-300/20 bg-rose-300/10 p-3 text-sm text-rose-100">
                    {error}
                  </div>
                ) : null}

                <Button className="w-full" type="submit" disabled={loading}>
                  {loading ? "Working..." : mode === "login" ? "Log in" : "Create account"}
                  <ArrowRight className="h-4 w-4" />
                </Button>
              </form>

              <div className="mt-5 text-center text-sm text-slate-400">
                {mode === "login" ? (
                  <a className="text-[#ff7900] hover:text-white" href="/register">
                    Need an account? Register
                  </a>
                ) : (
                  <a className="text-[#ff7900] hover:text-white" href="/login">
                    Already have an account? Log in
                  </a>
                )}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </main>
    </div>
  );
}
