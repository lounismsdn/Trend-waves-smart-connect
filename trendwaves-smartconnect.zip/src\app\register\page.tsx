import { AuthPanel } from "@/components/smartconnect/auth-panel";

export default function RegisterPage() {
  return <AuthPanel mode="register" />;
}
