import { NextRequest } from "next/server";
import { fail, guardRateLimit, handleApiError, ok } from "@/lib/api";
import { getAuthUser, signRedirect } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const limited = guardRateLimit(request, "qr:list", 240);
  if (limited) return limited;

  try {
    const user = await getAuthUser(request);
    if (!user) return fail("Unauthorized", 401);

    const qrCodes = await prisma.qrCode.findMany({
      where: user.role === "CLIENT" && user.clientId ? { clientId: user.clientId } : undefined,
      orderBy: { updatedAt: "desc" },
      include: {
        client: { select: { id: true, name: true, slug: true } },
        campaign: { select: { id: true, name: true, status: true } },
      },
    });

    const origin = process.env.APP_URL ?? new URL(request.url).origin;
    const signedQrCodes = await Promise.all(
      qrCodes.map(async (qrCode) => {
        const signature = await signRedirect(qrCode.shortId);
        return {
          ...qrCode,
          shortUrl: `${origin}/r/${qrCode.shortId}?s=${signature}`,
        };
      }),
    );

    return ok(signedQrCodes);
  } catch (error) {
    return handleApiError(error);
  }
}
