import { NextRequest } from "next/server";
import { fail, guardRateLimit, handleApiError, ok } from "@/lib/api";
import { getAuthUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const limited = guardRateLimit(request, "auth:me", 120);
  if (limited) return limited;

  try {
    const session = await getAuthUser(request);
    if (!session) return fail("Unauthorized", 401);

    const user = await prisma.user.findUnique({
      where: { id: session.sub },
      select: {
        id: true,
        email: true,
        name: true,
        role: true,
        agencyName: true,
        clientId: true,
        client: { select: { name: true, slug: true } },
      },
    });

    if (!user) return fail("User not found", 404);

    return ok(user);
  } catch (error) {
    return handleApiError(error);
  }
}
