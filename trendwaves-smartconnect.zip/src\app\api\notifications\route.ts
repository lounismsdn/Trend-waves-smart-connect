import { NextRequest } from "next/server";
import { z } from "zod";
import { fail, guardRateLimit, handleApiError, ok } from "@/lib/api";
import { getAuthUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export const runtime = "nodejs";

const notificationPatchSchema = z.object({
  ids: z.array(z.string()).optional(),
  read: z.boolean().default(true),
});

export async function GET(request: NextRequest) {
  const limited = guardRateLimit(request, "notifications:list", 240);
  if (limited) return limited;

  try {
    const user = await getAuthUser(request);
    if (!user) return fail("Unauthorized", 401);

    const notifications = await prisma.notification.findMany({
      orderBy: [{ read: "asc" }, { createdAt: "desc" }],
      take: 20,
    });

    return ok(notifications);
  } catch (error) {
    return handleApiError(error);
  }
}

export async function PATCH(request: NextRequest) {
  const limited = guardRateLimit(request, "notifications:update", 120);
  if (limited) return limited;

  try {
    const user = await getAuthUser(request);
    if (!user) return fail("Unauthorized", 401);

    const input = notificationPatchSchema.parse(await request.json());
    await prisma.notification.updateMany({
      where: input.ids?.length ? { id: { in: input.ids } } : undefined,
      data: { read: input.read },
    });

    return ok({ updated: true });
  } catch (error) {
    return handleApiError(error);
  }
}
