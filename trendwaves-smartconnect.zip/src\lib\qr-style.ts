import crypto from "crypto";
import PDFDocument from "pdfkit";
import QRCode from "qrcode";
import sharp from "sharp";

export type QrStyleDesign = {
  moduleShape?: "square" | "rounded" | "dots" | "wave";
  eyeShape?: "square" | "rounded" | "circle";
  foreground?: string;
  foreground2?: string;
  background?: string;
  background2?: string;
  gradientType?: "solid" | "linear" | "radial";
  gradientDirection?: number;
  gradientIntensity?: number;
  gradientOpacity?: number;
  dotSpacing?: number;
  borderRadius?: number;
  padding?: number;
  quietZone?: number;
  frameText?: string;
  frameStyle?: "none" | "pill" | "premium" | "editorial";
  glowIntensity?: number;
  logoUrl?: string;
  logoScale?: number;
  logoPadding?: number;
  logoMask?: "rounded" | "circle" | "none";
  backgroundPattern?: "none" | "waves" | "grid" | "dots";
};

export function normalizeQrDesign(design?: Record<string, unknown> | null): Required<QrStyleDesign> {
  const input = (design ?? {}) as QrStyleDesign;

  return {
    moduleShape: input.moduleShape ?? "rounded",
    eyeShape: input.eyeShape ?? "rounded",
    foreground: input.foreground ?? "#050505",
    foreground2: input.foreground2 ?? "#1500f5",
    background: input.background ?? "#ffffff",
    background2: input.background2 ?? "#f8fafc",
    gradientType: input.gradientType ?? "linear",
    gradientDirection: input.gradientDirection ?? 135,
    gradientIntensity: input.gradientIntensity ?? 68,
    gradientOpacity: input.gradientOpacity ?? 100,
    dotSpacing: input.dotSpacing ?? 3,
    borderRadius: input.borderRadius ?? 22,
    padding: input.padding ?? 18,
    quietZone: input.quietZone ?? 4,
    frameText: input.frameText ?? "Scan to connect",
    frameStyle: input.frameStyle ?? "premium",
    glowIntensity: input.glowIntensity ?? 22,
    logoUrl: input.logoUrl ?? "",
    logoScale: input.logoScale ?? 17,
    logoPadding: input.logoPadding ?? 8,
    logoMask: input.logoMask ?? "rounded",
    backgroundPattern: input.backgroundPattern ?? "waves",
  };
}

export function checksumDesign(design: unknown) {
  return crypto.createHash("sha256").update(JSON.stringify(design ?? {})).digest("hex");
}

export function validateQrStyleReliability(design?: Record<string, unknown> | null) {
  const normalized = normalizeQrDesign(design);
  const issues: string[] = [];

  if (normalized.quietZone < 2) issues.push("Quiet zone should be at least 2 modules.");
  if (normalized.logoScale > 24) issues.push("Logo scale should stay below 24% for scan reliability.");
  if (normalized.dotSpacing > 16) issues.push("Dot spacing is high and may reduce module readability.");

  return {
    valid: issues.length === 0,
    issues,
    score: Math.max(62, 100 - issues.length * 14 - Math.max(0, normalized.logoScale - 20)),
  };
}

function isFinderPattern(x: number, y: number, size: number) {
  const inTop = y < 7;
  const inLeft = x < 7;
  const inRight = x >= size - 7;
  const inBottom = y >= size - 7;

  return (inTop && inLeft) || (inTop && inRight) || (inBottom && inLeft);
}

function moduleElement({
  x,
  y,
  shape,
  spacing,
  fill,
}: {
  x: number;
  y: number;
  shape: Required<QrStyleDesign>["moduleShape"];
  spacing: number;
  fill: string;
}) {
  const gap = Math.min(Math.max(spacing / 100, 0), 0.34);
  const pos = { x: x + gap / 2, y: y + gap / 2, size: 1 - gap };

  if (shape === "dots") {
    const r = pos.size / 2;
    return `<circle cx="${x + 0.5}" cy="${y + 0.5}" r="${r}" fill="${fill}" />`;
  }

  if (shape === "wave") {
    const radius = Math.max(0.16, pos.size * 0.38);
    const offset = Math.sin((x + y) * 0.44) * 0.025;
    return `<rect x="${pos.x}" y="${pos.y + offset}" width="${pos.size}" height="${pos.size}" rx="${radius}" fill="${fill}" />`;
  }

  const rx = shape === "rounded" ? Math.max(0.08, pos.size * 0.3) : 0;
  return `<rect x="${pos.x}" y="${pos.y}" width="${pos.size}" height="${pos.size}" rx="${rx}" fill="${fill}" />`;
}

function eyeElement(x: number, y: number, shape: Required<QrStyleDesign>["eyeShape"], fill: string, background: string) {
  if (shape === "circle") {
    return [
      `<circle cx="${x + 3.5}" cy="${y + 3.5}" r="3.5" fill="${fill}" />`,
      `<circle cx="${x + 3.5}" cy="${y + 3.5}" r="2.25" fill="${background}" />`,
      `<circle cx="${x + 3.5}" cy="${y + 3.5}" r="1.35" fill="${fill}" />`,
    ].join("");
  }

  const rx = shape === "rounded" ? 1.45 : 0;
  return [
    `<rect x="${x}" y="${y}" width="7" height="7" rx="${rx}" fill="${fill}" />`,
    `<rect x="${x + 1.05}" y="${y + 1.05}" width="4.9" height="4.9" rx="${rx / 1.5}" fill="${background}" />`,
    `<rect x="${x + 2.25}" y="${y + 2.25}" width="2.5" height="2.5" rx="${rx / 2}" fill="${fill}" />`,
  ].join("");
}

export function createStyledQrSvg(url: string, designInput?: Record<string, unknown> | null) {
  const design = normalizeQrDesign(designInput);
  const qr = QRCode.create(url, { errorCorrectionLevel: "H" });
  const size = qr.modules.size;
  const data = qr.modules.data;
  const quiet = Math.max(2, design.quietZone);
  const frameHeight = design.frameStyle === "none" ? 0 : 8;
  const canvas = size + quiet * 2;
  const totalHeight = canvas + frameHeight;
  const fill = design.gradientType === "solid" ? design.foreground : "url(#qrForeground)";
  const angle = ((design.gradientDirection % 360) * Math.PI) / 180;
  const x2 = 0.5 + Math.cos(angle) * 0.5;
  const y2 = 0.5 + Math.sin(angle) * 0.5;

  const modules = Array.from(data)
    .map((enabled, index) => {
      if (!enabled) return "";
      const x = index % size;
      const y = Math.floor(index / size);
      if (isFinderPattern(x, y, size)) return "";
      return moduleElement({
        x: x + quiet,
        y: y + quiet,
        shape: design.moduleShape,
        spacing: design.dotSpacing,
        fill,
      });
    })
    .join("");

  const eyes = [
    eyeElement(quiet, quiet, design.eyeShape, fill, design.background),
    eyeElement(quiet + size - 7, quiet, design.eyeShape, fill, design.background),
    eyeElement(quiet, quiet + size - 7, design.eyeShape, fill, design.background),
  ].join("");

  const pattern =
    design.backgroundPattern === "waves"
      ? `<path d="M${quiet} ${canvas - 6} C ${canvas * 0.3} ${canvas - 12}, ${canvas * 0.6} ${canvas}, ${canvas - quiet} ${canvas - 8}" fill="none" stroke="${design.foreground2}" stroke-width="0.28" opacity="0.18" />`
      : design.backgroundPattern === "grid"
        ? `<path d="M0 ${canvas / 2} H ${canvas} M${canvas / 2} 0 V ${canvas}" stroke="${design.foreground2}" stroke-width="0.12" opacity="0.13" />`
        : "";

  const logoSize = (canvas * design.logoScale) / 100;
  const logoX = canvas / 2 - logoSize / 2;
  const logoY = canvas / 2 - logoSize / 2;
  const logoRadius = design.logoMask === "circle" ? logoSize / 2 : design.logoMask === "rounded" ? design.logoPadding : 0;
  const logo = design.logoUrl
    ? `<rect x="${logoX}" y="${logoY}" width="${logoSize}" height="${logoSize}" rx="${logoRadius}" fill="${design.background}" stroke="rgba(5,5,5,0.12)" stroke-width="0.25" /><image href="${design.logoUrl}" x="${logoX + design.logoPadding / 4}" y="${logoY + design.logoPadding / 4}" width="${logoSize - design.logoPadding / 2}" height="${logoSize - design.logoPadding / 2}" preserveAspectRatio="xMidYMid meet" />`
    : "";

  const frame = frameHeight
    ? `<text x="${canvas / 2}" y="${canvas + 5.4}" text-anchor="middle" font-family="Arial, sans-serif" font-size="3.2" font-weight="800" letter-spacing="0.7" fill="${design.foreground}">${escapeXml(design.frameText)}</text>`
    : "";

  return `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="${Math.round((1200 * totalHeight) / canvas)}" viewBox="0 0 ${canvas} ${totalHeight}" role="img" aria-label="Trend Waves styled dynamic QR">
  <defs>
    <linearGradient id="qrForeground" x1="0" y1="0" x2="${x2}" y2="${y2}">
      <stop offset="0%" stop-color="${design.foreground}" stop-opacity="${design.gradientOpacity / 100}" />
      <stop offset="${Math.max(35, design.gradientIntensity)}%" stop-color="${design.foreground2}" stop-opacity="${design.gradientOpacity / 100}" />
    </linearGradient>
    <radialGradient id="qrBackground" cx="50%" cy="45%" r="70%">
      <stop offset="0%" stop-color="${design.background2}" />
      <stop offset="100%" stop-color="${design.background}" />
    </radialGradient>
  </defs>
  <rect width="${canvas}" height="${totalHeight}" rx="${design.borderRadius / 3}" fill="${design.gradientType === "radial" ? "url(#qrBackground)" : design.background}" />
  ${pattern}
  <g>${modules}${eyes}</g>
  ${logo}
  ${frame}
</svg>`;
}

export async function createStyledQrPngBuffer(url: string, design?: Record<string, unknown> | null) {
  return sharp(Buffer.from(createStyledQrSvg(url, design))).png().toBuffer();
}

export async function createStyledQrPdfBuffer(url: string, title: string, design?: Record<string, unknown> | null) {
  const qrBuffer = await createStyledQrPngBuffer(url, design);
  const normalized = normalizeQrDesign(design);

  return new Promise<Buffer>((resolve) => {
    const doc = new PDFDocument({ size: "A4", margin: 52 });
    const chunks: Buffer[] = [];

    doc.on("data", (chunk: Buffer) => chunks.push(chunk));
    doc.on("end", () => resolve(Buffer.concat(chunks)));

    doc.fillColor("#050505").fontSize(24).text(title, { align: "center" });
    doc.moveDown(0.35);
    doc.fillColor("#64748b").fontSize(10).text(url, { align: "center" });
    doc.roundedRect(129, 150, 337, 390, 24).fill("#f8fafc");
    doc.image(qrBuffer, 155, 174, { width: 285 });
    doc.fillColor(normalized.foreground).fontSize(12).text(normalized.frameText, 155, 485, { width: 285, align: "center" });
    doc.end();
  });
}

function escapeXml(value: string) {
  return value.replace(/[<>&'"]/g, (character) => {
    if (character === "<") return "&lt;";
    if (character === ">") return "&gt;";
    if (character === "&") return "&amp;";
    if (character === "'") return "&apos;";
    return "&quot;";
  });
}
