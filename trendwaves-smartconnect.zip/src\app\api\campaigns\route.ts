import { NextRequest } from "next/server";
import { fail, guardRateLimit, handleApiError, ok, parseBody } from "@/lib/api";
import { getAuthUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { campaignSchema } from "@/lib/validation";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const limited = guardRateLimit(request, "campaigns:list", 240);
  if (limited) return limited;

  try {
    const user = await getAuthUser(request);
    if (!user) return fail("Unauthorized", 401);

    const campaigns = await prisma.campaign.findMany({
      orderBy: { updatedAt: "desc" },
      include: { client: true, qrCodes: true, nfcTags: true },
    });

    return ok(campaigns);
  } catch (error) {
    return handleApiError(error);
  }
}

export async function POST(request: NextRequest) {
  const limited = guardRateLimit(request, "campaigns:create", 120);
  if (limited) return limited;

  try {
    const user = await getAuthUser(request);
    if (!user) return fail("Unauthorized", 401);

    const input = await parseBody(request, campaignSchema);
    const campaign = await prisma.campaign.create({
      data: {
        ...input,
        startAt: input.startAt ? new Date(input.startAt) : undefined,
        endAt: input.endAt ? new Date(input.endAt) : undefined,
      },
    });

    await prisma.auditLog.create({
      data: {
        actorId: user.sub,
        action: "CAMPAIGN_CREATED",
        entity: "Campaign",
        entityId: campaign.id,
      },
    });

    return ok(campaign, { status: 201 });
  } catch (error) {
    return handleApiError(error);
  }
}
