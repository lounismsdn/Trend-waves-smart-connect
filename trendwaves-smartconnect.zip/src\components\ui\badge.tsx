import * as React from "react";
import { cn } from "@/lib/utils";

type BadgeVariant = "default" | "success" | "warning" | "danger" | "muted" | "cyan";

const styles: Record<BadgeVariant, string> = {
  default: "border-[#c2c8d2]/20 bg-white/[0.07] text-slate-200",
  success: "border-[#1500f5]/30 bg-[#1500f5]/15 text-white",
  warning: "border-[#ff7900]/30 bg-[#ff7900]/12 text-[#ffb06b]",
  danger: "border-rose-300/20 bg-rose-300/10 text-rose-200",
  muted: "border-slate-500/20 bg-slate-500/10 text-slate-300",
  cyan: "border-[#ff7900]/30 bg-[#ff7900]/12 text-[#ffb06b]",
};

export function Badge({
  className,
  variant = "default",
  ...props
}: React.HTMLAttributes<HTMLSpanElement> & { variant?: BadgeVariant }) {
  return (
    <span
      className={cn("inline-flex items-center rounded-full border px-2.5 py-1 text-xs font-medium", styles[variant], className)}
      {...props}
    />
  );
}
