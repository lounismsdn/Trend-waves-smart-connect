import { AppShell } from "@/components/smartconnect/app-shell";
import { ClientPortalView } from "@/components/smartconnect/views";
import { requirePageAuth } from "@/lib/server-auth";

export default async function ClientPortalPage() {
  await requirePageAuth("/client-portal");

  return (
    <AppShell>
      <ClientPortalView />
    </AppShell>
  );
}
