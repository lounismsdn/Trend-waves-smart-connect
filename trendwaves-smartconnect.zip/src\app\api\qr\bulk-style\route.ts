import { NextRequest } from "next/server";
import { Prisma } from "@prisma/client";
import { fail, guardRateLimit, handleApiError, ok } from "@/lib/api";
import { getAuthUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { checksumDesign, validateQrStyleReliability } from "@/lib/qr-style";
import { qrBulkStyleSchema } from "@/lib/validation";

export const runtime = "nodejs";

export async function POST(request: NextRequest) {
  const limited = guardRateLimit(request, "qr:bulk-style", 40);
  if (limited) return limited;

  try {
    const user = await getAuthUser(request);
    if (!user) return fail("Unauthorized", 401);

    const input = qrBulkStyleSchema.parse(await request.json());
    const reliability = validateQrStyleReliability(input.design);
    if (!reliability.valid) return fail("QR style is not export-safe", 422, reliability);

    const results = await prisma.$transaction(async (tx) => {
      const currentAssets = await tx.qrCode.findMany({
        where: {
          id: { in: input.qrCodeIds },
          ...(user.role === "CLIENT" && user.clientId ? { clientId: user.clientId } : {}),
        },
      });

      const updates = [];
      for (const asset of currentAssets) {
        const nextVersion = asset.designVersion + 1;
        const updated = await tx.qrCode.update({
          where: { id: asset.id },
          data: {
            design: input.design as Prisma.InputJsonValue,
            designVersion: nextVersion,
            designChecksum: checksumDesign(input.design),
          },
        });
        await tx.qrDesignVersion.create({
          data: {
            qrCodeId: asset.id,
            version: nextVersion,
            design: input.design as Prisma.InputJsonValue,
            changes: (input.changes ?? { bulkApplied: true }) as Prisma.InputJsonValue,
            editorId: user.sub,
          },
        });
        updates.push(updated);
      }

      return updates;
    });

    return ok({ updated: results.length, assets: results, reliability });
  } catch (error) {
    return handleApiError(error);
  }
}
