import { existsSync, readFileSync } from "node:fs";
import { PrismaClient } from "@prisma/client";

const requiredEnv = ["DATABASE_URL", "DIRECT_URL", "JWT_SECRET", "APP_URL"];
const envFiles = [".env", ".env.local"];

function parseEnvFile(path) {
  if (!existsSync(path)) return {};

  return Object.fromEntries(
    readFileSync(path, "utf8")
      .split(/\r?\n/)
      .map((line) => line.trim())
      .filter((line) => line && !line.startsWith("#"))
      .map((line) => {
        const index = line.indexOf("=");
        const key = line.slice(0, index);
        const value = line.slice(index + 1).replace(/^"|"$/g, "");
        return [key, value];
      }),
  );
}

function checkEnv() {
  const report = [];

  for (const file of envFiles) {
    const env = parseEnvFile(file);
    const missing = requiredEnv.filter((key) => !env[key]);
    const hasPlaceholder = Object.values(env).some((value) => value.includes("YOUR_PASSWORD"));

    report.push({ file, missing, hasPlaceholder });
  }

  return report;
}

async function main() {
  const envReport = checkEnv();
  const envFailed = envReport.some((item) => item.missing.length || item.hasPlaceholder);

  console.log("Environment files");
  for (const item of envReport) {
    console.log(
      `- ${item.file}: ${item.missing.length ? `missing ${item.missing.join(", ")}` : "ok"}${
        item.hasPlaceholder ? " (placeholder password still present)" : ""
      }`,
    );
  }

  if (envFailed) {
    process.exitCode = 1;
    return;
  }

  const prisma = new PrismaClient();

  try {
    const [users, clients, campaigns, qrCodes, nfcTags, scanEvents, migrations] = await Promise.all([
      prisma.user.count(),
      prisma.client.count(),
      prisma.campaign.count(),
      prisma.qrCode.count(),
      prisma.nfcTag.count(),
      prisma.scanEvent.count(),
      prisma.$queryRaw`select migration_name from "_prisma_migrations" order by finished_at desc limit 1`,
    ]);

    console.log("Database");
    console.log(`- users: ${users}`);
    console.log(`- clients: ${clients}`);
    console.log(`- campaigns: ${campaigns}`);
    console.log(`- QR codes: ${qrCodes}`);
    console.log(`- NFC tags: ${nfcTags}`);
    console.log(`- scan events: ${scanEvents}`);
    console.log(`- latest migration: ${migrations[0]?.migration_name ?? "none"}`);

    if (!users || !clients || !campaigns || !qrCodes || !nfcTags) {
      process.exitCode = 1;
    }
  } finally {
    await prisma.$disconnect();
  }
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
