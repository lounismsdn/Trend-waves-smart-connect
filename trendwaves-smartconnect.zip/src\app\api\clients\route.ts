import { NextRequest } from "next/server";
import { Prisma } from "@prisma/client";
import { fail, guardRateLimit, handleApiError, ok, parseBody } from "@/lib/api";
import { getAuthUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { clientSchema } from "@/lib/validation";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const limited = guardRateLimit(request, "clients:list", 240);
  if (limited) return limited;

  try {
    const user = await getAuthUser(request);
    if (!user) return fail("Unauthorized", 401);

    const clients = await prisma.client.findMany({
      orderBy: { updatedAt: "desc" },
      include: { campaigns: true, qrCodes: true, nfcTags: true },
    });

    return ok(clients);
  } catch (error) {
    return handleApiError(error);
  }
}

export async function POST(request: NextRequest) {
  const limited = guardRateLimit(request, "clients:create", 120);
  if (limited) return limited;

  try {
    const user = await getAuthUser(request);
    if (!user) return fail("Unauthorized", 401);

    const input = await parseBody(request, clientSchema);
    const client = await prisma.client.create({
      data: {
        ...input,
        branding: input.branding as Prisma.InputJsonValue | undefined,
        permissions: input.permissions as Prisma.InputJsonValue | undefined,
        settings: input.settings as Prisma.InputJsonValue | undefined,
      },
    });

    await prisma.auditLog.create({
      data: {
        actorId: user.sub,
        action: "CLIENT_CREATED",
        entity: "Client",
        entityId: client.id,
      },
    });

    return ok(client, { status: 201 });
  } catch (error) {
    return handleApiError(error);
  }
}
