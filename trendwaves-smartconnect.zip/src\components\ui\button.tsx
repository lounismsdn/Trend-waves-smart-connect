"use client";

import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-full text-sm font-medium transition-all duration-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#1500f5]/60 disabled:pointer-events-none disabled:opacity-50",
  {
    variants: {
      variant: {
        default:
          "bg-white text-[#050505] shadow-[0_0_28px_rgba(255,255,255,0.16)] hover:bg-[#c2c8d2]",
        secondary:
          "border border-[#c2c8d2]/20 bg-white/[0.07] text-white hover:border-[#1500f5]/60 hover:bg-white/[0.12]",
        ghost: "text-slate-300 hover:bg-white/[0.07] hover:text-white",
        accent:
          "bg-[#ff7900] text-[#050505] shadow-[0_0_32px_rgba(255,121,0,0.24)] hover:bg-[#ff9a32]",
        destructive: "bg-rose-500/90 text-white hover:bg-rose-400",
      },
      size: {
        default: "h-11 px-5",
        sm: "h-9 px-4 text-xs",
        icon: "h-10 w-10",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  },
);

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean;
}

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button";

    return <Comp className={cn(buttonVariants({ variant, size, className }))} ref={ref} {...props} />;
  },
);

Button.displayName = "Button";

export { buttonVariants };
