"use client";

import { motion } from "framer-motion";
import {
  BarChart3,
  Bell,
  BriefcaseBusiness,
  ChevronRight,
  Command,
  LayoutDashboard,
  LogOut,
  Menu,
  Paintbrush,
  Plus,
  QrCode,
  Search,
  ShieldCheck,
  SmartphoneNfc,
  UserRoundCog,
} from "lucide-react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import * as React from "react";
import { Toaster, toast } from "sonner";
import { TrendWavesLogo } from "@/components/smartconnect/brand-logo";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { cn } from "@/lib/utils";

const navItems = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/qr-manager", label: "QR Manager", icon: QrCode },
  { href: "/nfc-manager", label: "NFC Manager", icon: SmartphoneNfc },
  { href: "/analytics", label: "Analytics", icon: BarChart3 },
  { href: "/campaigns", label: "Campaigns", icon: BriefcaseBusiness },
  { href: "/qr/customizer", label: "QR Customizer", icon: Paintbrush },
  { href: "/client", label: "Client Dashboard", icon: UserRoundCog },
  { href: "/client-portal", label: "Client Portal", icon: UserRoundCog },
];

const categories = [
  { label: "Website", value: "WEBSITE" },
  { label: "Menu", value: "MENU" },
  { label: "Instagram / Social", value: "INSTAGRAM_SOCIAL" },
  { label: "WhatsApp", value: "WHATSAPP" },
  { label: "PDF", value: "PDF" },
  { label: "Google Maps", value: "GOOGLE_MAPS" },
  { label: "Custom landing page", value: "CUSTOM_LANDING_PAGE" },
];

function BrandMark() {
  return (
    <Link href="/dashboard" className="group flex items-center gap-3">
      <div className="relative grid h-11 w-20 place-items-center rounded-2xl border border-[#c2c8d2]/20 bg-white px-2 shadow-[0_0_32px_rgba(21,0,245,0.16)]">
        <TrendWavesLogo withText={false} withTm={false} tone="blue" markClassName="h-7 w-16 transition group-hover:scale-105" />
      </div>
      <div>
        <p className="font-display text-sm font-black uppercase leading-none tracking-[0.08em] text-white">
          Trend waves
        </p>
        <p className="mt-1 text-xs text-[#c2c8d2]/70">SmartConnect OS</p>
      </div>
    </Link>
  );
}

function Sidebar() {
  const pathname = usePathname();

  return (
    <aside className="fixed inset-y-0 left-0 z-40 hidden w-72 border-r border-[#c2c8d2]/20 bg-[#050505]/86 p-5 backdrop-blur-2xl lg:flex lg:flex-col">
      <BrandMark />
      <nav className="mt-9 space-y-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          const active = pathname === item.href || (item.href === "/qr/customizer" && pathname === "/qr-customizer");

          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "group flex items-center justify-between rounded-2xl px-3 py-3 text-sm transition",
                active
                  ? "bg-white text-[#050505] shadow-[0_16px_40px_rgba(255,255,255,0.1)]"
                  : "text-slate-400 hover:bg-white/[0.07] hover:text-white",
              )}
            >
              <span className="flex items-center gap-3">
                <Icon className="h-4 w-4" />
                {item.label}
              </span>
              {active ? <ChevronRight className="h-4 w-4" /> : null}
            </Link>
          );
        })}
      </nav>

      <div className="mt-auto rounded-[18px] border border-[#c2c8d2]/20 bg-white/[0.055] p-4">
        <div className="mb-4 flex items-center justify-between">
          <Badge variant="cyan">Enterprise</Badge>
          <ShieldCheck className="h-4 w-4 text-[#ff7900]" />
        </div>
        <p className="font-display text-sm font-bold text-white">Signed redirects active</p>
        <p className="mt-2 text-xs leading-5 text-slate-400">
          Rate limits, audit logs, and fraud signals are wired into the platform API.
        </p>
      </div>
    </aside>
  );
}

function MobileNav() {
  const pathname = usePathname();

  return (
    <div className="fixed inset-x-3 bottom-3 z-50 rounded-[22px] border border-[#c2c8d2]/20 bg-[#050505]/90 p-2 shadow-2xl backdrop-blur-xl lg:hidden">
      <div className="grid grid-cols-4 gap-1">
        {navItems.slice(0, 4).map((item) => {
          const Icon = item.icon;
          const active = pathname === item.href;

          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex h-12 flex-col items-center justify-center gap-1 rounded-2xl text-[10px] transition",
                active ? "bg-white text-[#050505]" : "text-slate-400",
              )}
            >
              <Icon className="h-4 w-4" />
              {item.label.split(" ")[0]}
            </Link>
          );
        })}
      </div>
    </div>
  );
}

function GeneratorModal() {
  const [open, setOpen] = React.useState(false);
  const [loading, setLoading] = React.useState(false);
  const [category, setCategory] = React.useState("WEBSITE");

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setLoading(true);

    const formData = new FormData(event.currentTarget);
    const payload = {
      name: String(formData.get("name")),
      destinationUrl: String(formData.get("destinationUrl")),
      category,
    };

    try {
      const response = await fetch("/api/qr/create", {
        method: "POST",
        headers: { "content-type": "application/json" },
        credentials: "include",
        body: JSON.stringify(payload),
      });
      const body = await response.json();

      if (!response.ok) {
        throw new Error(body.error ?? "Could not create QR");
      }

      toast.success("Dynamic QR created", {
        description: body.data?.shortUrl ?? "The asset is ready for design, export, and client assignment.",
      });
      window.dispatchEvent(new CustomEvent("smartconnect:qr-created", { detail: body.data }));
      setOpen(false);
    } catch (caught) {
      toast.error("QR creation failed", {
        description: caught instanceof Error ? caught.message : "Check the destination URL and try again.",
      });
    } finally {
      setLoading(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="fixed bottom-24 right-5 z-40 lg:bottom-7" variant="accent">
          <Plus className="h-4 w-4" />
          New asset
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Generate dynamic QR</DialogTitle>
          <DialogDescription>
            Create a short-link backed QR asset that can be edited after distribution.
          </DialogDescription>
        </DialogHeader>
        <form className="mt-6 space-y-4" onSubmit={submit}>
          <Input name="name" placeholder="Campaign or asset name" required />
          <Input name="destinationUrl" placeholder="Destination URL" type="url" required />
          <Select name="category" value={category} onValueChange={setCategory}>
            <SelectTrigger className="w-full">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {categories.map((category) => (
                <SelectItem key={category.value} value={category.value}>
                  {category.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <div className="grid gap-3 sm:grid-cols-2">
            <Button variant="secondary" type="button" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={loading}>
              {loading ? "Generating..." : "Generate draft"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}

export function AppShell({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const [user, setUser] = React.useState<{ name: string; role: string; email: string } | null>(null);
  const [globalSearch, setGlobalSearch] = React.useState("");
  const [notificationItems, setNotificationItems] = React.useState<
    Array<{ id: string; title: string; message: string; severity: string; read: boolean }>
  >([]);

  React.useEffect(() => {
    fetch("/api/auth/me", { credentials: "include" })
      .then((response) => (response.ok ? response.json() : null))
      .then((body) => {
        if (body?.data) setUser(body.data);
      })
      .catch(() => undefined);

    fetch("/api/notifications", { credentials: "include" })
      .then((response) => (response.ok ? response.json() : null))
      .then((body) => {
        if (Array.isArray(body?.data)) setNotificationItems(body.data);
      })
      .catch(() => undefined);
  }, []);

  async function logout() {
    await fetch("/api/auth/logout", { method: "POST", credentials: "include" });
    router.push("/login");
    router.refresh();
  }

  function submitGlobalSearch(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    router.push(`/qr-manager?search=${encodeURIComponent(globalSearch)}`);
    toast.success("Search opened in QR Manager", { description: globalSearch || "Showing all assets." });
  }

  async function markNotificationsRead() {
    if (notificationItems.length === 0) return;
    await fetch("/api/notifications", {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ ids: notificationItems.map((item) => item.id), read: true }),
    });
    setNotificationItems((items) => items.map((item) => ({ ...item, read: true })));
    toast.success("Notifications marked as read");
  }

  return (
    <div className="min-h-screen overflow-hidden bg-[#050505] text-white">
      <Toaster theme="dark" position="top-right" richColors />
      <div className="pointer-events-none fixed inset-0 wave-field opacity-80" />
      <div className="pointer-events-none fixed inset-0 bg-[radial-gradient(circle_at_10%_10%,rgba(21,0,245,0.18),transparent_30%),radial-gradient(circle_at_90%_20%,rgba(255,121,0,0.10),transparent_28%),linear-gradient(180deg,rgba(255,255,255,0.04),transparent_35%)]" />

      <Sidebar />
      <MobileNav />

      <div className="relative z-10 lg:pl-72">
        <header className="sticky top-0 z-30 border-b border-[#c2c8d2]/20 bg-[#050505]/76 px-4 py-4 backdrop-blur-2xl sm:px-6">
          <div className="mx-auto flex max-w-7xl items-center gap-4">
            <div className="lg:hidden">
              <Button size="icon" variant="secondary" aria-label="Menu" onClick={() => toast.success("Use the bottom navigation to switch pages")}>
                <Menu className="h-4 w-4" />
              </Button>
            </div>
            <div className="hidden lg:block">
              <p className="text-xs uppercase tracking-[0.22em] text-slate-500">Agency command center</p>
              <TrendWavesLogo tone="white" markClassName="hidden" textClassName="text-xl" />
            </div>
            <form onSubmit={submitGlobalSearch} className="ml-auto hidden min-w-0 flex-1 max-w-md items-center gap-2 rounded-full border border-[#c2c8d2]/20 bg-white/[0.055] px-4 py-2 text-slate-400 md:flex">
              <Search className="h-4 w-4 shrink-0" />
              <input
                className="min-w-0 flex-1 bg-transparent text-sm text-white outline-none placeholder:text-slate-500"
                placeholder="Search campaigns, clients, assets, tags"
                value={globalSearch}
                onChange={(event) => setGlobalSearch(event.target.value)}
              />
              <button type="submit" aria-label="Submit global search" className="ml-auto">
                <Command className="h-4 w-4" />
              </button>
            </form>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button size="icon" variant="secondary" aria-label="Notifications" className="relative">
                  <Bell className="h-4 w-4" />
                  {notificationItems.some((item) => !item.read) ? (
                    <span className="absolute right-2 top-2 h-2 w-2 rounded-full bg-[#ff7900]" />
                  ) : null}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <div className="px-3 pb-2 pt-1">
                  <p className="font-display text-sm font-bold">Notification center</p>
                  <p className="text-xs text-slate-500">Spikes, links, expirations</p>
                </div>
                {notificationItems.length > 0 ? (
                  notificationItems.map((note) => (
                    <DropdownMenuItem key={note.id} className={note.read ? "opacity-70" : ""}>
                      <span className="flex flex-col">
                        <span>{note.title}</span>
                        <span className="text-xs text-slate-500">{note.message}</span>
                      </span>
                    </DropdownMenuItem>
                  ))
                ) : (
                  <DropdownMenuItem>No active notifications</DropdownMenuItem>
                )}
                {notificationItems.length > 0 ? (
                  <DropdownMenuItem onSelect={markNotificationsRead}>Mark all as read</DropdownMenuItem>
                ) : null}
              </DropdownMenuContent>
            </DropdownMenu>
            <Button variant="secondary" className="hidden sm:inline-flex" onClick={() => router.push("/client")}>
              {user ? `${user.name} · ${user.role}` : "Client mode"}
            </Button>
            <Button size="icon" variant="secondary" aria-label="Log out" onClick={logout}>
              <LogOut className="h-4 w-4" />
            </Button>
          </div>
        </header>

        <motion.main
          className="mx-auto max-w-7xl px-4 pb-28 pt-6 sm:px-6 lg:pb-10"
          initial={{ opacity: 0, y: 18 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45, ease: "easeOut" }}
        >
          {children}
        </motion.main>
      </div>

      <GeneratorModal />
    </div>
  );
}
