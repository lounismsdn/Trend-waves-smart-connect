import PDFDocument from "pdfkit";
import { NextRequest } from "next/server";
import { fail, guardRateLimit, handleApiError } from "@/lib/api";
import { getAuthUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export const runtime = "nodejs";

type RouteContext = { params: Promise<{ id: string }> };

function escapeCsv(value: unknown) {
  return `"${String(value ?? "").replaceAll('"', '""')}"`;
}

async function pdfBuffer(assetName: string, rows: string[][]) {
  const doc = new PDFDocument({ margin: 48, size: "A4" });
  const chunks: Buffer[] = [];

  doc.on("data", (chunk: Buffer) => chunks.push(chunk));
  const done = new Promise<Buffer>((resolve) => {
    doc.on("end", () => resolve(Buffer.concat(chunks)));
  });

  doc.fontSize(22).text("Trend Waves SmartConnect", { continued: false });
  doc.moveDown(0.4).fontSize(14).fillColor("#444").text(`${assetName} analytics export`);
  doc.moveDown();

  rows.slice(0, 40).forEach((row, index) => {
    doc.fillColor(index === 0 ? "#1500f5" : "#111").fontSize(index === 0 ? 10 : 9).text(row.join("  |  "));
    doc.moveDown(0.35);
  });

  doc.end();
  return done;
}

export async function GET(request: NextRequest, context: RouteContext) {
  const limited = guardRateLimit(request, "qr:analytics-export", 60);
  if (limited) return limited;

  try {
    const user = await getAuthUser(request);
    if (!user) return fail("Unauthorized", 401);

    const { id } = await context.params;
    const format = request.nextUrl.searchParams.get("format") ?? "csv";
    const qrCode = await prisma.qrCode.findUnique({ where: { id } });
    if (!qrCode) return fail("QR code not found", 404);
    if (user.role === "CLIENT" && user.clientId && qrCode.clientId !== user.clientId) return fail("Forbidden", 403);

    const events = await prisma.scanEvent.findMany({
      where: { qrCodeId: id },
      orderBy: { createdAt: "desc" },
      take: 1000,
    });

    const rows = [
      ["Timestamp", "City", "Country", "Device", "Browser", "Source", "Converted"],
      ...events.map((event) => [
        event.createdAt.toISOString(),
        event.city ?? "Unknown",
        event.country ?? "Unknown",
        event.deviceType ?? "Unknown",
        event.browser ?? "Unknown",
        event.referrer ?? "Direct",
        event.converted ? "Yes" : "No",
      ]),
    ];

    if (format === "pdf") {
      const buffer = await pdfBuffer(qrCode.name, rows);
      return new Response(new Uint8Array(buffer), {
        headers: {
          "content-type": "application/pdf",
          "content-disposition": `attachment; filename="${qrCode.shortId}-analytics.pdf"`,
        },
      });
    }

    return new Response(rows.map((row) => row.map(escapeCsv).join(",")).join("\n"), {
      headers: {
        "content-type": "text/csv",
        "content-disposition": `attachment; filename="${qrCode.shortId}-analytics.csv"`,
      },
    });
  } catch (error) {
    return handleApiError(error);
  }
}
