import { NextRequest } from "next/server";
import { fail, guardRateLimit, handleApiError, ok, parseBody } from "@/lib/api";
import { getAuthUser } from "@/lib/auth";
import { signedNfcRedirectUrl, registerNfcTag } from "@/services/nfc";
import { nfcRegisterSchema } from "@/lib/validation";

export const runtime = "nodejs";

export async function POST(request: NextRequest) {
  const limited = guardRateLimit(request, "nfc:register", 80);
  if (limited) return limited;

  try {
    const user = await getAuthUser(request);
    if (!user) return fail("Unauthorized", 401);

    const input = await parseBody(request, nfcRegisterSchema);
    const nfcTag = await registerNfcTag({ user, input });
    const shortUrl = await signedNfcRedirectUrl(nfcTag.shortId, request.url);

    return ok({ ...nfcTag, shortUrl }, { status: 201 });
  } catch (error) {
    return handleApiError(error);
  }
}
