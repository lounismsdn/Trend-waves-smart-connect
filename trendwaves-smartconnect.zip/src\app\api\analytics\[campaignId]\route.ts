import { NextRequest } from "next/server";
import { fail, guardRateLimit, handleApiError, ok } from "@/lib/api";
import { getAuthUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export const runtime = "nodejs";

type RouteContext = { params: Promise<{ campaignId: string }> };

export async function GET(request: NextRequest, context: RouteContext) {
  const limited = guardRateLimit(request, "analytics:campaign", 240);
  if (limited) return limited;

  try {
    const user = await getAuthUser(request);
    if (!user) return fail("Unauthorized", 401);

    const { campaignId } = await context.params;
    const [campaign, totalScans, devices, locations, recentEvents] = await Promise.all([
      prisma.campaign.findUnique({ where: { id: campaignId }, include: { client: true } }),
      prisma.scanEvent.count({ where: { campaignId } }),
      prisma.scanEvent.groupBy({ by: ["deviceType"], where: { campaignId }, _count: true }),
      prisma.scanEvent.groupBy({ by: ["country", "city"], where: { campaignId }, _count: true }),
      prisma.scanEvent.findMany({ where: { campaignId }, take: 50, orderBy: { createdAt: "desc" } }),
    ]);

    if (!campaign) return fail("Campaign not found", 404);

    return ok({ campaign, totalScans, devices, locations, recentEvents });
  } catch (error) {
    return handleApiError(error);
  }
}
