"use client";

/* eslint-disable @next/next/no-img-element */

import { motion } from "framer-motion";
import {
  BarChart3,
  CalendarDays,
  CheckCircle2,
  Copy,
  Download,
  ExternalLink,
  Eye,
  FileDown,
  Filter,
  Grid3X3,
  Layers3,
  List,
  Lock,
  MousePointerClick,
  Palette,
  Pause,
  Pencil,
  Play,
  Plus,
  QrCode,
  RadioTower,
  RefreshCw,
  Search,
  Sparkles,
  SmartphoneNfc,
  Trash2,
  Upload,
  Users,
} from "lucide-react";
import QRCode from "qrcode";
import { useRouter, useSearchParams } from "next/navigation";
import * as React from "react";
import { toast } from "sonner";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  campaignComparison,
  campaigns,
  clientPortalItems,
  dailyScans,
  deviceData,
  locationData,
  metrics,
  nfcTags,
  performance,
  qrAssets,
  recentActivity,
} from "@/lib/mock-data";
import { TrendWavesLogo } from "@/components/smartconnect/brand-logo";
import { cn, currency, formatNumber } from "@/lib/utils";

const chartColors = ["#1500f5", "#ff7900", "#f8fafc", "#c2c8d2"];
type QrAsset = (typeof qrAssets)[number];
type NfcTag = (typeof nfcTags)[number] & {
  id?: string;
  shortId?: string;
  shortUrl?: string;
  destinationUrl?: string;
  operationalStatus?: string;
  writtenPayload?: string | null;
  isLocked?: boolean;
  isWritable?: boolean;
};

type SmartQrAsset = QrAsset & {
  rawCategory: string;
  rawStatus: "ACTIVE" | "PAUSED" | "ARCHIVED" | "EXPIRED";
  uniqueScans: number;
  shortUrl: string;
  createdAt: string;
  lastScanAt: string | null;
  campaign: string;
};

type QrFormMode = "create" | "edit";

type QrApiAsset = {
  id: string;
  name: string;
  category: string;
  destinationUrl: string;
  scanCount: number;
  uniqueVisitors?: number;
  status: string;
  shortId: string;
  createdAt?: string;
  lastScanAt?: string | null;
  shortUrl?: string;
  client?: { name?: string } | null;
  campaign?: { name?: string } | null;
};

const qrCategoryOptions = [
  { label: "Website", value: "WEBSITE" },
  { label: "Menu", value: "MENU" },
  { label: "Instagram", value: "INSTAGRAM_SOCIAL" },
  { label: "WhatsApp", value: "WHATSAPP" },
  { label: "PDF", value: "PDF" },
  { label: "Google Maps", value: "GOOGLE_MAPS" },
  { label: "Custom landing", value: "CUSTOM_LANDING_PAGE" },
];

function categoryLabel(category: string) {
  return category
    .replace("INSTAGRAM_SOCIAL", "Instagram")
    .replace("GOOGLE_MAPS", "Google Maps")
    .replace("CUSTOM_LANDING_PAGE", "Custom landing")
    .replaceAll("_", " ")
    .toLowerCase()
    .replace(/\b\w/g, (letter) => letter.toUpperCase());
}

function statusLabel(status: string) {
  return status.toLowerCase().replace(/\b\w/g, (letter) => letter.toUpperCase());
}

function rawCategoryFromLabel(category: string) {
  const normalized = category.toUpperCase().replaceAll(" / ", "_").replaceAll(" ", "_");
  if (normalized === "INSTAGRAM" || normalized === "SOCIAL_MEDIA") return "INSTAGRAM_SOCIAL";
  if (normalized === "CUSTOM_LANDING") return "CUSTOM_LANDING_PAGE";
  return normalized;
}

function normalizeAsset(asset: Partial<SmartQrAsset> & QrAsset): SmartQrAsset {
  const rawCategory = asset.rawCategory ?? rawCategoryFromLabel(asset.category);
  const rawStatus = (asset.rawStatus ?? asset.status.toUpperCase()) as SmartQrAsset["rawStatus"];

  return {
    ...asset,
    rawCategory,
    rawStatus,
    uniqueScans: asset.uniqueScans ?? Math.max(Math.floor(asset.scans * 0.72), 1),
    shortUrl: asset.shortUrl ?? `/r/${asset.shortId}`,
    createdAt: asset.createdAt ?? new Date().toISOString(),
    lastScanAt: asset.lastScanAt ?? null,
    campaign: asset.campaign ?? "Unassigned campaign",
  };
}

function assetFromApi(asset: QrApiAsset, fallback?: Partial<SmartQrAsset>): SmartQrAsset {
  return normalizeAsset({
    id: asset.id,
    name: asset.name,
    category: categoryLabel(asset.category),
    rawCategory: asset.category,
    client: asset.client?.name ?? fallback?.client ?? "Unassigned",
    destination: asset.destinationUrl,
    scans: asset.scanCount ?? fallback?.scans ?? 0,
    uniqueScans: asset.uniqueVisitors ?? fallback?.uniqueScans ?? 0,
    status: statusLabel(asset.status ?? "ACTIVE"),
    rawStatus: (asset.status ?? "ACTIVE") as SmartQrAsset["rawStatus"],
    shortId: asset.shortId,
    shortUrl: asset.shortUrl ?? fallback?.shortUrl ?? `/r/${asset.shortId}`,
    createdAt: asset.createdAt ?? fallback?.createdAt ?? new Date().toISOString(),
    lastScanAt: asset.lastScanAt ?? fallback?.lastScanAt ?? null,
    campaign: asset.campaign?.name ?? fallback?.campaign ?? "Unassigned campaign",
  });
}

function sparklineFor(asset: SmartQrAsset) {
  return Array.from({ length: 10 }).map((_, index) => {
    const wave = Math.sin(index * 0.9 + asset.scans * 0.003) * 0.22 + 0.78;
    const lift = 0.64 + index * 0.045;
    return {
      day: index + 1,
      scans: Math.max(3, Math.round((asset.scans / 10) * wave * lift)),
    };
  });
}

function assetTrend(asset: SmartQrAsset) {
  return Math.max(4, Math.min(42, Math.round((asset.uniqueScans / Math.max(asset.scans, 1)) * 28)));
}

function statusVariant(status: string) {
  if (status === "Active") return "success" as const;
  if (status === "Paused") return "warning" as const;
  return "muted" as const;
}

function dateLabel(value?: string | null) {
  if (!value) return "No scans yet";
  return new Intl.DateTimeFormat("en", { month: "short", day: "numeric", year: "numeric" }).format(new Date(value));
}

function downloadBlob(blob: Blob, filename: string) {
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = filename;
  link.click();
  URL.revokeObjectURL(link.href);
}

function downloadText(content: string, filename: string, type = "text/csv") {
  downloadBlob(new Blob([content], { type }), filename);
}

function useLiveMetrics() {
  const [liveMetrics, setLiveMetrics] = React.useState(metrics);

  React.useEffect(() => {
    fetch("/api/analytics/overview", { credentials: "include" })
      .then((response) => (response.ok ? response.json() : null))
      .then((body) => {
        if (!body?.data) return;
        setLiveMetrics([
          { ...metrics[0], value: body.data.qrScans ?? body.data.totalScans ?? metrics[0].value },
          { ...metrics[1], value: body.data.nfcTaps ?? metrics[1].value },
          { ...metrics[2], value: body.data.activeCampaigns ?? metrics[2].value },
          { ...metrics[3], value: body.data.conversionEvents ?? metrics[3].value },
        ]);
      })
      .catch(() => undefined);
  }, []);

  return liveMetrics;
}

function useLiveQrAssets() {
  const [assets, setAssets] = React.useState<SmartQrAsset[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState<string | null>(null);

  const refresh = React.useCallback(async () => {
    setLoading(true);
    setError(null);

    try {
      const response = await fetch("/api/qr", { credentials: "include" });
      const body = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(body.error ?? "Could not load QR assets");
      if (!Array.isArray(body?.data)) throw new Error("QR API returned an unexpected response");
      setAssets(body.data.map((asset: QrApiAsset) => assetFromApi(asset)));
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Could not load QR assets");
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => {
    refresh();

    function addCreatedAsset(event: Event) {
      const asset = (event as CustomEvent<QrApiAsset>).detail;
      if (!asset?.id) return;
      setAssets((current) => [assetFromApi(asset), ...current.filter((item) => item.id !== asset.id)]);
    }

    window.addEventListener("smartconnect:qr-created", addCreatedAsset);
    return () => window.removeEventListener("smartconnect:qr-created", addCreatedAsset);
  }, [refresh]);

  return { assets, setAssets, loading, error, refresh } as const;
}

function useLiveNfcTags() {
  const [tags, setTags] = React.useState<NfcTag[]>(nfcTags);

  React.useEffect(() => {
    fetch("/api/nfc", { credentials: "include" })
      .then((response) => (response.ok ? response.json() : null))
      .then((body) => {
        if (!Array.isArray(body?.data)) return;
        setTags(
          body.data.map((tag: {
            id: string;
            shortId: string;
            shortUrl?: string;
            chipUid: string;
            name: string;
            status: string;
            destinationUrl: string;
            operationalStatus?: string;
            writtenPayload?: string | null;
            isWritable?: boolean;
            isLocked: boolean;
            client?: { name?: string } | null;
            lastTapAt?: string | null;
            tapCount: number;
          }) => ({
            id: tag.id,
            shortId: tag.shortId,
            shortUrl: tag.shortUrl,
            uid: tag.chipUid,
            name: tag.name,
            status: tag.isLocked ? "Locked" : tag.operationalStatus ? statusLabel(tag.operationalStatus) : tag.status === "ACTIVE" ? "Ready" : statusLabel(tag.status),
            destinationUrl: tag.destinationUrl,
            operationalStatus: tag.operationalStatus,
            writtenPayload: tag.writtenPayload,
            isLocked: tag.isLocked,
            isWritable: tag.isWritable,
            client: tag.client?.name ?? "Unassigned",
            lastTap: tag.lastTapAt ? new Date(tag.lastTapAt).toLocaleDateString() : "No taps yet",
            taps: tag.tapCount,
          })),
        );
      })
      .catch(() => undefined);
  }, []);

  return [tags, setTags] as const;
}

function CountUp({ value }: { value: number }) {
  const [count, setCount] = React.useState(0);

  React.useEffect(() => {
    const duration = 900;
    const startedAt = performanceNow();
    let frame = 0;

    function performanceNow() {
      return window.performance.now();
    }

    function tick(now: number) {
      const progress = Math.min((now - startedAt) / duration, 1);
      setCount(Math.floor(value * (1 - Math.pow(1 - progress, 3))));
      if (progress < 1) {
        frame = requestAnimationFrame(tick);
      }
    }

    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [value]);

  return <>{formatNumber(count)}</>;
}

function PageHeader({
  eyebrow,
  title,
  description,
  action,
}: {
  eyebrow: string;
  title: string;
  description: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="mb-7 flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
      <div className="max-w-3xl">
        <p className="mb-3 text-xs font-semibold uppercase tracking-[0.28em] text-[#ff7900]">{eyebrow}</p>
        <h2 className="font-display text-3xl font-black leading-tight text-white sm:text-4xl lg:text-5xl">
          {title}
        </h2>
        <p className="mt-4 max-w-2xl text-sm leading-6 text-slate-400 sm:text-base">{description}</p>
      </div>
      {action}
    </div>
  );
}

function MetricCard({ metric, index }: { metric: (typeof metrics)[number]; index: number }) {
  const Icon = metric.icon;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.08, duration: 0.45 }}
    >
      <Card className="group overflow-hidden">
        <CardContent className="p-5">
          <div className="mb-8 flex items-start justify-between">
            <div className="grid h-11 w-11 place-items-center rounded-2xl border border-white/10 bg-white/[0.07]">
              <Icon className="h-5 w-5 text-[#ff7900]" />
            </div>
            <Badge variant="success">{metric.delta}</Badge>
          </div>
          <p className="text-sm text-slate-400">{metric.label}</p>
          <p className="mt-2 font-display text-3xl font-black text-white">
            <CountUp value={metric.value} />
          </p>
          <div className="mt-4 h-1 overflow-hidden rounded-full bg-white/10">
            <motion.div
              className="h-full rounded-full bg-gradient-to-r from-[#1500f5] to-[#ff7900]"
              initial={{ width: 0 }}
              animate={{ width: `${65 + index * 7}%` }}
              transition={{ delay: 0.3, duration: 0.8 }}
            />
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

function ChartTooltip({
  active,
  payload,
  label,
}: {
  active?: boolean;
  payload?: Array<{ name: string; value: number; color?: string }>;
  label?: string;
}) {
  if (!active || !payload?.length) return null;

  return (
    <div className="rounded-2xl border border-white/10 bg-slate-950/95 p-3 shadow-2xl">
      <p className="mb-2 text-xs text-slate-400">{label}</p>
      {payload.map((item) => (
        <p key={item.name} className="text-sm text-white">
          <span style={{ color: item.color }}>{item.name}</span>: {formatNumber(item.value)}
        </p>
      ))}
    </div>
  );
}

function ChartFrame({
  className,
  children,
}: {
  className: string;
  children: React.ReactNode;
}) {
  const ref = React.useRef<HTMLDivElement | null>(null);
  const [ready, setReady] = React.useState(false);

  React.useEffect(() => {
    const node = ref.current;
    if (!node) return;

    const update = () => {
      const box = node.getBoundingClientRect();
      setReady(box.width > 0 && box.height > 0);
    };

    const timer = window.setTimeout(update, 80);
    const observer = new ResizeObserver(update);
    observer.observe(node);
    return () => {
      window.clearTimeout(timer);
      observer.disconnect();
    };
  }, []);

  return (
    <div ref={ref} className={className}>
      {ready ? children : <Skeleton className="h-full w-full" />}
    </div>
  );
}

function DashboardPerformanceGraph() {
  const ref = React.useRef<HTMLDivElement | null>(null);
  const [width, setWidth] = React.useState(0);

  React.useEffect(() => {
    const node = ref.current;
    if (!node) return;

    const update = () => setWidth(Math.floor(node.getBoundingClientRect().width));
    const timer = window.setTimeout(update, 100);
    const observer = new ResizeObserver(update);
    observer.observe(node);
    return () => {
      window.clearTimeout(timer);
      observer.disconnect();
    };
  }, []);

  return (
    <div ref={ref} className="h-[330px] min-w-0">
      {width > 0 ? (
        <AreaChart width={width} height={330} data={performance}>
          <defs>
            <linearGradient id="scans" x1="0" x2="0" y1="0" y2="1">
              <stop offset="0%" stopColor="#1500f5" stopOpacity={0.45} />
              <stop offset="100%" stopColor="#1500f5" stopOpacity={0} />
            </linearGradient>
            <linearGradient id="taps" x1="0" x2="0" y1="0" y2="1">
              <stop offset="0%" stopColor="#ff7900" stopOpacity={0.35} />
              <stop offset="100%" stopColor="#ff7900" stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid stroke="rgba(255,255,255,0.07)" vertical={false} />
          <XAxis dataKey="day" stroke="#64748b" tickLine={false} axisLine={false} />
          <YAxis stroke="#64748b" tickLine={false} axisLine={false} />
          <Tooltip content={<ChartTooltip />} />
          <Area type="monotone" dataKey="scans" stroke="#1500f5" fill="url(#scans)" strokeWidth={3} />
          <Area type="monotone" dataKey="taps" stroke="#ff7900" fill="url(#taps)" strokeWidth={3} />
          <Line type="monotone" dataKey="conversions" stroke="#ffffff" strokeWidth={2} />
        </AreaChart>
      ) : (
        <Skeleton className="h-full w-full" />
      )}
    </div>
  );
}

export function DashboardView() {
  const router = useRouter();
  const liveMetrics = useLiveMetrics();

  function exportReport() {
    const rows = [
      ["Metric", "Value", "Delta"],
      ...liveMetrics.map((metric) => [metric.label, String(metric.value), metric.delta]),
    ];
    downloadText(rows.map((row) => row.map((value) => `"${value.replaceAll('"', '""')}"`).join(",")).join("\n"), "trendwaves-dashboard-report.csv");
    toast.success("Dashboard report exported");
  }

  return (
    <div>
      <PageHeader
        eyebrow="Real-time command"
        title="Dynamic QR and NFC performance, shaped for agency speed."
        description="Monitor short-link redirects, campaign lift, NFC activations, broken destinations, and conversion signals from one premium operating surface."
        action={
          <div className="flex gap-3">
            <Button variant="secondary" onClick={exportReport}>
              <FileDown className="h-4 w-4" />
              Export report
            </Button>
            <Button onClick={() => router.push("/campaigns")}>
              <Plus className="h-4 w-4" />
              New campaign
            </Button>
          </div>
        }
      />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {liveMetrics.map((metric, index) => (
          <MetricCard key={metric.label} metric={metric} index={index} />
        ))}
      </div>

      <div className="mt-5 grid gap-5 xl:grid-cols-[1.55fr_0.9fr]">
        <Card>
          <CardHeader className="flex-row items-center justify-between">
            <div>
              <CardTitle>Performance graph</CardTitle>
              <CardDescription>Scans, NFC taps, and conversion events this week</CardDescription>
            </div>
            <Badge variant="cyan">Live</Badge>
          </CardHeader>
          <CardContent>
            <DashboardPerformanceGraph />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Recent activity</CardTitle>
            <CardDescription>Operational signals from QR, NFC, and link monitoring</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {recentActivity.map((item) => {
              const Icon = item.icon;

              return (
                <div key={item.title} className="rounded-[18px] border border-white/10 bg-white/[0.045] p-4">
                  <div className="mb-3 flex items-center gap-3">
                    <span className="grid h-9 w-9 place-items-center rounded-2xl bg-[#1500f5]/15 text-white">
                      <Icon className="h-4 w-4" />
                    </span>
                    <div>
                      <p className="font-medium text-white">{item.title}</p>
                      <p className="text-xs text-slate-500">{item.time}</p>
                    </div>
                  </div>
                  <p className="text-sm leading-5 text-slate-400">{item.detail}</p>
                </div>
              );
            })}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function MiniSparkline({ asset }: { asset: SmartQrAsset }) {
  const data = sparklineFor(asset);
  const values = data.map((item) => item.scans);
  const min = Math.min(...values);
  const max = Math.max(...values);
  const range = Math.max(max - min, 1);
  const points = data
    .map((item, index) => {
      const x = (index / Math.max(data.length - 1, 1)) * 100;
      const y = 42 - ((item.scans - min) / range) * 34;
      return `${x.toFixed(2)},${y.toFixed(2)}`;
    })
    .join(" ");
  const areaPoints = `0,48 ${points} 100,48`;

  return (
    <svg className="pointer-events-none h-12 w-full overflow-visible" viewBox="0 0 100 48" preserveAspectRatio="none" aria-label={`${asset.name} scan sparkline`}>
      <polygon points={areaPoints} fill="rgba(255,121,0,0.12)" />
      <polyline points={points} fill="none" stroke="#ff7900" strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" vectorEffect="non-scaling-stroke" />
    </svg>
  );
}

function QrTrendChart({ data }: { data: Array<{ day: number; scans: number; unique: number }> }) {
  const max = Math.max(...data.flatMap((item) => [item.scans, item.unique]), 1);

  function pointsFor(key: "scans" | "unique") {
    return data.map((item, index) => {
      const x = (index / Math.max(data.length - 1, 1)) * 100;
      const y = 54 - (item[key] / max) * 46;
      return { x, y };
    });
  }

  function pathFor(points: Array<{ x: number; y: number }>) {
    return points.map((point, index) => `${index === 0 ? "M" : "L"} ${point.x.toFixed(2)} ${point.y.toFixed(2)}`).join(" ");
  }

  const scanPoints = pointsFor("scans");
  const uniquePoints = pointsFor("unique");
  const scanPath = pathFor(scanPoints);
  const areaPath = `${scanPath} L 100 60 L 0 60 Z`;

  return (
    <div className="flex h-full w-full flex-col rounded-[18px] border border-white/10 bg-white/[0.035] p-4">
      <svg className="min-h-0 w-full flex-1 overflow-visible" viewBox="0 0 100 60" preserveAspectRatio="none" aria-label="Daily scans and unique visitors">
        {[12, 24, 36, 48].map((y) => (
          <line key={y} x1="0" x2="100" y1={y} y2={y} stroke="rgba(255,255,255,0.08)" strokeWidth="1" vectorEffect="non-scaling-stroke" />
        ))}
        <path d={areaPath} fill="rgba(21,0,245,0.18)" />
        <path d={scanPath} fill="none" stroke="#1500f5" strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" vectorEffect="non-scaling-stroke" />
        <path d={pathFor(uniquePoints)} fill="none" stroke="#ff7900" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" vectorEffect="non-scaling-stroke" />
      </svg>
      <div className="mt-2 flex items-center gap-4 text-xs text-slate-400">
        <span className="inline-flex items-center gap-2"><span className="h-2 w-2 rounded-full bg-[#1500f5]" />Scans</span>
        <span className="inline-flex items-center gap-2"><span className="h-2 w-2 rounded-full bg-[#ff7900]" />Unique</span>
      </div>
    </div>
  );
}

function QrPreview({ value, refreshKey = 0, className }: { value: string; refreshKey?: number; className?: string }) {
  const [src, setSrc] = React.useState("");

  React.useEffect(() => {
    let active = true;
    QRCode.toDataURL(value || "https://trendwaves.app/r/demo", {
      margin: 2,
      width: 900,
      color: { dark: "#050505", light: "#ffffff" },
    }).then((dataUrl) => {
      if (active) setSrc(dataUrl);
    });
    return () => {
      active = false;
    };
  }, [value, refreshKey]);

  return src ? (
    <img src={src} alt="Rendered QR code preview" className={cn("aspect-square rounded-[18px] bg-white p-3", className)} />
  ) : (
    <Skeleton className={cn("aspect-square rounded-[18px]", className)} />
  );
}

function QrAssetFormDialog({
  open,
  mode,
  asset,
  onOpenChange,
  onSubmit,
}: {
  open: boolean;
  mode: QrFormMode;
  asset: SmartQrAsset | null;
  onOpenChange: (open: boolean) => void;
  onSubmit: (payload: { name: string; destinationUrl: string; category: string }) => Promise<void>;
}) {
  const [name, setName] = React.useState("");
  const [destinationUrl, setDestinationUrl] = React.useState("");
  const [category, setCategory] = React.useState("WEBSITE");
  const [loading, setLoading] = React.useState(false);

  React.useEffect(() => {
    if (!open) return;
    setName(asset?.name ?? "");
    setDestinationUrl(asset?.destination ?? "");
    setCategory(asset?.rawCategory ?? "WEBSITE");
  }, [asset, open]);

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setLoading(true);
    try {
      await onSubmit({ name, destinationUrl, category });
      onOpenChange(false);
    } catch (caught) {
      toast.error(mode === "create" ? "Could not generate QR" : "Could not update QR", {
        description: caught instanceof Error ? caught.message : "Check the fields and try again.",
      });
    } finally {
      setLoading(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-xl">
        <DialogHeader>
          <DialogTitle>{mode === "create" ? "Generate dynamic QR" : "Edit QR destination"}</DialogTitle>
          <DialogDescription>
            {mode === "create"
              ? "Create a short-link backed asset with live analytics."
              : "Update the destination without changing the printed QR code."}
          </DialogDescription>
        </DialogHeader>
        <form className="mt-5 space-y-4" onSubmit={submit}>
          <label className="space-y-2">
            <span className="text-sm text-slate-400">Asset name</span>
            <Input value={name} onChange={(event) => setName(event.target.value)} required />
          </label>
          <label className="space-y-2">
            <span className="text-sm text-slate-400">Destination URL</span>
            <Input value={destinationUrl} onChange={(event) => setDestinationUrl(event.target.value)} type="url" required />
          </label>
          <label className="space-y-2">
            <span className="text-sm text-slate-400">Category</span>
            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger className="w-full">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {qrCategoryOptions.map((option) => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </label>
          <div className="grid gap-3 sm:grid-cols-2">
            <Button type="button" variant="secondary" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={loading}>
              {loading ? "Saving..." : mode === "create" ? "Generate QR" : "Save changes"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function QrDetailDialog({
  asset,
  open,
  refreshKey,
  onOpenChange,
  onCopy,
  onDownload,
  onDuplicate,
  onDelete,
  onEdit,
  onToggleStatus,
  onRegenerate,
}: {
  asset: SmartQrAsset | null;
  open: boolean;
  refreshKey: number;
  onOpenChange: (open: boolean) => void;
  onCopy: (asset: SmartQrAsset) => void;
  onDownload: (asset: SmartQrAsset, format?: "png" | "svg" | "pdf") => void;
  onDuplicate: (asset: SmartQrAsset) => void;
  onDelete: (asset: SmartQrAsset) => void;
  onEdit: (asset: SmartQrAsset) => void;
  onToggleStatus: (asset: SmartQrAsset) => void;
  onRegenerate: () => void;
}) {
  if (!asset) return null;

  const daily = sparklineFor(asset).map((item) => ({ ...item, unique: Math.round(item.scans * 0.68) }));
  const deviceBreakdown = [
    { name: "Mobile", value: Math.max(54, Math.round(asset.uniqueScans * 0.58)) },
    { name: "Desktop", value: Math.max(18, Math.round(asset.uniqueScans * 0.24)) },
    { name: "Tablet", value: Math.max(8, Math.round(asset.uniqueScans * 0.12)) },
  ];
  const locationBreakdown = [
    { city: "Algiers", scans: Math.max(24, Math.round(asset.scans * 0.38)) },
    { city: "Paris", scans: Math.max(12, Math.round(asset.scans * 0.22)) },
    { city: "Dubai", scans: Math.max(8, Math.round(asset.scans * 0.14)) },
  ];
  const analyticsHref = `/qr/${asset.id}/analytics`;

  function openFullAnalytics() {
    window.location.assign(analyticsHref);
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] max-w-6xl overflow-y-auto">
        <motion.div initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.24 }}>
          <DialogHeader>
            <div className="flex flex-col gap-3 pr-8 sm:flex-row sm:items-start sm:justify-between">
              <div>
                <DialogTitle className="font-display text-3xl font-black">{asset.name}</DialogTitle>
                <DialogDescription>
                  {asset.client} · /r/{asset.shortId} · {asset.category}
                </DialogDescription>
              </div>
              <Badge variant={statusVariant(asset.status)}>{asset.status}</Badge>
            </div>
          </DialogHeader>

          <div className="mt-6 grid gap-5 xl:grid-cols-[0.8fr_1.2fr]">
            <Card className="bg-white/[0.04]">
              <CardHeader>
                <CardTitle>QR Preview</CardTitle>
                <CardDescription>Signed redirect asset rendered from the short link</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="mx-auto max-w-sm rounded-[26px] border border-white/10 bg-white/[0.06] p-4">
                  <QrPreview value={asset.shortUrl} refreshKey={refreshKey} className="w-full" />
                </div>
                <div className="mt-4 grid gap-3 sm:grid-cols-3">
                  <Button variant="secondary" onClick={() => onDownload(asset)}>
                    <Download className="h-4 w-4" />
                    Download
                  </Button>
                  <Button variant="secondary" onClick={() => onCopy(asset)}>
                    <Copy className="h-4 w-4" />
                    Copy link
                  </Button>
                  <Button onClick={onRegenerate}>
                    <RefreshCw className="h-4 w-4" />
                    Regenerate
                  </Button>
                </div>
              </CardContent>
            </Card>

            <div className="grid gap-5">
              <div className="grid gap-4 sm:grid-cols-3">
                <Card>
                  <CardContent className="p-4">
                    <MousePointerClick className="mb-5 h-5 w-5 text-[#ff7900]" />
                    <p className="text-xs uppercase tracking-[0.18em] text-slate-500">Total scans</p>
                    <p className="mt-2 font-display text-3xl font-black text-white">{formatNumber(asset.scans)}</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4">
                    <Users className="mb-5 h-5 w-5 text-[#ff7900]" />
                    <p className="text-xs uppercase tracking-[0.18em] text-slate-500">Unique scans</p>
                    <p className="mt-2 font-display text-3xl font-black text-white">{formatNumber(asset.uniqueScans)}</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4">
                    <CalendarDays className="mb-5 h-5 w-5 text-[#ff7900]" />
                    <p className="text-xs uppercase tracking-[0.18em] text-slate-500">Last scan</p>
                    <p className="mt-2 text-lg font-semibold text-white">{dateLabel(asset.lastScanAt)}</p>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle>Analytics Overview</CardTitle>
                  <CardDescription>Daily scans, device mix, and top locations</CardDescription>
                </CardHeader>
                <CardContent className="grid gap-5 lg:grid-cols-[1.25fr_0.75fr]">
                  <ChartFrame className="h-[220px]">
                    <QrTrendChart data={daily} />
                  </ChartFrame>
                  <div className="space-y-3">
                    {deviceBreakdown.map((device) => (
                      <div key={device.name} className="rounded-2xl border border-white/10 bg-white/[0.045] p-3">
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-white">{device.name}</span>
                          <span className="text-slate-400">{formatNumber(device.value)}</span>
                        </div>
                      </div>
                    ))}
                    {locationBreakdown.map((location) => (
                      <div key={location.city} className="rounded-2xl border border-white/10 bg-white/[0.045] p-3">
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-white">{location.city}</span>
                          <span className="text-slate-400">{formatNumber(location.scans)}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-5 grid gap-5 lg:grid-cols-[0.95fr_1.05fr]">
            <Card>
              <CardHeader>
                <CardTitle>Asset Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                {[
                  ["Asset name", asset.name],
                  ["Client", asset.client],
                  ["Campaign", asset.campaign],
                  ["Short-link ID", asset.shortId],
                  ["Destination", asset.destination],
                  ["Created", dateLabel(asset.createdAt)],
                ].map(([label, value]) => (
                  <div key={label} className="rounded-2xl border border-white/10 bg-white/[0.04] p-3">
                    <p className="text-xs uppercase tracking-[0.16em] text-slate-500">{label}</p>
                    <p className="mt-1 break-words text-white">{value}</p>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
                <CardDescription>Every control is wired to live UI or API behavior</CardDescription>
              </CardHeader>
              <CardContent className="grid gap-3 sm:grid-cols-2">
                <Button variant="secondary" onClick={() => onEdit(asset)}>
                  <Pencil className="h-4 w-4" />
                  Edit destination
                </Button>
                <Button variant="secondary" onPointerDown={openFullAnalytics} onClick={openFullAnalytics}>
                  <BarChart3 className="h-4 w-4" />
                  View full analytics
                </Button>
                <Button variant="secondary" onClick={() => onDuplicate(asset)}>
                  <Copy className="h-4 w-4" />
                  Duplicate
                </Button>
                <Button variant="secondary" onClick={() => onDownload(asset, "pdf")}>
                  <FileDown className="h-4 w-4" />
                  Export PDF
                </Button>
                <Button variant="secondary" onClick={() => onToggleStatus(asset)}>
                  {asset.rawStatus === "PAUSED" ? <Play className="h-4 w-4" /> : <Pause className="h-4 w-4" />}
                  {asset.rawStatus === "PAUSED" ? "Resume" : "Pause"}
                </Button>
                <Button variant="destructive" onClick={() => onDelete(asset)}>
                  <Trash2 className="h-4 w-4" />
                  Delete
                </Button>
              </CardContent>
            </Card>
          </div>
        </motion.div>
      </DialogContent>
    </Dialog>
  );
}

export function QRManagerView() {
  const searchParams = useSearchParams();
  const [query, setQuery] = React.useState("");
  const [view, setView] = React.useState<"grid" | "table">("grid");
  const [category, setCategory] = React.useState("all");
  const [selectedAsset, setSelectedAsset] = React.useState<SmartQrAsset | null>(null);
  const [detailOpen, setDetailOpen] = React.useState(false);
  const [formOpen, setFormOpen] = React.useState(false);
  const [formMode, setFormMode] = React.useState<QrFormMode>("create");
  const [refreshKey, setRefreshKey] = React.useState(0);
  const { assets: liveQrAssets, setAssets: setLiveQrAssets, loading, error, refresh } = useLiveQrAssets();

  React.useEffect(() => {
    setQuery(searchParams.get("search") ?? "");
  }, [searchParams]);

  React.useEffect(() => {
    function clearFiltersAfterCreate() {
      setSearchQuery("");
      setCategory("all");
      setView("grid");
    }

    window.addEventListener("smartconnect:qr-created", clearFiltersAfterCreate);
    return () => window.removeEventListener("smartconnect:qr-created", clearFiltersAfterCreate);
  }, []);

  const filtered = liveQrAssets.filter((asset) => {
    const matchesQuery = `${asset.name} ${asset.client} ${asset.destination} ${asset.shortId} ${asset.category}`
      .toLowerCase()
      .includes(query.toLowerCase());
    const matchesCategory = category === "all" || asset.rawCategory === category;
    return matchesQuery && matchesCategory;
  });

  const openCreate = React.useCallback(() => {
    setSelectedAsset(null);
    setFormMode("create");
    setFormOpen(true);
  }, []);

  function openDetails(asset: SmartQrAsset) {
    setSelectedAsset(asset);
    setDetailOpen(true);
  }

  function editAsset(asset: SmartQrAsset) {
    setSelectedAsset(asset);
    setFormMode("edit");
    setFormOpen(true);
  }

  function setSearchQuery(value: string) {
    setQuery(value);

    const url = new URL(window.location.href);
    if (value) {
      url.searchParams.set("search", value);
    } else {
      url.searchParams.delete("search");
    }
    window.history.replaceState(null, "", `${url.pathname}${url.search}`);
  }

  async function saveAsset(payload: { name: string; destinationUrl: string; category: string }) {
    if (formMode === "edit" && !selectedAsset) {
      throw new Error("Choose a QR asset before editing.");
    }

    const endpoint = formMode === "create" ? "/api/qr/create" : `/api/qr/${selectedAsset?.id}`;
    const method = formMode === "create" ? "POST" : "PUT";
    const response = await fetch(endpoint, {
      method,
      headers: { "content-type": "application/json" },
      credentials: "include",
      body: JSON.stringify(payload),
    });
    const body = await response.json().catch(() => ({}));

    if (!response.ok) {
      throw new Error(body.error ?? (formMode === "create" ? "Could not generate QR" : "Could not update QR"));
    }

    if (!body?.data?.id) throw new Error("QR API returned an unexpected response");

    const saved = assetFromApi(body.data, selectedAsset ?? undefined);

    setLiveQrAssets((current) =>
      formMode === "create" ? [saved, ...current] : current.map((asset) => (asset.id === saved.id ? saved : asset)),
    );
    setSelectedAsset(saved);
    if (formMode === "create") {
      setSearchQuery("");
      setCategory("all");
      setView("grid");
    }
    toast.success(formMode === "create" ? "Dynamic QR created" : "QR updated", {
      description: `/r/${saved.shortId} is ready.`,
    });
  }

  async function downloadAsset(asset: SmartQrAsset, format: "png" | "svg" | "pdf" = "png") {
    try {
      const response = await fetch(`/api/qr/${asset.id}/export?format=${format}`, { credentials: "include" });
      if (!response.ok) throw new Error("Export failed");
      const blob = await response.blob();
      downloadBlob(blob, `${asset.shortId}.${format}`);
      toast.success(`${format.toUpperCase()} export started`);
    } catch (error) {
      toast.error("Export failed", { description: error instanceof Error ? error.message : "Try again." });
    }
  }

  async function copyRedirectLink(asset: SmartQrAsset) {
    const url = asset.shortUrl.startsWith("http") ? asset.shortUrl : `${window.location.origin}/r/${asset.shortId}`;
    try {
      await navigator.clipboard.writeText(url);
      toast.success("Redirect link copied", { description: url });
    } catch {
      toast.error("Copy failed", { description: url });
    }
  }

  async function duplicateAsset(asset: SmartQrAsset) {
    try {
      const response = await fetch("/api/qr/create", {
        method: "POST",
        headers: { "content-type": "application/json" },
        credentials: "include",
        body: JSON.stringify({
          name: `${asset.name} copy`,
          category: asset.rawCategory,
          destinationUrl: asset.destination,
        }),
      });
      const body = await response.json().catch(() => ({}));

      if (!response.ok) throw new Error(body.error ?? "Try again.");
      if (!body?.data?.id) throw new Error("QR API returned an unexpected response");

      const copy = assetFromApi(body.data, { ...asset, scans: 0, uniqueScans: 0, lastScanAt: null });
      setLiveQrAssets((current) => [copy, ...current]);
      toast.success("QR duplicated", { description: `/r/${copy.shortId} created.` });
    } catch (caught) {
      toast.error("Duplicate failed", { description: caught instanceof Error ? caught.message : "Try again." });
    }
  }

  async function deleteAsset(asset: SmartQrAsset) {
    if (!window.confirm(`Delete "${asset.name}"? This removes the QR asset and its scan events.`)) return;
    const response = await fetch(`/api/qr/${asset.id}`, { method: "DELETE", credentials: "include" });
    const body = await response.json().catch(() => ({}));
    if (!response.ok) {
      toast.error("Delete failed", { description: body.error ?? "Try again." });
      return;
    }
    setLiveQrAssets((current) => current.filter((item) => item.id !== asset.id));
    setSelectedAsset((current) => (current?.id === asset.id ? null : current));
    setDetailOpen(false);
    toast.success("QR deleted", { description: `${asset.name} was removed.` });
  }

  async function toggleStatus(asset: SmartQrAsset) {
    const nextStatus = asset.rawStatus === "PAUSED" ? "ACTIVE" : "PAUSED";
    const response = await fetch(`/api/qr/${asset.id}`, {
      method: "PUT",
      headers: { "content-type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ status: nextStatus }),
    });
    const body = await response.json();
    if (!response.ok) {
      toast.error("Status update failed", { description: body.error ?? "Try again." });
      return;
    }
    const updated = { ...asset, rawStatus: nextStatus as SmartQrAsset["rawStatus"], status: statusLabel(nextStatus) };
    setLiveQrAssets((current) => current.map((item) => (item.id === asset.id ? updated : item)));
    setSelectedAsset(updated);
    toast.success(nextStatus === "ACTIVE" ? "QR resumed" : "QR paused");
  }

  function regeneratePreview() {
    setRefreshKey((value) => value + 1);
    toast.success("QR preview regenerated");
  }

  function exportQrInventory() {
    const rows = [
      ["Name", "Client", "Category", "Short ID", "Destination", "Status", "Scans", "Unique"],
      ...filtered.map((asset) => [
        asset.name,
        asset.client,
        asset.category,
        asset.shortId,
        asset.destination,
        asset.status,
        String(asset.scans),
        String(asset.uniqueScans),
      ]),
    ];
    downloadText(rows.map((row) => row.map((value) => `"${value.replaceAll('"', '""')}"`).join(",")).join("\n"), "trendwaves-qr-assets.csv");
    toast.success("QR inventory exported");
  }

  function runAction(event: React.MouseEvent, action: () => void) {
    event.stopPropagation();
    action();
  }

  function openDetailsFromKeyboard(event: React.KeyboardEvent, asset: SmartQrAsset) {
    if (event.key !== "Enter" && event.key !== " ") return;
    event.preventDefault();
    openDetails(asset);
  }

  return (
    <div>
      <PageHeader
        eyebrow="Dynamic QR management"
        title="Generate, edit, duplicate, export, and retire QR assets."
        description="Every QR routes through the backend short-link engine, so destinations can be changed after printing without losing analytics."
        action={
          <div className="flex flex-wrap gap-3">
            <Button variant="secondary" onClick={exportQrInventory}>
              <FileDown className="h-4 w-4" />
              Export list
            </Button>
            <Button onClick={openCreate}>
              <QrCode className="h-4 w-4" />
              Generate new QR
            </Button>
          </div>
        }
      />

      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col gap-3 lg:flex-row lg:items-center">
            <div className="flex flex-1 items-center gap-2 rounded-full border border-white/10 bg-white/[0.05] px-4">
              <Search className="h-4 w-4 text-slate-500" />
              <Input
                className="border-0 bg-transparent px-0 focus:bg-transparent"
                placeholder="Search QR assets"
                value={query}
                onChange={(event) => setSearchQuery(event.target.value)}
              />
            </div>
            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger className="w-full lg:w-52">
                <Filter className="h-4 w-4" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All categories</SelectItem>
                {qrCategoryOptions.map((option) => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <div className="flex rounded-full border border-white/10 bg-white/[0.05] p-1">
              <Button size="icon" variant={view === "grid" ? "default" : "ghost"} onClick={() => setView("grid")} aria-label="Show grid">
                <Grid3X3 className="h-4 w-4" />
              </Button>
              <Button size="icon" variant={view === "table" ? "default" : "ghost"} onClick={() => setView("table")} aria-label="Show table">
                <List className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {error ? (
        <Card className="mt-5 border-rose-300/20 bg-rose-300/10">
          <CardContent className="flex flex-col gap-4 p-5 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <p className="font-display text-lg font-bold text-white">QR assets could not load</p>
              <p className="mt-1 text-sm text-rose-100/80">{error}</p>
            </div>
            <Button variant="secondary" onClick={refresh}>
              <RefreshCw className="h-4 w-4" />
              Retry
            </Button>
          </CardContent>
        </Card>
      ) : loading && liveQrAssets.length === 0 ? (
        <div className="mt-5 grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          {Array.from({ length: 4 }).map((_, index) => (
            <Card key={index}>
              <CardContent className="space-y-4 p-5">
                <Skeleton className="h-14 w-14 rounded-[18px]" />
                <Skeleton className="h-5 w-3/4" />
                <Skeleton className="h-4 w-1/2" />
                <Skeleton className="h-12 w-full rounded-full" />
                <Skeleton className="h-12 w-full" />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : view === "grid" ? (
        <div className="mt-5 grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          {filtered.map((asset) => (
            <Card
              key={asset.id}
              onClick={() => openDetails(asset)}
              onKeyDown={(event) => openDetailsFromKeyboard(event, asset)}
              role="button"
              tabIndex={0}
              aria-label={`Open details for ${asset.name}`}
              className="group cursor-pointer transition duration-300 hover:-translate-y-1 hover:border-[#ff7900]/35 hover:bg-white/[0.075] hover:shadow-[0_24px_90px_rgba(21,0,245,0.24)]"
            >
              <CardContent className="p-5">
                <div className="mb-5 flex items-start justify-between">
                  <div className="grid h-14 w-14 place-items-center rounded-[18px] bg-white">
                    <QrCode className="h-7 w-7 text-slate-950" />
                  </div>
                  <Badge variant={statusVariant(asset.status)}>{asset.status}</Badge>
                </div>
                <p className="font-display text-lg font-bold text-white">{asset.name}</p>
                <p className="mt-1 text-sm text-slate-400">{asset.client}</p>
                <p className="mt-4 truncate rounded-full border border-white/10 bg-white/[0.05] px-3 py-2 text-xs text-slate-400">
                  /r/{asset.shortId}
                </p>
                <div className="mt-4 grid gap-2">
                  <div className="flex items-end justify-between gap-3">
                    <div>
                      <p className="font-display text-2xl font-black text-white">{formatNumber(asset.scans)} scans</p>
                      <p className="text-xs text-slate-400">{formatNumber(asset.uniqueScans)} unique</p>
                    </div>
                    <Badge variant="cyan">+{assetTrend(asset)}% this week</Badge>
                  </div>
                  <MiniSparkline asset={asset} />
                </div>
                <div className="mt-4 flex items-center justify-between">
                  <Button size="sm" variant="ghost" onClick={(event) => runAction(event, () => openDetails(asset))}>
                    Open details
                  </Button>
                  <div className="flex gap-1">
                    <Button size="icon" variant="ghost" aria-label="Edit QR" onClick={(event) => runAction(event, () => editAsset(asset))}>
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <Button size="icon" variant="ghost" aria-label="Download QR" onClick={(event) => runAction(event, () => downloadAsset(asset))}>
                      <Download className="h-4 w-4" />
                    </Button>
                    <Button size="icon" variant="ghost" aria-label="Duplicate QR" onClick={(event) => runAction(event, () => duplicateAsset(asset))}>
                      <Copy className="h-4 w-4" />
                    </Button>
                    <Button size="icon" variant="ghost" aria-label="Delete QR" onClick={(event) => runAction(event, () => deleteAsset(asset))}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
          {filtered.length === 0 ? (
            <Card className="md:col-span-2 xl:col-span-4">
              <CardContent className="grid min-h-64 place-items-center p-8 text-center">
                <div>
                  <Search className="mx-auto mb-4 h-8 w-8 text-slate-500" />
                  <p className="font-display text-xl font-bold text-white">No QR assets found</p>
                  <p className="mt-2 text-sm text-slate-400">Adjust search/filter or generate a new dynamic QR.</p>
                  <Button className="mt-5" onClick={openCreate}>
                    <Plus className="h-4 w-4" />
                    Generate QR
                  </Button>
                </div>
              </CardContent>
            </Card>
          ) : null}
        </div>
      ) : (
        <Card className="mt-5 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full min-w-[760px] text-left text-sm">
              <thead className="border-b border-white/10 text-xs uppercase tracking-[0.16em] text-slate-500">
                <tr>
                  <th className="px-5 py-4">Asset</th>
                  <th className="px-5 py-4">Category</th>
                  <th className="px-5 py-4">Client</th>
                  <th className="px-5 py-4">Scans / Unique</th>
                  <th className="px-5 py-4">Trend</th>
                  <th className="px-5 py-4">Status</th>
                  <th className="px-5 py-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((asset) => (
                  <tr
                    key={asset.id}
                    className="cursor-pointer border-b border-white/5 transition hover:bg-white/[0.04] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#1500f5]/60"
                    tabIndex={0}
                    onClick={() => openDetails(asset)}
                    onKeyDown={(event) => openDetailsFromKeyboard(event, asset)}
                  >
                    <td className="px-5 py-4 text-white">
                      <div>
                        <p className="font-medium">{asset.name}</p>
                        <p className="text-xs text-slate-500">/r/{asset.shortId}</p>
                      </div>
                    </td>
                    <td className="px-5 py-4 text-slate-400">{asset.category}</td>
                    <td className="px-5 py-4 text-slate-400">{asset.client}</td>
                    <td className="px-5 py-4 text-slate-400">
                      {formatNumber(asset.scans)} / {formatNumber(asset.uniqueScans)}
                    </td>
                    <td className="px-5 py-4">
                      <div className="w-28">
                        <MiniSparkline asset={asset} />
                      </div>
                    </td>
                    <td className="px-5 py-4">
                      <Badge variant={statusVariant(asset.status)}>{asset.status}</Badge>
                    </td>
                    <td className="px-5 py-4">
                      <div className="flex justify-end gap-1">
                        <Button size="icon" variant="ghost" aria-label="Edit QR" onClick={(event) => runAction(event, () => editAsset(asset))}>
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button size="icon" variant="ghost" aria-label="Download QR" onClick={(event) => runAction(event, () => downloadAsset(asset))}>
                          <Download className="h-4 w-4" />
                        </Button>
                        <Button size="icon" variant="ghost" aria-label="Duplicate QR" onClick={(event) => runAction(event, () => duplicateAsset(asset))}>
                          <Copy className="h-4 w-4" />
                        </Button>
                        <Button size="icon" variant="ghost" aria-label="Delete QR" onClick={(event) => runAction(event, () => deleteAsset(asset))}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      <QrAssetFormDialog
        open={formOpen}
        mode={formMode}
        asset={selectedAsset}
        onOpenChange={setFormOpen}
        onSubmit={saveAsset}
      />
      <QrDetailDialog
        asset={selectedAsset}
        open={detailOpen}
        refreshKey={refreshKey}
        onOpenChange={setDetailOpen}
        onCopy={copyRedirectLink}
        onDownload={downloadAsset}
        onDuplicate={duplicateAsset}
        onDelete={deleteAsset}
        onEdit={editAsset}
        onToggleStatus={toggleStatus}
        onRegenerate={regeneratePreview}
      />
    </div>
  );
}

export function NFCManagerView() {
  const [writerStatus, setWriterStatus] = React.useState("Ready for browser NFC session");
  const [bulkMode, setBulkMode] = React.useState(false);
  const [manualUid, setManualUid] = React.useState("");
  const [tagName, setTagName] = React.useState("New SmartConnect tag");
  const [destinationUrl, setDestinationUrl] = React.useState("https://trendwaves.app/r/new-tag");
  const [selectedTagId, setSelectedTagId] = React.useState("");
  const [writing, setWriting] = React.useState(false);
  const [liveNfcTags, setLiveNfcTags] = useLiveNfcTags();

  const selectedTag = React.useMemo(
    () => liveNfcTags.find((tag) => tag.id === selectedTagId || tag.uid === selectedTagId) ?? liveNfcTags[0],
    [liveNfcTags, selectedTagId],
  );

  React.useEffect(() => {
    if (!selectedTagId && liveNfcTags[0]?.id) setSelectedTagId(liveNfcTags[0].id);
  }, [liveNfcTags, selectedTagId]);

  React.useEffect(() => {
    if (selectedTag?.destinationUrl) setDestinationUrl(selectedTag.destinationUrl);
  }, [selectedTag?.destinationUrl]);

  async function registerTag() {
    if (!manualUid.trim()) {
      toast.error("Enter a chip UID first");
      return;
    }

    setWriting(true);
    try {
      const response = await fetch("/api/nfc/register", {
        method: "POST",
        headers: { "content-type": "application/json" },
        credentials: "include",
        body: JSON.stringify({
          chipUid: manualUid,
          name: tagName,
          destinationUrl,
          tagType: "NTAG213",
        }),
      });
      const body = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(body.error ?? "Could not register NFC tag");

      const tag = body.data;
      setLiveNfcTags((current) => [
        {
          id: tag.id,
          shortId: tag.shortId,
          shortUrl: tag.shortUrl,
          uid: tag.chipUid,
          name: tag.name,
          status: tag.operationalStatus ? statusLabel(tag.operationalStatus) : "Writable",
          client: tag.client?.name ?? "Unassigned",
          lastTap: "No taps yet",
          taps: tag.tapCount ?? 0,
          destinationUrl: tag.destinationUrl,
          operationalStatus: tag.operationalStatus,
          writtenPayload: tag.writtenPayload,
          isLocked: tag.isLocked,
          isWritable: tag.isWritable,
        },
        ...current.filter((item) => item.uid !== tag.chipUid),
      ]);
      setSelectedTagId(tag.id);
      setWriterStatus(`Registered ${tag.chipUid}. It is ready for NDEF writing.`);
      toast.success("NFC tag registered", { description: tag.shortUrl });
    } catch (error) {
      setWriterStatus("Registration failed");
      toast.error("NFC registration failed", { description: error instanceof Error ? error.message : "Try again." });
    } finally {
      setWriting(false);
    }
  }

  async function writeNfc(tag = selectedTag) {
    if (!tag?.id) {
      toast.error("Register or select a tag first");
      return;
    }

    setWriting(true);
    let writeLogId = "";
    let payload = "";

    try {
      const prepare = await fetch("/api/nfc/write", {
        method: "POST",
        headers: { "content-type": "application/json" },
        credentials: "include",
        body: JSON.stringify({
          tagId: tag.id,
          destinationUrl: destinationUrl || tag.destinationUrl,
        }),
      });
      const prepared = await prepare.json().catch(() => ({}));
      if (!prepare.ok) throw new Error(prepared.error ?? "Could not prepare NFC write");
      writeLogId = prepared.data.writeLog.id;
      payload = prepared.data.payload;

    if (typeof window === "undefined" || !("NDEFReader" in window)) {
        setWriterStatus(`Web NFC unavailable. Write this URL with an external NFC app: ${payload}`);
        toast.error("Web NFC unavailable", { description: "Backend prepared the payload for manual writing." });
      return;
    }

      const NDEFReader = (window as unknown as { NDEFReader: new () => { write: (value: unknown) => Promise<void> } }).NDEFReader;
      const writer = new NDEFReader();
      await writer.write({ records: [{ recordType: "url", data: payload }] });

      const confirm = await fetch("/api/nfc/write/confirm", {
        method: "POST",
        headers: { "content-type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ writeLogId, success: true, payload }),
      });
      const confirmed = await confirm.json().catch(() => ({}));
      if (!confirm.ok) throw new Error(confirmed.error ?? "Write confirmation failed");

      setLiveNfcTags((current) =>
        current.map((item) =>
          item.id === tag.id
            ? { ...item, status: "Verified", writtenPayload: payload, destinationUrl: destinationUrl || item.destinationUrl, lastTap: item.lastTap }
            : item,
        ),
      );
      setWriterStatus(`Verified NDEF URL: ${payload}`);
      toast.success("NFC write verified", { description: "The backend write log is complete." });
    } catch (error) {
      if (writeLogId) {
        await fetch("/api/nfc/write/confirm", {
          method: "POST",
          headers: { "content-type": "application/json" },
          credentials: "include",
          body: JSON.stringify({
            writeLogId,
            success: false,
            payload,
            errorMessage: error instanceof Error ? error.message : "Browser write failed",
          }),
        }).catch(() => undefined);
      }
      setWriterStatus("Write failed or permission was denied");
      toast.error("NFC write failed", { description: error instanceof Error ? error.message : "Check browser support and tap permissions." });
    } finally {
      setWriting(false);
    }
  }

  async function refreshTag(tag: NfcTag) {
    if (!tag.id) return;

    try {
      const response = await fetch(`/api/nfc/${tag.id}`, { credentials: "include" });
      const body = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(body.error ?? "Could not refresh NFC tag");
      const fresh = body.data;
      setLiveNfcTags((current) =>
        current.map((item) =>
          item.id === tag.id
            ? {
                ...item,
                status: fresh.isLocked ? "Locked" : fresh.operationalStatus ? statusLabel(fresh.operationalStatus) : statusLabel(fresh.status),
                destinationUrl: fresh.destinationUrl,
                writtenPayload: fresh.writtenPayload,
                lastTap: fresh.lastTapAt ? new Date(fresh.lastTapAt).toLocaleString() : "No taps yet",
                taps: fresh.tapCount,
              }
            : item,
        ),
      );
      setWriterStatus(`${fresh.name} refreshed from backend`);
      toast.success("NFC tag refreshed");
    } catch (error) {
      toast.error("Refresh failed", { description: error instanceof Error ? error.message : "Try again." });
    }
  }

  async function verifyTag(tag = selectedTag) {
    if (!tag?.id) {
      toast.error("Select a tag first");
      return;
    }

    try {
      const payload = tag.writtenPayload ?? tag.shortUrl ?? destinationUrl;
      const response = await fetch("/api/nfc/verify", {
        method: "POST",
        headers: { "content-type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ tagId: tag.id, payload }),
      });
      const body = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(body.error ?? "Verification failed");
      setWriterStatus(body.data.verified ? "Tag verified against redirect engine" : "Verification failed against backend checks");
      toast[body.data.verified ? "success" : "error"](body.data.verified ? "NFC tag verified" : "NFC verification failed");
    } catch (error) {
      toast.error("Verification failed", { description: error instanceof Error ? error.message : "Try again." });
    }
  }

  async function lockTag(tag: NfcTag) {
    if (!tag.id) return;
    if (!window.confirm(`Lock "${tag.name}" against future rewrites?`)) return;

    try {
      const response = await fetch(`/api/nfc/${tag.id}/lock`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ confirm: true }),
      });
      const body = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(body.error ?? "Lock failed");
      setLiveNfcTags((current) => current.map((item) => (item.id === tag.id ? { ...item, status: "Locked", isLocked: true } : item)));
      setWriterStatus(`${tag.name} is locked in the backend audit trail`);
      toast.success("NFC tag locked");
    } catch (error) {
      toast.error("Lock failed", { description: error instanceof Error ? error.message : "Admin permission is required." });
    }
  }

  async function batchWrite() {
    if (liveNfcTags.length === 0) {
      toast.error("No NFC tags available");
      return;
    }

    setWriting(true);
    try {
      const response = await fetch("/api/nfc/batch-write", {
        method: "POST",
        headers: { "content-type": "application/json" },
        credentials: "include",
        body: JSON.stringify({
          destinationUrl,
          tags: liveNfcTags.map((tag) => ({ chipUid: tag.uid, name: tag.name })),
        }),
      });
      const body = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(body.error ?? "Batch write preparation failed");
      setBulkMode(true);
      setWriterStatus(`${body.data.length} tags queued for browser writing and verification.`);
      toast.success("Batch write queue prepared");
    } catch (error) {
      toast.error("Batch write failed", { description: error instanceof Error ? error.message : "Try again." });
    } finally {
      setWriting(false);
    }
  }

  return (
    <div>
      <PageHeader
        eyebrow="NFC tag management"
        title="Register, assign, write, verify, and lock NFC destinations."
        description="Batch assign chip UIDs to clients, rewrite destinations from the dashboard, and track every tap through the same analytics engine."
        action={
          <Button onClick={registerTag} disabled={writing}>
            <SmartphoneNfc className="h-4 w-4" />
            {writing ? "Working..." : "Register tag"}
          </Button>
        }
      />

      <div className="grid gap-5 xl:grid-cols-[1.25fr_0.75fr]">
        <Card className="overflow-hidden">
          <CardHeader>
            <CardTitle>Registered tags</CardTitle>
            <CardDescription>Live operating state for client NFC inventory</CardDescription>
          </CardHeader>
          <div className="overflow-x-auto">
            <table className="w-full min-w-[760px] text-left text-sm">
              <thead className="border-y border-white/10 text-xs uppercase tracking-[0.16em] text-slate-500">
                <tr>
                  <th className="px-5 py-4">UID</th>
                  <th className="px-5 py-4">Name</th>
                  <th className="px-5 py-4">Client</th>
                  <th className="px-5 py-4">Last tap</th>
                  <th className="px-5 py-4">Status</th>
                  <th className="px-5 py-4 text-right">Write/update</th>
                </tr>
              </thead>
              <tbody>
                {liveNfcTags.map((tag) => (
                  <tr key={tag.uid} className="border-b border-white/5">
                    <td className="px-5 py-4 font-mono text-xs text-[#ffb06b]">{tag.uid}</td>
                    <td className="px-5 py-4 text-white">{tag.name}</td>
                    <td className="px-5 py-4 text-slate-400">{tag.client}</td>
                    <td className="px-5 py-4 text-slate-400">{tag.lastTap}</td>
                    <td className="px-5 py-4">
                      <Badge variant={tag.status === "Locked" ? "muted" : tag.status === "Writing" ? "warning" : "success"}>
                        {tag.status}
                      </Badge>
                    </td>
                    <td className="px-5 py-4">
                      <div className="flex justify-end gap-1">
                        <Button size="icon" variant="ghost" onClick={() => writeNfc(tag)} aria-label="Write NFC tag">
                          <RadioTower className="h-4 w-4" />
                        </Button>
                        <Button size="icon" variant="ghost" onClick={() => refreshTag(tag)} aria-label="Refresh NFC tag">
                          <RefreshCw className="h-4 w-4" />
                        </Button>
                        <Button size="icon" variant="ghost" onClick={() => lockTag(tag)} aria-label="Lock NFC tag">
                          <Lock className="h-4 w-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>NFC writing interface</CardTitle>
            <CardDescription>Web NFC with manual UID fallback</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Select value={selectedTag?.id ?? ""} onValueChange={setSelectedTagId}>
              <SelectTrigger className="w-full">
                <SmartphoneNfc className="h-4 w-4" />
                <SelectValue placeholder="Select tag" />
              </SelectTrigger>
              <SelectContent>
                {liveNfcTags.map((tag) => (
                  <SelectItem key={tag.id ?? tag.uid} value={tag.id ?? tag.uid}>
                    {tag.name} {tag.shortId ? `/r/${tag.shortId}` : tag.uid}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Input value={destinationUrl} onChange={(event) => setDestinationUrl(event.target.value)} placeholder="https://trendwaves.app/r/abc123" />
            <Input value={manualUid} onChange={(event) => setManualUid(event.target.value)} placeholder="Manual chip UID fallback" />
            <Input value={tagName} onChange={(event) => setTagName(event.target.value)} placeholder="Tag name" />
            <div className="flex items-center justify-between rounded-[18px] border border-white/10 bg-white/[0.05] p-4">
              <div>
                <p className="font-medium text-white">Bulk writing mode</p>
                <p className="text-xs text-slate-500">Queue tags for client assignment</p>
              </div>
              <Switch checked={bulkMode} onCheckedChange={setBulkMode} />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <Button onClick={() => writeNfc()} disabled={writing}>
                <RadioTower className="h-4 w-4" />
                Write
              </Button>
              <Button variant="secondary" onClick={() => verifyTag()} disabled={writing}>
                <CheckCircle2 className="h-4 w-4" />
                Verify
              </Button>
              <Button variant="secondary" onClick={() => selectedTag && lockTag(selectedTag)} disabled={writing}>
                <Lock className="h-4 w-4" />
                Lock
              </Button>
              <Button variant="secondary" onClick={batchWrite} disabled={writing}>
                <Layers3 className="h-4 w-4" />
                Batch
              </Button>
            </div>
            <div className="rounded-[18px] border border-[#ff7900]/30 bg-[#ff7900]/12 p-4 text-sm text-[#ffb06b]">
              {writerStatus}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

export function AnalyticsView() {
  function exportRealtimeSnapshot() {
    const rows = [
      ["Date", "QR scans", "NFC taps"],
      ...dailyScans.map((row) => [row.date, String(row.scans), String(row.nfc)]),
    ];
    downloadText(rows.map((row) => row.map((value) => `"${value.replaceAll('"', '""')}"`).join(",")).join("\n"), "trendwaves-analytics-stream.csv");
    toast.success("Real-time analytics snapshot exported");
  }

  return (
    <div>
      <PageHeader
        eyebrow="Analytics intelligence"
        title="Campaign, location, device, and conversion telemetry."
        description="Track repeat scans, browser/device breakdowns, city-level performance, and comparative lift across QR and NFC campaigns."
        action={<Button variant="secondary" onClick={exportRealtimeSnapshot}>Real-time stream</Button>}
      />

      <div className="grid gap-5 xl:grid-cols-[1.35fr_0.9fr]">
        <Card>
          <CardHeader>
            <CardTitle>Daily scans</CardTitle>
            <CardDescription>QR scans and NFC taps over the last eight days</CardDescription>
          </CardHeader>
          <CardContent>
            <ChartFrame className="h-[320px]">
              <ResponsiveContainer width="100%" height="100%" minWidth={1} minHeight={1}>
                <LineChart data={dailyScans}>
                  <CartesianGrid stroke="rgba(255,255,255,0.07)" vertical={false} />
                  <XAxis dataKey="date" stroke="#64748b" tickLine={false} axisLine={false} />
                  <YAxis stroke="#64748b" tickLine={false} axisLine={false} />
                  <Tooltip content={<ChartTooltip />} />
                  <Line type="monotone" dataKey="scans" stroke="#1500f5" strokeWidth={3} dot={false} />
                  <Line type="monotone" dataKey="nfc" stroke="#ff7900" strokeWidth={3} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            </ChartFrame>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Devices</CardTitle>
            <CardDescription>Traffic split by device type</CardDescription>
          </CardHeader>
          <CardContent>
            <ChartFrame className="h-[320px]">
              <ResponsiveContainer width="100%" height="100%" minWidth={1} minHeight={1}>
                <PieChart>
                  <Pie data={deviceData} dataKey="value" nameKey="name" innerRadius={72} outerRadius={110} paddingAngle={4}>
                    {deviceData.map((entry, index) => (
                      <Cell key={entry.name} fill={chartColors[index % chartColors.length]} />
                    ))}
                  </Pie>
                  <Tooltip content={<ChartTooltip />} />
                </PieChart>
              </ResponsiveContainer>
            </ChartFrame>
            <div className="grid grid-cols-2 gap-2">
              {deviceData.map((device, index) => (
                <div key={device.name} className="rounded-2xl border border-white/10 bg-white/[0.05] p-3">
                  <span className="mb-2 block h-2 w-8 rounded-full" style={{ backgroundColor: chartColors[index] }} />
                  <p className="text-sm text-white">{device.name}</p>
                  <p className="text-xs text-slate-500">{device.value}%</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="mt-5 grid gap-5 xl:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Locations</CardTitle>
            <CardDescription>Top-performing cities by scan volume</CardDescription>
          </CardHeader>
          <CardContent>
            <ChartFrame className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%" minWidth={1} minHeight={1}>
                <BarChart data={locationData}>
                  <CartesianGrid stroke="rgba(255,255,255,0.07)" vertical={false} />
                  <XAxis dataKey="city" stroke="#64748b" tickLine={false} axisLine={false} />
                  <YAxis stroke="#64748b" tickLine={false} axisLine={false} />
                  <Tooltip content={<ChartTooltip />} />
                  <Bar dataKey="scans" radius={[12, 12, 0, 0]} fill="#1500f5" />
                </BarChart>
              </ResponsiveContainer>
            </ChartFrame>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Campaign comparison</CardTitle>
            <CardDescription>Scan volume against conversion events</CardDescription>
          </CardHeader>
          <CardContent>
            <ChartFrame className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%" minWidth={1} minHeight={1}>
                <BarChart data={campaignComparison}>
                  <CartesianGrid stroke="rgba(255,255,255,0.07)" vertical={false} />
                  <XAxis dataKey="name" stroke="#64748b" tickLine={false} axisLine={false} />
                  <YAxis stroke="#64748b" tickLine={false} axisLine={false} />
                  <Tooltip content={<ChartTooltip />} />
                  <Bar dataKey="scans" fill="#1500f5" radius={[10, 10, 0, 0]} />
                  <Bar dataKey="conversions" fill="#ff7900" radius={[10, 10, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </ChartFrame>
          </CardContent>
        </Card>
      </div>

      <Card className="mt-5">
        <CardHeader>
          <CardTitle>Scan heatmap</CardTitle>
          <CardDescription>Hourly intensity pattern for fraud review and campaign timing</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-12 gap-2">
            {Array.from({ length: 72 }).map((_, index) => {
              const intensity = ((index * 17) % 100) / 100;
              return (
                <div
                  key={index}
                  className="h-8 rounded-lg border border-white/5"
                  style={{ backgroundColor: `rgba(21, 0, 245, ${0.08 + intensity * 0.42})` }}
                />
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export function CampaignsView() {
  const columns = ["Design", "Review", "Live"];
  const [campaignRows, setCampaignRows] = React.useState(campaigns);
  const [clientOptions, setClientOptions] = React.useState<Array<{ id: string; name: string }>>([]);
  const [createOpen, setCreateOpen] = React.useState(false);
  const [creating, setCreating] = React.useState(false);
  const [campaignClientId, setCampaignClientId] = React.useState("");

  React.useEffect(() => {
    fetch("/api/clients", { credentials: "include" })
      .then((response) => (response.ok ? response.json() : null))
      .then((body) => {
        if (Array.isArray(body?.data)) {
          setClientOptions(body.data.map((client: { id: string; name: string }) => ({ id: client.id, name: client.name })));
          setCampaignClientId((current) => current || body.data[0]?.id || "");
        }
      })
      .catch(() => undefined);

    fetch("/api/campaigns", { credentials: "include" })
      .then((response) => (response.ok ? response.json() : null))
      .then((body) => {
        if (!Array.isArray(body?.data)) return;
        setCampaignRows(
          body.data.map((campaign: {
            id: string;
            name: string;
            status: string;
            notes?: string | null;
            client?: { name?: string } | null;
            qrCodes?: Array<{ scanCount?: number }>;
            nfcTags?: Array<{ tapCount?: number }>;
          }) => ({
            id: campaign.id,
            name: campaign.name,
            client: campaign.client?.name ?? "Unassigned",
            status: statusLabel(campaign.status),
            assets: (campaign.qrCodes?.length ?? 0) + (campaign.nfcTags?.length ?? 0),
            scans:
              (campaign.qrCodes ?? []).reduce((sum, asset) => sum + (asset.scanCount ?? 0), 0) +
              (campaign.nfcTags ?? []).reduce((sum, tag) => sum + (tag.tapCount ?? 0), 0),
            owner: campaign.client?.name ?? "Trend Waves",
            stage: campaign.status === "ACTIVE" ? "Live" : campaign.status === "PAUSED" ? "Review" : "Design",
            notes: campaign.notes ?? "No campaign notes.",
          })),
        );
      })
      .catch(() => undefined);
  }, []);

  async function createCampaign(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const formData = new FormData(event.currentTarget);
    setCreating(true);
    try {
      const response = await fetch("/api/campaigns", {
        method: "POST",
        headers: { "content-type": "application/json" },
        credentials: "include",
        body: JSON.stringify({
          name: String(formData.get("name")),
          clientId: campaignClientId,
          status: "PLANNED",
          notes: String(formData.get("notes") ?? ""),
        }),
      });
      const body = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(body.error ?? "Campaign creation failed");
      const clientName = clientOptions.find((client) => client.id === campaignClientId)?.name ?? "Client";
      setCampaignRows((current) => [
        {
          id: body.data.id,
          name: body.data.name,
          client: clientName,
          status: "Planned",
          assets: 0,
          scans: 0,
          owner: "Trend Waves",
          stage: "Design",
          notes: body.data.notes ?? "No campaign notes.",
        },
        ...current,
      ]);
      setCreateOpen(false);
      toast.success("Campaign created");
    } catch (error) {
      toast.error("Campaign creation failed", { description: error instanceof Error ? error.message : "Try again." });
    } finally {
      setCreating(false);
    }
  }

  return (
    <div>
      <PageHeader
        eyebrow="Campaign operations"
        title="Plan, launch, pause, and compare client activation campaigns."
        description="Combine QR codes, NFC tags, dates, notes, and ownership in one agency-grade campaign workspace."
        action={<Button onClick={() => setCreateOpen(true)}>New campaign</Button>}
      />

      <Tabs defaultValue="kanban">
        <TabsList>
          <TabsTrigger value="kanban">Kanban</TabsTrigger>
          <TabsTrigger value="table">Table</TabsTrigger>
        </TabsList>
        <TabsContent value="kanban">
          <div className="grid gap-4 lg:grid-cols-3">
            {columns.map((column) => (
              <Card key={column}>
                <CardHeader>
                  <CardTitle>{column}</CardTitle>
                  <CardDescription>{campaignRows.filter((campaign) => campaign.stage === column).length} campaigns</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  {campaignRows
                    .filter((campaign) => campaign.stage === column)
                    .map((campaign) => (
                      <div key={campaign.id} className="rounded-[18px] border border-white/10 bg-white/[0.05] p-4 transition hover:-translate-y-1 hover:bg-white/[0.08]">
                        <div className="mb-3 flex items-center justify-between">
                          <Badge variant={campaign.status === "Active" ? "success" : campaign.status === "Paused" ? "warning" : "cyan"}>
                            {campaign.status}
                          </Badge>
                          <span className="text-xs text-slate-500">{campaign.owner}</span>
                        </div>
                        <p className="font-display text-lg font-bold text-white">{campaign.name}</p>
                        <p className="text-sm text-slate-400">{campaign.client}</p>
                        <p className="mt-3 text-sm leading-5 text-slate-500">{campaign.notes}</p>
                        <div className="mt-4 flex items-center justify-between text-sm text-slate-400">
                          <span>{campaign.assets} assets</span>
                          <span>{formatNumber(campaign.scans)} scans</span>
                        </div>
                      </div>
                    ))}
                  {campaignRows.filter((campaign) => campaign.stage === column).length === 0 ? (
                    <Skeleton className="h-36" />
                  ) : null}
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
        <TabsContent value="table">
          <Card className="overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full min-w-[800px] text-left text-sm">
                <thead className="border-b border-white/10 text-xs uppercase tracking-[0.16em] text-slate-500">
                  <tr>
                    <th className="px-5 py-4">Campaign</th>
                    <th className="px-5 py-4">Client</th>
                    <th className="px-5 py-4">Status</th>
                    <th className="px-5 py-4">Assets</th>
                    <th className="px-5 py-4">Scans</th>
                    <th className="px-5 py-4">Owner</th>
                  </tr>
                </thead>
                <tbody>
                {campaignRows.map((campaign) => (
                    <tr key={campaign.id} className="border-b border-white/5">
                      <td className="px-5 py-4 text-white">{campaign.name}</td>
                      <td className="px-5 py-4 text-slate-400">{campaign.client}</td>
                      <td className="px-5 py-4">
                        <Badge variant={campaign.status === "Active" ? "success" : campaign.status === "Paused" ? "warning" : "cyan"}>
                          {campaign.status}
                        </Badge>
                      </td>
                      <td className="px-5 py-4 text-slate-400">{campaign.assets}</td>
                      <td className="px-5 py-4 text-slate-400">{formatNumber(campaign.scans)}</td>
                      <td className="px-5 py-4 text-slate-400">{campaign.owner}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        </TabsContent>
      </Tabs>

      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent className="max-w-xl">
          <DialogHeader>
            <DialogTitle>Create campaign</DialogTitle>
            <DialogDescription>Create a real campaign record that can hold QR and NFC assets.</DialogDescription>
          </DialogHeader>
          <form className="mt-5 space-y-4" onSubmit={createCampaign}>
            <Input name="name" placeholder="Campaign name" required />
            <Select value={campaignClientId} onValueChange={setCampaignClientId}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Client" />
              </SelectTrigger>
              <SelectContent>
                {clientOptions.map((client) => (
                  <SelectItem key={client.id} value={client.id}>
                    {client.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Input name="notes" placeholder="Notes" />
            <div className="grid gap-3 sm:grid-cols-2">
              <Button type="button" variant="secondary" onClick={() => setCreateOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" disabled={creating || !campaignClientId}>
                {creating ? "Creating..." : "Create campaign"}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

const qrStyleTabs = ["Classic", "Rounded Flow", "Liquid Wave", "Premium Frame", "Dot Matrix", "Minimal Editorial"];

function RoundedQrSvg({
  value,
  dark,
  accent,
  stylePreset,
  cornerRadius,
  dotRoundness,
  eyeRoundness,
  gradient,
}: {
  value: string;
  dark: string;
  accent: string;
  stylePreset: string;
  cornerRadius: number;
  dotRoundness: number;
  eyeRoundness: number;
  gradient: boolean;
}) {
  const qr = React.useMemo(() => {
    try {
      return QRCode.create(value || "https://trendwaves.app/r/demo", { errorCorrectionLevel: "M" });
    } catch {
      return QRCode.create("https://trendwaves.app/r/demo", { errorCorrectionLevel: "M" });
    }
  }, [value]);

  const size = qr.modules.size;
  const data = qr.modules.data;
  const radius =
    stylePreset === "Dot Matrix"
      ? 0.5
      : stylePreset === "Rounded Flow" || stylePreset === "Liquid Wave"
        ? Math.max(0.04, dotRoundness / 100)
        : stylePreset === "Minimal Editorial"
          ? 0.18
          : 0.08;
  const moduleGap = stylePreset === "Premium Frame" ? 0.08 : stylePreset === "Minimal Editorial" ? 0 : 0.03;
  const fill = gradient ? "url(#qr-gradient)" : dark;

  return (
    <svg viewBox={`0 0 ${size} ${size}`} className="h-72 w-72" role="img" aria-label="Live QR style preview">
      <defs>
        <linearGradient id="qr-gradient" x1="0" x2="1" y1="0" y2="1">
          <stop offset="0%" stopColor={dark} />
          <stop offset="100%" stopColor={accent} />
        </linearGradient>
      </defs>
      <rect width={size} height={size} rx={Math.max(1, cornerRadius / 8)} fill="#ffffff" />
      {Array.from(data).map((enabled, index) => {
        if (!enabled) return null;
        const x = index % size;
        const y = Math.floor(index / size);
        const waveOffset = stylePreset === "Rounded Flow" || stylePreset === "Liquid Wave" ? Math.sin((x + y) * 0.42) * 0.025 : 0;
        return (
          <rect
            key={`${x}-${y}`}
            x={x + moduleGap / 2}
            y={y + moduleGap / 2 + waveOffset}
            width={1 - moduleGap}
            height={1 - moduleGap}
            rx={stylePreset === "Rounded Flow" || stylePreset === "Liquid Wave" || stylePreset === "Dot Matrix" ? radius : radius / 2}
            fill={fill}
            opacity={stylePreset === "Premium Frame" ? 0.94 : 1}
          />
        );
      })}
      {stylePreset === "Rounded Flow" || stylePreset === "Liquid Wave" ? (
        <g fill="none" stroke={accent} strokeLinecap="round" strokeWidth="0.28" opacity="0.42">
          <path d={`M${size * 0.18} ${size * 0.78} C ${size * 0.34} ${size * 0.66}, ${size * 0.56} ${size * 0.94}, ${size * 0.82} ${size * 0.72}`} />
          <path d={`M${size * 0.14} ${size * 0.26} C ${size * 0.34} ${size * 0.12}, ${size * 0.56} ${size * 0.38}, ${size * 0.76} ${size * 0.2}`} />
        </g>
      ) : null}
      {stylePreset === "Rounded Flow" || stylePreset === "Liquid Wave" ? (
        <g fill="none" stroke="#ffffff" strokeWidth={Math.max(0.1, eyeRoundness / 120)} opacity="0.7">
          <rect x="3.5" y="3.5" width="6" height="6" rx={eyeRoundness / 24} />
          <rect x={size - 9.5} y="3.5" width="6" height="6" rx={eyeRoundness / 24} />
          <rect x="3.5" y={size - 9.5} width="6" height="6" rx={eyeRoundness / 24} />
        </g>
      ) : null}
    </svg>
  );
}

export function QRCustomizerView() {
  const { assets: qrTargets, refresh: refreshQrTargets } = useLiveQrAssets();
  const [destination, setDestination] = React.useState("https://trendwaves.app/r/smart-demo");
  const [dark, setDark] = React.useState("#0f172a");
  const [accent, setAccent] = React.useState("#ff7900");
  const [shape, setShape] = React.useState("rounded");
  const [moduleShape, setModuleShape] = React.useState("rounded");
  const [eyeShape, setEyeShape] = React.useState("rounded");
  const [backgroundPattern, setBackgroundPattern] = React.useState("waves");
  const [stylePreset, setStylePreset] = React.useState("Rounded Flow");
  const [cornerRadius, setCornerRadius] = React.useState(28);
  const [dotRoundness, setDotRoundness] = React.useState(72);
  const [eyeRoundness, setEyeRoundness] = React.useState(70);
  const [glowIntensity, setGlowIntensity] = React.useState(22);
  const [gradient, setGradient] = React.useState(true);
  const [frame, setFrame] = React.useState("Scan to connect");
  const [logo, setLogo] = React.useState<string | null>(null);
  const [qrDataUrl, setQrDataUrl] = React.useState("");
  const [selectedQrId, setSelectedQrId] = React.useState("");
  const [savingStyle, setSavingStyle] = React.useState(false);

  const selectedQr = React.useMemo(
    () => qrTargets.find((asset) => asset.id === selectedQrId) ?? null,
    [qrTargets, selectedQrId],
  );

  const styleDesign = React.useMemo(
    () => ({
      moduleShape,
      eyeShape,
      foreground: dark,
      foreground2: accent,
      background: "#ffffff",
      background2: "#f8fafc",
      gradientType: gradient ? "linear" : "solid",
      gradientDirection: stylePreset === "Liquid Wave" ? 165 : 135,
      gradientIntensity: gradient ? 70 : 0,
      gradientOpacity: 100,
      dotSpacing: Math.max(0, Math.round((100 - dotRoundness) / 7)),
      borderRadius: Math.max(0, Math.round(cornerRadius / 1.6)),
      padding: 18,
      quietZone: 4,
      frameText: frame,
      frameStyle: stylePreset === "Minimal Editorial" ? "editorial" : stylePreset === "Classic" ? "none" : "premium",
      glowIntensity,
      logoUrl: logo ?? "",
      logoScale: logo ? 17 : 0,
      logoPadding: 8,
      logoMask: eyeRoundness > 75 ? "circle" : "rounded",
      backgroundPattern,
    }),
    [accent, backgroundPattern, cornerRadius, dark, dotRoundness, eyeRoundness, frame, glowIntensity, gradient, logo, moduleShape, eyeShape, stylePreset],
  );

  React.useEffect(() => {
    if (!selectedQrId && qrTargets[0]) {
      setSelectedQrId(qrTargets[0].id);
      setDestination(qrTargets[0].shortUrl.startsWith("http") ? qrTargets[0].shortUrl : `/r/${qrTargets[0].shortId}`);
    }
  }, [qrTargets, selectedQrId]);

  React.useEffect(() => {
    QRCode.toDataURL(destination || "https://trendwaves.app/r/demo", {
      margin: 2,
      width: 900,
      color: { dark, light: "#ffffff" },
    }).then(setQrDataUrl);
  }, [destination, dark]);

  function selectStyle(nextPreset: string) {
    setStylePreset(nextPreset);
    if (nextPreset === "Classic") {
      setModuleShape("square");
      setEyeShape("square");
      setGradient(false);
      setBackgroundPattern("none");
      setCornerRadius(8);
      setDotRoundness(10);
    } else if (nextPreset === "Rounded Flow") {
      setModuleShape("rounded");
      setEyeShape("rounded");
      setGradient(true);
      setBackgroundPattern("waves");
      setCornerRadius(44);
      setDotRoundness(78);
    } else if (nextPreset === "Liquid Wave") {
      setModuleShape("wave");
      setEyeShape("circle");
      setGradient(true);
      setBackgroundPattern("waves");
      setCornerRadius(58);
      setDotRoundness(88);
    } else if (nextPreset === "Premium Frame") {
      setModuleShape("rounded");
      setEyeShape("rounded");
      setGradient(true);
      setBackgroundPattern("grid");
      setCornerRadius(34);
      setDotRoundness(66);
    } else if (nextPreset === "Dot Matrix") {
      setModuleShape("dots");
      setEyeShape("circle");
      setGradient(true);
      setBackgroundPattern("dots");
      setCornerRadius(20);
      setDotRoundness(96);
    } else {
      setModuleShape("rounded");
      setEyeShape("square");
      setGradient(false);
      setBackgroundPattern("none");
      setCornerRadius(18);
      setDotRoundness(54);
    }
  }

  async function applyStyleToQr(showToast = true) {
    if (!selectedQrId) {
      toast.error("Choose a QR asset first");
      return false;
    }

    setSavingStyle(true);
    try {
      const response = await fetch(`/api/qr/${selectedQrId}/style`, {
        method: "PUT",
        headers: { "content-type": "application/json" },
        credentials: "include",
        body: JSON.stringify({
          design: styleDesign,
          changes: { source: "qr-customizer", preset: stylePreset },
        }),
      });
      const body = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(body.error ?? "Could not apply QR style");
      await refreshQrTargets();
      if (showToast) toast.success("QR style applied", { description: "Short ID and analytics history were preserved." });
      return true;
    } catch (error) {
      toast.error("Style update failed", { description: error instanceof Error ? error.message : "Try again." });
      return false;
    } finally {
      setSavingStyle(false);
    }
  }

  async function applyStyleToAll() {
    if (qrTargets.length === 0) {
      toast.error("No QR assets available");
      return;
    }

    setSavingStyle(true);
    try {
      const response = await fetch("/api/qr/bulk-style", {
        method: "POST",
        headers: { "content-type": "application/json" },
        credentials: "include",
        body: JSON.stringify({
          qrCodeIds: qrTargets.map((asset) => asset.id),
          design: styleDesign,
          changes: { source: "qr-customizer-bulk", preset: stylePreset },
        }),
      });
      const body = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(body.error ?? "Could not apply bulk style");
      await refreshQrTargets();
      toast.success("Bulk style applied", { description: `${qrTargets.length} QR assets updated without changing short IDs.` });
    } catch (error) {
      toast.error("Bulk style failed", { description: error instanceof Error ? error.message : "Try again." });
    } finally {
      setSavingStyle(false);
    }
  }

  async function saveStylePreset() {
    setSavingStyle(true);
    try {
      const response = await fetch("/api/qr/style-presets", {
        method: "POST",
        headers: { "content-type": "application/json" },
        credentials: "include",
        body: JSON.stringify({
          name: stylePreset,
          description: `${stylePreset} template saved from the live QR customizer.`,
          design: styleDesign,
        }),
      });
      const body = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(body.error ?? "Could not save style preset");
      toast.success("Style preset saved", { description: `${stylePreset} is ready to apply to QR assets.` });
    } catch (error) {
      toast.error("Preset save failed", { description: error instanceof Error ? error.message : "Try again." });
    } finally {
      setSavingStyle(false);
    }
  }

  async function exportQr(format: "png" | "svg" | "pdf") {
    if (selectedQrId && (await applyStyleToQr(false))) {
      const response = await fetch(`/api/qr/${selectedQrId}/export?format=${format}`, { credentials: "include" });
      if (!response.ok) {
        toast.error("Export failed");
        return;
      }
      downloadBlob(await response.blob(), `${selectedQr?.shortId ?? "trendwaves-qr"}.${format}`);
      toast.success(`${format.toUpperCase()} export started`);
      return;
    }

    if (format === "png") {
      const link = document.createElement("a");
      link.href = qrDataUrl;
      link.download = "trendwaves-smartconnect-qr.png";
      link.click();
      toast.success("PNG export started");
      return;
    }

    if (format === "svg") {
      const svg = await QRCode.toString(destination, {
        type: "svg",
        margin: 2,
        width: 900,
        color: { dark, light: "#ffffff" },
      });
      const blob = new Blob([svg], { type: "image/svg+xml" });
      const link = document.createElement("a");
      link.href = URL.createObjectURL(blob);
      link.download = "trendwaves-smartconnect-qr.svg";
      link.click();
      URL.revokeObjectURL(link.href);
      toast.success("SVG export started");
      return;
    }

    toast.success("PDF print/export opened");
    window.print();
  }

  return (
    <div>
      <PageHeader
        eyebrow="QR design studio"
        title="Design branded dynamic QR codes with live preview and export."
        description="Apply Trend Waves styling, client logos, frame text, shape systems, and production export formats."
        action={
          <Button variant="secondary" onClick={saveStylePreset} disabled={savingStyle}>
            <Sparkles className="h-4 w-4" />
            {savingStyle ? "Saving..." : "Save style preset"}
          </Button>
        }
      />

      <div className="grid gap-5 xl:grid-cols-[0.9fr_1.1fr]">
        <Card>
          <CardHeader>
            <CardTitle>Controls</CardTitle>
            <CardDescription>Customize destination, color, logo, frame, and shape</CardDescription>
          </CardHeader>
          <CardContent className="space-y-5">
            <label className="space-y-2">
              <span className="text-sm text-slate-400">Dynamic QR asset</span>
              <Select
                value={selectedQrId}
                onValueChange={(value) => {
                  setSelectedQrId(value);
                  const target = qrTargets.find((asset) => asset.id === value);
                  if (target) setDestination(target.shortUrl.startsWith("http") ? target.shortUrl : `/r/${target.shortId}`);
                }}
              >
                <SelectTrigger className="w-full">
                  <QrCode className="h-4 w-4" />
                  <SelectValue placeholder="Choose QR asset" />
                </SelectTrigger>
                <SelectContent>
                  {qrTargets.map((asset) => (
                    <SelectItem key={asset.id} value={asset.id}>
                      {asset.name} /r/{asset.shortId}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </label>
            <div className="space-y-3">
              <span className="text-sm text-slate-400">Style selector</span>
              <Tabs value={stylePreset} onValueChange={selectStyle}>
                <TabsList className="grid h-auto grid-cols-2 gap-1 sm:grid-cols-3">
                  {qrStyleTabs.map((style) => (
                    <TabsTrigger key={style} value={style} className="min-h-10">
                      {style}
                    </TabsTrigger>
                  ))}
                </TabsList>
              </Tabs>
            </div>
            <label className="space-y-2">
              <span className="text-sm text-slate-400">Destination URL</span>
              <Input value={destination} onChange={(event) => setDestination(event.target.value)} />
            </label>
            <div className="grid gap-4 sm:grid-cols-2">
              <label className="space-y-2">
                <span className="text-sm text-slate-400">QR color</span>
                <input className="h-11 w-full rounded-full border border-white/10 bg-transparent p-1" type="color" value={dark} onChange={(event) => setDark(event.target.value)} />
              </label>
              <label className="space-y-2">
                <span className="text-sm text-slate-400">Accent glow</span>
                <input className="h-11 w-full rounded-full border border-white/10 bg-transparent p-1" type="color" value={accent} onChange={(event) => setAccent(event.target.value)} />
              </label>
            </div>
            <label className="space-y-2">
              <span className="text-sm text-slate-400">Frame text</span>
              <Input value={frame} onChange={(event) => setFrame(event.target.value)} />
            </label>
            <div className="grid gap-4 sm:grid-cols-2">
              <Select value={moduleShape} onValueChange={setModuleShape}>
                <SelectTrigger className="w-full">
                  <Palette className="h-4 w-4" />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="square">Square modules</SelectItem>
                  <SelectItem value="rounded">Rounded modules</SelectItem>
                  <SelectItem value="dots">Circular dots</SelectItem>
                  <SelectItem value="wave">Liquid wave</SelectItem>
                </SelectContent>
              </Select>
              <Select value={eyeShape} onValueChange={setEyeShape}>
                <SelectTrigger className="w-full">
                  <Eye className="h-4 w-4" />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="square">Square eyes</SelectItem>
                  <SelectItem value="rounded">Rounded eyes</SelectItem>
                  <SelectItem value="circle">Circular eyes</SelectItem>
                </SelectContent>
              </Select>
              <Select value={backgroundPattern} onValueChange={setBackgroundPattern}>
                <SelectTrigger className="w-full">
                  <Layers3 className="h-4 w-4" />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">Clean background</SelectItem>
                  <SelectItem value="waves">Wave overlay</SelectItem>
                  <SelectItem value="grid">Editorial grid</SelectItem>
                  <SelectItem value="dots">Dot pattern</SelectItem>
                </SelectContent>
              </Select>
              <Select value={shape} onValueChange={setShape}>
                <SelectTrigger className="w-full">
                  <Palette className="h-4 w-4" />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="rounded">Rounded frame</SelectItem>
                  <SelectItem value="sharp">Sharp editorial</SelectItem>
                  <SelectItem value="pill">Pill frame</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="rounded-[18px] border border-white/10 bg-white/[0.045] p-4">
              <div className="mb-4 flex items-center justify-between gap-4">
                <div>
                  <p className="text-sm font-medium text-white">Rounded Flow controls</p>
                  <p className="text-xs text-slate-500">Soft wave geometry, rounded modules, and premium gradient support.</p>
                </div>
                <div className="flex items-center gap-2 text-xs text-slate-400">
                  Gradient
                  <Switch checked={gradient} onCheckedChange={setGradient} />
                </div>
              </div>
              {[
                ["Corner radius", cornerRadius, setCornerRadius],
                ["Dot roundness", dotRoundness, setDotRoundness],
                ["Inner eye roundness", eyeRoundness, setEyeRoundness],
                ["Glow intensity", glowIntensity, setGlowIntensity],
              ].map(([label, value, setter]) => (
                <label key={String(label)} className="mb-3 grid gap-2 last:mb-0">
                  <span className="flex justify-between text-xs text-slate-400">
                    {String(label)}
                    <span>{String(value)}%</span>
                  </span>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={Number(value)}
                    onChange={(event) => (setter as React.Dispatch<React.SetStateAction<number>>)(Number(event.target.value))}
                    className="w-full accent-[#ff7900]"
                  />
                </label>
              ))}
            </div>
            <label className="flex cursor-pointer items-center justify-center gap-2 rounded-full border border-white/10 bg-white/[0.06] px-4 py-3 text-sm text-slate-300 transition hover:bg-white/[0.1]">
              <Upload className="h-4 w-4" />
              Upload center logo
              <input
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(event) => {
                  const file = event.target.files?.[0];
                  if (!file) return;
                  const reader = new FileReader();
                  reader.onload = () => setLogo(String(reader.result));
                  reader.readAsDataURL(file);
                }}
              />
            </label>
            <div className="grid grid-cols-3 gap-3">
              <Button variant="secondary" onClick={() => exportQr("png")}>
                PNG
              </Button>
              <Button variant="secondary" onClick={() => exportQr("svg")}>
                SVG
              </Button>
              <Button onClick={() => exportQr("pdf")}>PDF</Button>
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              <Button onClick={() => applyStyleToQr()} disabled={savingStyle}>
                <CheckCircle2 className="h-4 w-4" />
                Apply to QR
              </Button>
              <Button variant="secondary" onClick={applyStyleToAll} disabled={savingStyle}>
                <Layers3 className="h-4 w-4" />
                Apply to all
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card className="overflow-hidden">
          <CardHeader className="flex-row items-center justify-between">
            <div>
              <CardTitle>Live preview</CardTitle>
              <CardDescription>Branded short-link QR frame</CardDescription>
            </div>
            <Badge variant="cyan">Dynamic</Badge>
          </CardHeader>
          <CardContent>
            <div
              className={cn(
                "mx-auto grid min-h-[520px] max-w-xl place-items-center border border-white/10 bg-white/[0.04] p-6",
                shape === "rounded" && "rounded-[34px]",
                shape === "sharp" && "rounded-none",
                shape === "pill" && "rounded-[44px]",
              )}
              style={{ boxShadow: `0 0 ${40 + glowIntensity * 2}px ${accent}22` }}
            >
              <div className="relative rounded-[28px] bg-white p-7 text-center text-slate-950 shadow-2xl">
                <p className="mb-5 font-display text-lg font-black uppercase tracking-[0.12em]">Trend waves</p>
                <div className="relative">
                  <RoundedQrSvg
                    value={destination}
                    dark={dark}
                    accent={accent}
                    stylePreset={stylePreset}
                    cornerRadius={cornerRadius}
                    dotRoundness={dotRoundness}
                    eyeRoundness={eyeRoundness}
                    gradient={gradient}
                  />
                  <div className="absolute left-1/2 top-1/2 grid h-16 w-16 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-2xl border border-slate-200 bg-white shadow-xl">
                    {logo ? <img src={logo} alt="Uploaded logo" className="max-h-10 max-w-10 rounded-lg" /> : <TrendWavesLogo withText={false} withTm={false} tone="orange" markClassName="h-8 w-16" />}
                  </div>
                </div>
                <p className="mt-5 text-sm font-semibold uppercase tracking-[0.18em]">{frame}</p>
                <p className="mt-2 text-xs font-semibold uppercase tracking-[0.2em] text-slate-500">{stylePreset}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

export function ClientPortalView() {
  const { assets: liveQrAssets, setAssets: setLiveQrAssets } = useLiveQrAssets();
  const [allowUrlEdits, setAllowUrlEdits] = React.useState(true);
  const [clientDestination, setClientDestination] = React.useState("https://client.com/spring-menu");
  const portalAsset = liveQrAssets[0] ?? null;

  React.useEffect(() => {
    if (portalAsset?.destination) setClientDestination(portalAsset.destination);
  }, [portalAsset?.destination]);

  async function requestDestinationUpdate() {
    if (!portalAsset) {
      toast.error("No QR asset is available for this client");
      return;
    }

    try {
      const response = await fetch(`/api/qr/${portalAsset.id}`, {
        method: "PUT",
        headers: { "content-type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ destinationUrl: clientDestination }),
      });
      const body = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(body.error ?? "Destination update failed");
      setLiveQrAssets((current) =>
        current.map((asset) => (asset.id === portalAsset.id ? assetFromApi(body.data, asset) : asset)),
      );
      toast.success("Destination updated", { description: `/r/${portalAsset.shortId} now points to the new URL.` });
    } catch (error) {
      toast.error("Destination update failed", { description: error instanceof Error ? error.message : "Try again." });
    }
  }

  return (
    <div>
      <PageHeader
        eyebrow="Client portal"
        title="A simplified performance view for client sub-accounts."
        description="Clients can view analytics, download QR codes, check active campaigns, and edit destinations when permissions allow."
        action={<Button variant="secondary" onClick={() => setAllowUrlEdits((value) => !value)}>Client permissions</Button>}
      />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-5">
        {clientPortalItems.map((item) => {
          const Icon = item.icon;
          return (
            <Card key={item.label}>
              <CardContent className="p-5">
                <Icon className="mb-8 h-5 w-5 text-[#ff7900]" />
                <p className="text-sm text-slate-400">{item.label}</p>
                <p className="mt-2 font-display text-2xl font-black text-white">{item.value}</p>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="mt-5 grid gap-5 lg:grid-cols-[1.1fr_0.9fr]">
        <Card>
          <CardHeader>
            <CardTitle>Active campaigns</CardTitle>
            <CardDescription>Client-facing status without agency-only controls</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {campaigns.slice(0, 3).map((campaign) => (
              <div key={campaign.id} className="flex flex-col gap-3 rounded-[18px] border border-white/10 bg-white/[0.045] p-4 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <p className="font-medium text-white">{campaign.name}</p>
                  <p className="text-sm text-slate-400">{campaign.assets} assets</p>
                </div>
                <div className="flex items-center gap-3">
                  <Badge variant={campaign.status === "Active" ? "success" : "warning"}>{campaign.status}</Badge>
                  <Button
                    size="sm"
                    variant="secondary"
                    onClick={() => {
                      downloadText(
                        `Campaign,Assets,Scans\n"${campaign.name}",${campaign.assets},${campaign.scans}`,
                        `${campaign.id}-client-campaign.csv`,
                      );
                      toast.success("Client campaign export started");
                    }}
                  >
                    <Download className="h-4 w-4" />
                    Download
                  </Button>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Destination permissions</CardTitle>
            <CardDescription>Optional client editing with audit trail</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between rounded-[18px] border border-white/10 bg-white/[0.05] p-4">
              <div>
                <p className="font-medium text-white">Allow URL edits</p>
                <p className="text-xs text-slate-500">Requires approval workflow for production assets</p>
              </div>
              <Switch checked={allowUrlEdits} onCheckedChange={setAllowUrlEdits} />
            </div>
            <Input value={clientDestination} onChange={(event) => setClientDestination(event.target.value)} disabled={!allowUrlEdits} />
            <Button
              className="w-full"
              disabled={!allowUrlEdits}
              onClick={requestDestinationUpdate}
            >
              <ExternalLink className="h-4 w-4" />
              Update destination
            </Button>
          </CardContent>
        </Card>
      </div>

      <Card className="mt-5">
        <CardHeader>
          <CardTitle>Revenue signal</CardTitle>
          <CardDescription>Estimated campaign-attributed value from conversion events</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
            <div>
              <p className="font-display text-5xl font-black text-white">{currency(284000)}</p>
              <p className="mt-2 text-sm text-slate-400">Projected value from QR and NFC conversion events</p>
            </div>
            <Button variant="secondary" onClick={() => window.location.assign("/analytics")}>
              <Eye className="h-4 w-4" />
              View attribution
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
