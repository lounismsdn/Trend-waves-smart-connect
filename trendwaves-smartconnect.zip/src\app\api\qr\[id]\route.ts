import { NextRequest } from "next/server";
import { Prisma } from "@prisma/client";
import { fail, guardRateLimit, handleApiError, ok } from "@/lib/api";
import { getAuthUser, signRedirect } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { checksumDesign } from "@/lib/qr-style";
import { qrUpdateSchema } from "@/lib/validation";

export const runtime = "nodejs";

type RouteContext = { params: Promise<{ id: string }> };

export async function GET(request: NextRequest, context: RouteContext) {
  const limited = guardRateLimit(request, "qr:get", 240);
  if (limited) return limited;

  try {
    const user = await getAuthUser(request);
    if (!user) return fail("Unauthorized", 401);

    const { id } = await context.params;
    const qrCode = await prisma.qrCode.findUnique({
      where: { id },
      include: { client: true, campaign: true },
    });

    if (!qrCode) return fail("QR code not found", 404);

    const signature = await signRedirect(qrCode.shortId);
    const origin = process.env.APP_URL ?? new URL(request.url).origin;

    return ok({
      ...qrCode,
      shortUrl: `${origin}/r/${qrCode.shortId}?s=${signature}`,
    });
  } catch (error) {
    return handleApiError(error);
  }
}

export async function PUT(request: NextRequest, context: RouteContext) {
  const limited = guardRateLimit(request, "qr:update", 120);
  if (limited) return limited;

  try {
    const user = await getAuthUser(request);
    if (!user) return fail("Unauthorized", 401);

    const { id } = await context.params;
    const input = qrUpdateSchema.parse(await request.json());
    const { clientId, campaignId, ...assetUpdate } = input;
    const { design, ...safeAssetUpdate } = assetUpdate;
    const qrCode = await prisma.$transaction(async (tx) => {
      const current = await tx.qrCode.findUnique({ where: { id } });
      if (!current) throw new Error("QR code not found");

      const nextVersion = design === undefined ? current.designVersion : current.designVersion + 1;
      const updated = await tx.qrCode.update({
        where: { id },
        data: {
          ...safeAssetUpdate,
          design: design === undefined ? undefined : (design as Prisma.InputJsonValue),
          designChecksum: design === undefined ? undefined : checksumDesign(design),
          designVersion: nextVersion,
          client: clientId ? { connect: { id: clientId } } : undefined,
          campaign: campaignId ? { connect: { id: campaignId } } : undefined,
        },
        include: {
          client: { select: { id: true, name: true, slug: true } },
          campaign: { select: { id: true, name: true, status: true } },
        },
      });

      if (design !== undefined) {
        await tx.qrDesignVersion.create({
          data: {
            qrCodeId: id,
            version: nextVersion,
            design: design as Prisma.InputJsonValue,
            changes: { updatedFromVersion: current.designVersion } as Prisma.InputJsonValue,
            editorId: user.sub,
          },
        });
      }

      return updated;
    });

    await prisma.auditLog.create({
      data: {
        actorId: user.sub,
        action: "QR_UPDATED",
        entity: "QrCode",
        entityId: id,
        metadata: input as Prisma.InputJsonValue,
      },
    });

    const signature = await signRedirect(qrCode.shortId);
    const origin = process.env.APP_URL ?? new URL(request.url).origin;

    return ok({
      ...qrCode,
      shortUrl: `${origin}/r/${qrCode.shortId}?s=${signature}`,
    });
  } catch (error) {
    return handleApiError(error);
  }
}

export async function DELETE(request: NextRequest, context: RouteContext) {
  const limited = guardRateLimit(request, "qr:delete", 60);
  if (limited) return limited;

  try {
    const user = await getAuthUser(request);
    if (!user) return fail("Unauthorized", 401);

    const { id } = await context.params;
    const where =
      user.role === "CLIENT" && user.clientId
        ? { id, clientId: user.clientId }
        : { id };
    const deleted = await prisma.qrCode.deleteMany({ where });

    if (deleted.count === 0) {
      return ok({ deleted: false, missing: true });
    }

    await prisma.auditLog.create({
      data: {
        actorId: user.sub,
        action: "QR_DELETED",
        entity: "QrCode",
        entityId: id,
      },
    });

    return ok({ deleted: true, missing: false });
  } catch (error) {
    return handleApiError(error);
  }
}
