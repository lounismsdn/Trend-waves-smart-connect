import PDFDocument from "pdfkit";
import { NextRequest } from "next/server";
import { fail, guardRateLimit, handleApiError } from "@/lib/api";
import { getAuthUser } from "@/lib/auth";
import { getClientAnalytics } from "@/lib/analytics";
import { prisma } from "@/lib/prisma";

export const runtime = "nodejs";

type RouteContext = { params: Promise<{ id: string }> };

function escapeCsv(value: unknown) {
  return `"${String(value ?? "").replaceAll('"', '""')}"`;
}

async function pdfBuffer(clientName: string, rows: string[][]) {
  const doc = new PDFDocument({ margin: 48, size: "A4" });
  const chunks: Buffer[] = [];

  doc.on("data", (chunk: Buffer) => chunks.push(chunk));
  const done = new Promise<Buffer>((resolve) => {
    doc.on("end", () => resolve(Buffer.concat(chunks)));
  });

  doc.fontSize(22).fillColor("#111111").text("Trend Waves SmartConnect");
  doc.moveDown(0.4).fontSize(14).fillColor("#444444").text(`${clientName} client analytics report`);
  doc.moveDown();

  rows.slice(0, 60).forEach((row, index) => {
    doc.fillColor(index === 0 ? "#1500f5" : "#111111").fontSize(index === 0 ? 10 : 9).text(row.join("  |  "));
    doc.moveDown(0.35);
  });

  doc.end();
  return done;
}

export async function GET(request: NextRequest, context: RouteContext) {
  const limited = guardRateLimit(request, "export:client", 60);
  if (limited) return limited;

  try {
    const user = await getAuthUser(request);
    if (!user) return fail("Unauthorized", 401);

    const { id } = await context.params;
    if (user.role === "CLIENT" && user.clientId && user.clientId !== id) return fail("Forbidden", 403);

    const format = request.nextUrl.searchParams.get("format") ?? "csv";
    const analytics = await getClientAnalytics(
      id,
      request.nextUrl.searchParams.get("range"),
      request.nextUrl.searchParams.get("from"),
      request.nextUrl.searchParams.get("to"),
    );
    if (!analytics.client) return fail("Client not found", 404);

    const rows = [
      ["Metric", "Value"],
      ["Total scans", String(analytics.totals.scans)],
      ["Unique scans", String(analytics.totals.unique)],
      ["QR scans", String(analytics.totals.qrScans)],
      ["NFC taps", String(analytics.totals.nfcTaps)],
      ["Active QR assets", String(analytics.totals.activeQrAssets)],
      ["Active NFC tags", String(analytics.totals.activeNfcTags)],
      ["Active campaigns", String(analytics.totals.activeCampaigns)],
      ["Conversions", String(analytics.totals.conversions)],
      ["Conversion rate", `${analytics.totals.conversionRate}%`],
      [],
      ["Date", "Scans", "Unique"],
      ...analytics.dailyScans.map((day) => [day.date, String(day.scans), String(day.unique)]),
    ];

    await prisma.exportJob.create({
      data: {
        type: "CLIENT_ANALYTICS",
        format,
        status: "COMPLETED",
        assetType: "CLIENT",
        assetId: id,
        clientId: id,
        requesterId: user.sub,
        completedAt: new Date(),
      },
    });

    if (format === "pdf") {
      const buffer = await pdfBuffer(analytics.client.name, rows);
      return new Response(new Uint8Array(buffer), {
        headers: {
          "content-type": "application/pdf",
          "content-disposition": `attachment; filename="${analytics.client.slug}-analytics.pdf"`,
        },
      });
    }

    return new Response(rows.map((row) => row.map(escapeCsv).join(",")).join("\n"), {
      headers: {
        "content-type": "text/csv",
        "content-disposition": `attachment; filename="${analytics.client.slug}-analytics.csv"`,
      },
    });
  } catch (error) {
    return handleApiError(error);
  }
}
