import { NextRequest } from "next/server";
import { fail, guardRateLimit, handleApiError, ok, parseBody } from "@/lib/api";
import { setSessionCookie, signAccessToken, verifyPassword } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { loginSchema } from "@/lib/validation";

export const runtime = "nodejs";

export async function POST(request: NextRequest) {
  const limited = guardRateLimit(request, "auth:login", 12);
  if (limited) return limited;

  try {
    const input = await parseBody(request, loginSchema);
    const user = await prisma.user.findUnique({ where: { email: input.email } });

    if (!user || !(await verifyPassword(input.password, user.passwordHash))) {
      return fail("Invalid credentials", 401);
    }

    const token = await signAccessToken({
      sub: user.id,
      email: user.email,
      role: user.role,
      clientId: user.clientId,
    });

    const response = ok({
      token,
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role,
        clientId: user.clientId,
      },
    });
    setSessionCookie(response, token);

    return response;
  } catch (error) {
    return handleApiError(error);
  }
}
