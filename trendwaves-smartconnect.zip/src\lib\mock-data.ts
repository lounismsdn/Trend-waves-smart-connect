import {
  Activity,
  BadgeCheck,
  BellRing,
  CalendarRange,
  Globe2,
  Link2,
  MapPin,
  MessageCircle,
  QrCode,
  SmartphoneNfc,
} from "lucide-react";

export const metrics = [
  { label: "Total QR scans", value: 284730, delta: "+18.4%", icon: QrCode },
  { label: "NFC taps", value: 81244, delta: "+11.2%", icon: SmartphoneNfc },
  { label: "Active campaigns", value: 42, delta: "+6 live", icon: CalendarRange },
  { label: "Conversion events", value: 12386, delta: "+9.8%", icon: BadgeCheck },
];

export const performance = [
  { day: "Mon", scans: 8200, taps: 2500, conversions: 640 },
  { day: "Tue", scans: 9300, taps: 3100, conversions: 780 },
  { day: "Wed", scans: 10800, taps: 3600, conversions: 910 },
  { day: "Thu", scans: 14100, taps: 4300, conversions: 1120 },
  { day: "Fri", scans: 13200, taps: 5100, conversions: 1240 },
  { day: "Sat", scans: 16400, taps: 5800, conversions: 1540 },
  { day: "Sun", scans: 18300, taps: 6100, conversions: 1710 },
];

export const dailyScans = [
  { date: "Apr 12", scans: 6400, nfc: 2100 },
  { date: "Apr 13", scans: 7200, nfc: 2400 },
  { date: "Apr 14", scans: 6900, nfc: 2600 },
  { date: "Apr 15", scans: 8800, nfc: 3100 },
  { date: "Apr 16", scans: 9400, nfc: 3900 },
  { date: "Apr 17", scans: 11000, nfc: 4200 },
  { date: "Apr 18", scans: 12800, nfc: 4900 },
  { date: "Apr 19", scans: 13700, nfc: 5200 },
];

export const deviceData = [
  { name: "iOS", value: 48 },
  { name: "Android", value: 34 },
  { name: "Desktop", value: 12 },
  { name: "Tablet", value: 6 },
];

export const locationData = [
  { city: "Dubai", scans: 28600 },
  { city: "Paris", scans: 21400 },
  { city: "Algiers", scans: 18700 },
  { city: "London", scans: 14200 },
  { city: "Doha", scans: 9800 },
];

export const campaignComparison = [
  { name: "Retail Drop", scans: 42000, conversions: 6900 },
  { name: "Hotel Menus", scans: 36500, conversions: 4100 },
  { name: "Creator Cards", scans: 29800, conversions: 5200 },
  { name: "Maps Push", scans: 24700, conversions: 3000 },
];

export const recentActivity = [
  { icon: Activity, title: "Scan spike detected", detail: "Retail Drop is 42% above its normal Friday baseline.", time: "2m ago" },
  { icon: Link2, title: "Destination updated", detail: "Maison Verve menu QR now points to spring-menu-v4.pdf.", time: "18m ago" },
  { icon: BellRing, title: "Broken link resolved", detail: "Google Maps campaign recovered after endpoint check.", time: "43m ago" },
  { icon: SmartphoneNfc, title: "Bulk NFC write complete", detail: "120 tags assigned to Northline Hotels.", time: "1h ago" },
];

export const qrAssets = [
  {
    id: "qr_01",
    name: "Maison Verve Menu",
    category: "Menu",
    client: "Maison Verve",
    destination: "https://maisonverve.com/menu/spring",
    scans: 48220,
    status: "Active",
    shortId: "mvmenu24",
  },
  {
    id: "qr_02",
    name: "Creator Instagram Card",
    category: "Instagram",
    client: "Astra Social",
    destination: "https://instagram.com/astra.studio",
    scans: 23140,
    status: "Active",
    shortId: "astraig",
  },
  {
    id: "qr_03",
    name: "Property Maps Launcher",
    category: "Google Maps",
    client: "Northline Hotels",
    destination: "https://maps.google.com/?q=northline",
    scans: 17420,
    status: "Paused",
    shortId: "nlmaps",
  },
  {
    id: "qr_04",
    name: "WhatsApp Concierge",
    category: "WhatsApp",
    client: "Blue Atlas",
    destination: "https://wa.me/15551234567",
    scans: 34210,
    status: "Active",
    shortId: "atlaswa",
  },
];

export const nfcTags = [
  { uid: "04:A2:19:7F:11:8B", name: "VIP Table 12", status: "Ready", client: "Maison Verve", lastTap: "4m ago", taps: 8410 },
  { uid: "04:B8:22:9C:45:10", name: "Lobby Smart Poster", status: "Writing", client: "Northline Hotels", lastTap: "18m ago", taps: 12440 },
  { uid: "04:DD:02:91:CB:44", name: "Creator Business Card", status: "Locked", client: "Astra Social", lastTap: "1h ago", taps: 2820 },
  { uid: "04:99:AC:21:33:7E", name: "Event Badge Batch A", status: "Ready", client: "Blue Atlas", lastTap: "2h ago", taps: 6120 },
];

export const campaigns = [
  {
    id: "cmp_01",
    name: "Retail Drop",
    client: "Astra Social",
    status: "Active",
    assets: 18,
    scans: 42000,
    owner: "Maya",
    stage: "Live",
    notes: "Influencer cards and launch posters.",
  },
  {
    id: "cmp_02",
    name: "Hotel Menus",
    client: "Northline Hotels",
    status: "Active",
    assets: 64,
    scans: 36500,
    owner: "Omar",
    stage: "Live",
    notes: "Restaurant menus and lobby NFC tags.",
  },
  {
    id: "cmp_03",
    name: "Maps Push",
    client: "Blue Atlas",
    status: "Planned",
    assets: 11,
    scans: 24700,
    owner: "Lina",
    stage: "Design",
    notes: "Local traffic campaign for city activations.",
  },
  {
    id: "cmp_04",
    name: "PDF Lookbook",
    client: "Maison Verve",
    status: "Paused",
    assets: 9,
    scans: 13100,
    owner: "Samir",
    stage: "Review",
    notes: "Awaiting final creative approval.",
  },
];

export const notifications = [
  "Astra Social scan volume is trending above forecast.",
  "Three QR destinations need SSL certificate checks.",
  "Maison Verve campaign expires in 5 days.",
];

export const clientPortalItems = [
  { label: "Active QR codes", value: "18", icon: QrCode },
  { label: "NFC touchpoints", value: "7", icon: SmartphoneNfc },
  { label: "Top city", value: "Dubai", icon: MapPin },
  { label: "Primary channel", value: "Instagram", icon: Globe2 },
  { label: "WhatsApp leads", value: "2.4k", icon: MessageCircle },
];
