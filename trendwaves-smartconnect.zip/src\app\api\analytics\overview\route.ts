import { subDays } from "date-fns";
import { NextRequest } from "next/server";
import { fail, guardRateLimit, handleApiError, ok } from "@/lib/api";
import { getAuthUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export const runtime = "nodejs";

export async function GET(request: NextRequest) {
  const limited = guardRateLimit(request, "analytics:overview", 240);
  if (limited) return limited;

  try {
    const user = await getAuthUser(request);
    if (!user) return fail("Unauthorized", 401);

    const since = subDays(new Date(), 30);
    const [
      totalScans,
      qrScans,
      nfcTaps,
      conversionEvents,
      uniqueVisitors,
      qrAssets,
      nfcAssets,
      activeCampaigns,
      topCampaigns,
      devices,
      recentEvents,
    ] =
      await Promise.all([
        prisma.scanEvent.count({ where: { createdAt: { gte: since } } }),
        prisma.scanEvent.count({ where: { createdAt: { gte: since }, kind: "QR" } }),
        prisma.scanEvent.count({ where: { createdAt: { gte: since }, kind: "NFC" } }),
        prisma.scanEvent.count({ where: { createdAt: { gte: since }, converted: true } }),
        prisma.scanEvent.groupBy({
          by: ["visitorId"],
          where: { createdAt: { gte: since }, visitorId: { not: null } },
        }),
        prisma.qrCode.count({ where: { status: "ACTIVE" } }),
        prisma.nfcTag.count({ where: { status: "ACTIVE" } }),
        prisma.campaign.count({ where: { status: "ACTIVE" } }),
        prisma.campaign.findMany({
          take: 5,
          orderBy: { updatedAt: "desc" },
          include: { client: true },
        }),
        prisma.scanEvent.groupBy({
          by: ["deviceType"],
          where: { createdAt: { gte: since } },
          _count: true,
        }),
        prisma.scanEvent.findMany({
          take: 20,
          orderBy: { createdAt: "desc" },
        }),
      ]);

    return ok({
      totalScans,
      qrScans,
      nfcTaps,
      conversionEvents,
      uniqueVisitors: uniqueVisitors.length,
      activeAssets: qrAssets + nfcAssets,
      activeCampaigns,
      topCampaigns,
      devices,
      recentEvents,
    });
  } catch (error) {
    return handleApiError(error);
  }
}
