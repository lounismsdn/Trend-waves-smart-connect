import { NextRequest, NextResponse } from "next/server";
import { ZodError, type ZodSchema } from "zod";
import { isRateLimited } from "@/lib/rate-limit";

export function getIp(request: NextRequest) {
  return (
    request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ||
    request.headers.get("x-real-ip") ||
    "127.0.0.1"
  );
}

export function ok<T>(data: T, init?: ResponseInit) {
  return NextResponse.json({ data }, init);
}

export function fail(message: string, status = 400, details?: unknown) {
  return NextResponse.json({ error: message, details }, { status });
}

export async function parseBody<T>(request: NextRequest, schema: ZodSchema<T>) {
  const body = await request.json();
  return schema.parse(body);
}

export function guardRateLimit(request: NextRequest, namespace: string, limit?: number) {
  const key = `${namespace}:${getIp(request)}`;
  if (isRateLimited(key, limit)) {
    return fail("Too many requests", 429);
  }

  return null;
}

export function handleApiError(error: unknown) {
  if (error instanceof ZodError) {
    return fail("Invalid request payload", 422, error.flatten());
  }

  if (error instanceof Error) {
    return fail(error.message, 500);
  }

  return fail("Unexpected server error", 500);
}
