import { Skeleton } from "@/components/ui/skeleton";

export default function Loading() {
  return (
    <div className="min-h-screen bg-[#050505] p-6">
      <div className="mx-auto grid max-w-7xl gap-4">
        <Skeleton className="h-16" />
        <div className="grid gap-4 md:grid-cols-4">
          <Skeleton className="h-36" />
          <Skeleton className="h-36" />
          <Skeleton className="h-36" />
          <Skeleton className="h-36" />
        </div>
        <Skeleton className="h-[420px]" />
      </div>
    </div>
  );
}
