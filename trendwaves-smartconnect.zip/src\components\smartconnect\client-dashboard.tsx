"use client";

/* eslint-disable @next/next/no-img-element */

import { motion } from "framer-motion";
import {
  BarChart3,
  CalendarDays,
  CheckCircle2,
  Copy,
  Download,
  Eye,
  FileDown,
  Grid3X3,
  KeyRound,
  LayoutDashboard,
  List,
  MapPin,
  Paintbrush,
  Pause,
  Pencil,
  Play,
  QrCode,
  Search,
  Settings,
  ShieldCheck,
  SmartphoneNfc,
  Trash2,
} from "lucide-react";
import QRCode from "qrcode";
import * as React from "react";
import { toast } from "sonner";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Line,
  LineChart,
  Pie,
  PieChart,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { formatNumber } from "@/lib/utils";

type ClientRecord = {
  id: string;
  name: string;
  slug: string;
  brandColor?: string | null;
  logoUrl?: string | null;
  permissions?: Record<string, unknown> | null;
  settings?: Record<string, unknown> | null;
};

type SessionUser = {
  id: string;
  name: string;
  email: string;
  role: "ADMIN" | "AGENCY" | "CLIENT";
  clientId?: string | null;
};

type ClientAsset = {
  id: string;
  kind: "QR" | "NFC";
  shortId: string;
  chipUid?: string;
  name: string;
  destinationUrl: string;
  status: string;
  client?: { name?: string } | null;
  campaign?: { id?: string; name?: string; status?: string } | null;
  scanCount?: number;
  tapCount?: number;
  uniqueVisitors?: number;
  lastScanAt?: string | null;
  lastTapAt?: string | null;
  createdAt?: string | null;
};

type CampaignRecord = {
  id: string;
  name: string;
  status: "PLANNED" | "ACTIVE" | "PAUSED" | "COMPLETED" | "EXPIRED";
  notes?: string | null;
  startAt?: string | null;
  endAt?: string | null;
  qrCodes?: unknown[];
  nfcTags?: unknown[];
};

type AnalyticsPayload = {
  client: ClientRecord | null;
  totals: {
    scans: number;
    unique: number;
    qrScans: number;
    nfcTaps: number;
    activeQrAssets: number;
    activeNfcTags: number;
    activeCampaigns: number;
    conversions: number;
    conversionRate: number;
  };
  dailyScans: Array<{ date: string; scans: number; unique: number }>;
  weeklyTrends: Array<{ week: string; scans: number; unique: number }>;
  monthlyPerformance: Array<{ month: string; date: string; scans: number; unique: number }>;
  devices: Array<{ name: string; value: number }>;
  locations: Array<{ name: string; value: number }>;
  browsers: Array<{ name: string; value: number }>;
  sources: Array<{ name: string; value: number }>;
  recentScans: Array<{
    id: string;
    kind: "QR" | "NFC";
    qrCodeId?: string | null;
    nfcTagId?: string | null;
    city?: string | null;
    country?: string | null;
    deviceType?: string | null;
    browser?: string | null;
    referrer?: string | null;
    createdAt: string;
  }>;
  assets: ClientAsset[];
  campaigns: CampaignRecord[];
};

type RangeMode = "today" | "7d" | "30d" | "custom";

const chartColors = ["#1500f5", "#ff7900", "#f8fafc", "#c2c8d2", "#38bdf8"];

function todayInput() {
  return new Date().toISOString().slice(0, 10);
}

function daysAgoInput(days: number) {
  const date = new Date();
  date.setDate(date.getDate() - days);
  return date.toISOString().slice(0, 10);
}

function statusVariant(status: string) {
  if (status === "ACTIVE" || status === "VERIFIED" || status === "WRITABLE") return "success" as const;
  if (status === "PAUSED" || status === "PLANNED") return "warning" as const;
  return "muted" as const;
}

function statusLabel(status: string) {
  return status.toLowerCase().replaceAll("_", " ").replace(/\b\w/g, (letter) => letter.toUpperCase());
}

function assetTotal(asset: ClientAsset) {
  return asset.kind === "QR" ? asset.scanCount ?? 0 : asset.tapCount ?? 0;
}

function assetLastScan(asset: ClientAsset) {
  const value = asset.kind === "QR" ? asset.lastScanAt : asset.lastTapAt;
  if (!value) return "No scans yet";
  return new Intl.DateTimeFormat("en", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" }).format(new Date(value));
}

function downloadBlob(blob: Blob, filename: string) {
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = filename;
  link.click();
  URL.revokeObjectURL(link.href);
}

function downloadText(content: string, filename: string, type = "text/csv") {
  downloadBlob(new Blob([content], { type }), filename);
}

async function apiJson<T>(url: string, init?: RequestInit): Promise<T> {
  const response = await fetch(url, {
    credentials: "include",
    ...init,
    headers: {
      ...(init?.body ? { "content-type": "application/json" } : {}),
      ...init?.headers,
    },
  });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body.error ?? "Request failed");
  return body.data as T;
}

function ClientQrThumb({ value }: { value: string }) {
  const [src, setSrc] = React.useState("");

  React.useEffect(() => {
    let active = true;
    QRCode.toDataURL(value || "https://trendwaves.app", {
      margin: 2,
      width: 520,
      color: { dark: "#050505", light: "#ffffff" },
    }).then((dataUrl) => {
      if (active) setSrc(dataUrl);
    });
    return () => {
      active = false;
    };
  }, [value]);

  if (!src) return <Skeleton className="aspect-square rounded-[18px]" />;
  return <img src={src} alt="QR asset preview" className="aspect-square rounded-[18px] bg-white p-2" />;
}

function ChartTooltip({ active, payload, label }: { active?: boolean; payload?: Array<{ name: string; value: number; color?: string }>; label?: string }) {
  if (!active || !payload?.length) return null;

  return (
    <div className="rounded-2xl border border-white/10 bg-[#050505]/95 px-3 py-2 text-xs shadow-2xl">
      <p className="mb-1 font-medium text-white">{label}</p>
      {payload.map((item) => (
        <p key={item.name} className="text-slate-300">
          {item.name}: {formatNumber(Number(item.value))}
        </p>
      ))}
    </div>
  );
}

function EmptyChart() {
  return (
    <div className="grid h-full min-h-56 place-items-center rounded-[18px] border border-white/10 bg-white/[0.035] text-center">
      <div>
        <BarChart3 className="mx-auto mb-3 h-6 w-6 text-slate-500" />
        <p className="text-sm text-slate-400">Analytics will appear after scans are tracked.</p>
      </div>
    </div>
  );
}

function ClientChartFrame({
  className,
  height,
  children,
}: {
  className: string;
  height: number;
  children: (width: number, height: number) => React.ReactNode;
}) {
  const ref = React.useRef<HTMLDivElement | null>(null);
  const [ready, setReady] = React.useState(false);
  const [width, setWidth] = React.useState(0);

  React.useEffect(() => {
    const node = ref.current;
    if (!node) return;

    const update = () => {
      const box = node.getBoundingClientRect();
      setWidth(Math.floor(box.width));
      setReady(box.width > 0 && box.height > 0);
    };

    const timer = window.setTimeout(update, 80);
    const observer = new ResizeObserver(update);
    observer.observe(node);
    return () => {
      window.clearTimeout(timer);
      observer.disconnect();
    };
  }, []);

  return (
    <div ref={ref} className={className}>
      {ready && width > 0 ? children(width, height) : <Skeleton className="h-full w-full rounded-[18px]" />}
    </div>
  );
}

function KpiCard({ label, value, detail, icon: Icon, index }: { label: string; value: string; detail: string; icon: React.ElementType; index: number }) {
  return (
    <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.045 }}>
      <Card className="h-full transition duration-300 hover:-translate-y-1 hover:border-[#ff7900]/35 hover:bg-white/[0.075]">
        <CardContent className="p-5">
          <div className="mb-8 flex items-center justify-between">
            <span className="grid h-11 w-11 place-items-center rounded-[18px] border border-white/10 bg-white/[0.06]">
              <Icon className="h-5 w-5 text-[#ff7900]" />
            </span>
            <Badge variant="cyan">Live</Badge>
          </div>
          <p className="text-xs uppercase tracking-[0.2em] text-slate-500">{label}</p>
          <p className="mt-2 font-display text-3xl font-black text-white">{value}</p>
          <p className="mt-2 text-sm text-slate-400">{detail}</p>
        </CardContent>
      </Card>
    </motion.div>
  );
}

export function ClientDashboardView() {
  const [clients, setClients] = React.useState<ClientRecord[]>([]);
  const [selectedClientId, setSelectedClientId] = React.useState("");
  const [analytics, setAnalytics] = React.useState<AnalyticsPayload | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [range, setRange] = React.useState<RangeMode>("30d");
  const [customFrom, setCustomFrom] = React.useState(daysAgoInput(30));
  const [customTo, setCustomTo] = React.useState(todayInput());
  const [view, setView] = React.useState<"grid" | "table">("grid");
  const [assetQuery, setAssetQuery] = React.useState("");
  const [selectedAsset, setSelectedAsset] = React.useState<ClientAsset | null>(null);
  const [editingAsset, setEditingAsset] = React.useState<ClientAsset | null>(null);
  const [editDestination, setEditDestination] = React.useState("");
  const [duplicateNfcAsset, setDuplicateNfcAsset] = React.useState<ClientAsset | null>(null);
  const [duplicateUid, setDuplicateUid] = React.useState("");
  const [saving, setSaving] = React.useState(false);
  const [brandColor, setBrandColor] = React.useState("#1500f5");
  const [logoUrl, setLogoUrl] = React.useState("");
  const [allowDestinationEdits, setAllowDestinationEdits] = React.useState(true);
  const [notificationsEnabled, setNotificationsEnabled] = React.useState(true);

  const selectedClient = analytics?.client ?? clients.find((client) => client.id === selectedClientId) ?? null;

  const analyticsQuery = React.useMemo(() => {
    const params = new URLSearchParams({ range });
    if (range === "custom") {
      params.set("from", customFrom);
      params.set("to", customTo);
    }
    return params.toString();
  }, [customFrom, customTo, range]);

  const loadAnalytics = React.useCallback(async () => {
    if (!selectedClientId) return;
    setLoading(true);
    try {
      const data = await apiJson<AnalyticsPayload>(`/api/analytics/client/${selectedClientId}?${analyticsQuery}`);
      setAnalytics(data);
      setBrandColor(data.client?.brandColor ?? "#1500f5");
      setLogoUrl(data.client?.logoUrl ?? "");
      setAllowDestinationEdits(Boolean(data.client?.permissions?.allowDestinationEdits ?? true));
      setNotificationsEnabled(Boolean(data.client?.settings?.notifications ?? true));
    } catch (error) {
      toast.error("Client analytics failed to load", {
        description: error instanceof Error ? error.message : "Refresh and try again.",
      });
    } finally {
      setLoading(false);
    }
  }, [analyticsQuery, selectedClientId]);

  React.useEffect(() => {
    let active = true;

    async function boot() {
      setLoading(true);
      try {
        const [user, clientList] = await Promise.all([
          apiJson<SessionUser>("/api/auth/me"),
          apiJson<ClientRecord[]>("/api/clients"),
        ]);
        if (!active) return;
        setClients(clientList);
        setSelectedClientId(user.clientId ?? clientList[0]?.id ?? "");
      } catch (error) {
        toast.error("Client dashboard could not start", {
          description: error instanceof Error ? error.message : "Check your login session.",
        });
        setLoading(false);
      }
    }

    boot();
    return () => {
      active = false;
    };
  }, []);

  React.useEffect(() => {
    loadAnalytics();
  }, [loadAnalytics]);

  const assets = React.useMemo(() => {
    return (analytics?.assets ?? []).filter((asset) => {
      const haystack = `${asset.name} ${asset.kind} ${asset.shortId} ${asset.destinationUrl} ${asset.client?.name ?? ""} ${asset.campaign?.name ?? ""}`.toLowerCase();
      return haystack.includes(assetQuery.toLowerCase());
    });
  }, [analytics?.assets, assetQuery]);

  const kpis = [
    {
      label: "Total scans",
      value: formatNumber(analytics?.totals.scans ?? 0),
      detail: `${formatNumber(analytics?.totals.unique ?? 0)} unique visitors`,
      icon: LayoutDashboard,
    },
    {
      label: "Active QR assets",
      value: formatNumber(analytics?.totals.activeQrAssets ?? 0),
      detail: `${formatNumber(analytics?.totals.qrScans ?? 0)} QR scans in range`,
      icon: QrCode,
    },
    {
      label: "Active NFC tags",
      value: formatNumber(analytics?.totals.activeNfcTags ?? 0),
      detail: `${formatNumber(analytics?.totals.nfcTaps ?? 0)} NFC taps in range`,
      icon: SmartphoneNfc,
    },
    {
      label: "Conversion metrics",
      value: `${analytics?.totals.conversionRate ?? 0}%`,
      detail: `${formatNumber(analytics?.totals.conversions ?? 0)} conversion events`,
      icon: CheckCircle2,
    },
  ];

  function openEdit(asset: ClientAsset) {
    setEditingAsset(asset);
    setEditDestination(asset.destinationUrl);
  }

  async function saveDestination(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!editingAsset) return;
    setSaving(true);
    try {
      if (editingAsset.kind === "QR") {
        await apiJson(`/api/qr/${editingAsset.id}`, {
          method: "PUT",
          body: JSON.stringify({ destinationUrl: editDestination }),
        });
      } else {
        await apiJson(`/api/nfc/${editingAsset.id}/update`, {
          method: "PUT",
          body: JSON.stringify({ destinationUrl: editDestination }),
        });
      }
      setEditingAsset(null);
      toast.success("Destination updated", { description: "The persistent short link and analytics history were preserved." });
      await loadAnalytics();
    } catch (error) {
      toast.error("Destination update failed", { description: error instanceof Error ? error.message : "Try again." });
    } finally {
      setSaving(false);
    }
  }

  async function duplicateAsset(asset: ClientAsset) {
    if (asset.kind === "NFC") {
      setDuplicateNfcAsset(asset);
      setDuplicateUid("");
      return;
    }

    try {
      const copy = await apiJson<ClientAsset>(`/api/qr/${asset.id}/duplicate`, { method: "POST" });
      toast.success("QR duplicated", { description: `/r/${copy.shortId} created with the same destination and style.` });
      await loadAnalytics();
    } catch (error) {
      toast.error("Duplicate failed", { description: error instanceof Error ? error.message : "Try again." });
    }
  }

  async function registerNfcDuplicate(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!duplicateNfcAsset || !selectedClientId) return;
    setSaving(true);
    try {
      await apiJson("/api/nfc/register", {
        method: "POST",
        body: JSON.stringify({
          chipUid: duplicateUid,
          name: `${duplicateNfcAsset.name} copy`,
          destinationUrl: duplicateNfcAsset.destinationUrl,
          clientId: selectedClientId,
          campaignId: duplicateNfcAsset.campaign?.id,
        }),
      });
      setDuplicateNfcAsset(null);
      toast.success("NFC tag registered", { description: "The copied destination is ready for Web NFC writing." });
      await loadAnalytics();
    } catch (error) {
      toast.error("NFC registration failed", { description: error instanceof Error ? error.message : "Try again." });
    } finally {
      setSaving(false);
    }
  }

  async function toggleAssetStatus(asset: ClientAsset) {
    const nextStatus = asset.status === "PAUSED" ? "ACTIVE" : "PAUSED";
    try {
      if (asset.kind === "QR") {
        await apiJson(`/api/qr/${asset.id}`, { method: "PUT", body: JSON.stringify({ status: nextStatus }) });
      } else {
        await apiJson(`/api/nfc/${asset.id}/update`, { method: "PUT", body: JSON.stringify({ status: nextStatus }) });
      }
      toast.success(nextStatus === "ACTIVE" ? "Asset resumed" : "Asset paused");
      await loadAnalytics();
    } catch (error) {
      toast.error("Status update failed", { description: error instanceof Error ? error.message : "Try again." });
    }
  }

  async function deleteAsset(asset: ClientAsset) {
    if (!window.confirm(`Delete "${asset.name}"? This action removes the asset and its analytics events.`)) return;
    try {
      await apiJson(`/api/${asset.kind === "QR" ? "qr" : "nfc"}/${asset.id}`, { method: "DELETE" });
      setSelectedAsset((current) => (current?.id === asset.id ? null : current));
      toast.success(`${asset.kind} asset deleted`);
      await loadAnalytics();
    } catch (error) {
      toast.error("Delete failed", { description: error instanceof Error ? error.message : "Try again." });
    }
  }

  async function exportQrAsset(asset: ClientAsset, format: "png" | "svg" | "pdf") {
    if (asset.kind !== "QR") {
      downloadText(
        `Name,UID,Destination,Status,Taps\n"${asset.name}","${asset.chipUid ?? ""}","${asset.destinationUrl}","${asset.status}",${assetTotal(asset)}`,
        `${asset.shortId}-nfc.csv`,
      );
      toast.success("NFC asset CSV exported");
      return;
    }

    try {
      const response = await fetch(`/api/qr/${asset.id}/export?format=${format}`, { credentials: "include" });
      if (!response.ok) throw new Error("Export failed");
      downloadBlob(await response.blob(), `${asset.shortId}.${format}`);
      toast.success(`${format.toUpperCase()} export started`);
    } catch (error) {
      toast.error("Export failed", { description: error instanceof Error ? error.message : "Try again." });
    }
  }

  async function exportClientReport(format: "csv" | "pdf") {
    if (!selectedClientId) return;
    try {
      const response = await fetch(`/api/export/client/${selectedClientId}?format=${format}&${analyticsQuery}`, { credentials: "include" });
      if (!response.ok) throw new Error("Report export failed");
      downloadBlob(await response.blob(), `client-analytics.${format}`);
      toast.success(`${format.toUpperCase()} analytics report exported`);
    } catch (error) {
      toast.error("Report export failed", { description: error instanceof Error ? error.message : "Try again." });
    }
  }

  async function saveSettings(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!selectedClientId) return;
    setSaving(true);
    try {
      await apiJson(`/api/clients/${selectedClientId}`, {
        method: "PUT",
        body: JSON.stringify({
          brandColor,
          logoUrl: logoUrl || undefined,
          permissions: { allowDestinationEdits },
          settings: { notifications: notificationsEnabled },
        }),
      });
      toast.success("Client settings saved");
      await loadAnalytics();
    } catch (error) {
      toast.error("Settings save failed", { description: error instanceof Error ? error.message : "Try again." });
    } finally {
      setSaving(false);
    }
  }

  async function updatePassword(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = event.currentTarget;
    const formData = new FormData(form);
    setSaving(true);
    try {
      await apiJson("/api/auth/password", {
        method: "POST",
        body: JSON.stringify({
          currentPassword: String(formData.get("currentPassword")),
          newPassword: String(formData.get("newPassword")),
        }),
      });
      form.reset();
      toast.success("Password updated");
    } catch (error) {
      toast.error("Password update failed", { description: error instanceof Error ? error.message : "Try again." });
    } finally {
      setSaving(false);
    }
  }

  const firstQr = assets.find((asset) => asset.kind === "QR");

  return (
    <div>
      <div className="mb-7 flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
        <div className="max-w-3xl">
          <p className="mb-3 text-xs font-semibold uppercase tracking-[0.28em] text-[#ff7900]">Client command center</p>
          <h1 className="font-display text-3xl font-black leading-tight text-white sm:text-4xl lg:text-5xl">
            Premium client dashboard for QR, NFC, campaigns, and exports.
          </h1>
          <p className="mt-4 max-w-2xl text-sm leading-6 text-slate-400 sm:text-base">
            A live portal for client-facing analytics, asset management, campaign monitoring, and brand settings.
          </p>
        </div>
        <div className="flex flex-col gap-3 sm:flex-row">
          {clients.length > 1 ? (
            <Select value={selectedClientId} onValueChange={setSelectedClientId}>
              <SelectTrigger className="w-full sm:w-64">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {clients.map((client) => (
                  <SelectItem key={client.id} value={client.id}>
                    {client.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          ) : null}
          <Button variant="secondary" onClick={() => exportClientReport("csv")}>
            <FileDown className="h-4 w-4" />
            Export CSV
          </Button>
          <Button onClick={() => exportClientReport("pdf")}>
            <Download className="h-4 w-4" />
            Export PDF
          </Button>
        </div>
      </div>

      {loading && !analytics ? (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          {Array.from({ length: 4 }).map((_, index) => (
            <Skeleton key={index} className="h-44 rounded-[18px]" />
          ))}
        </div>
      ) : null}

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {kpis.map((kpi, index) => (
          <KpiCard key={kpi.label} {...kpi} index={index} />
        ))}
      </div>

      <div className="mt-5 grid gap-5 xl:grid-cols-[1.3fr_0.7fr]">
        <Card>
          <CardHeader className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
            <div>
              <CardTitle>Analytics pulse</CardTitle>
              <CardDescription>Daily scans, weekly trends, monthly performance, and conversion lift</CardDescription>
            </div>
            <div className="flex flex-wrap gap-2">
              {(["today", "7d", "30d", "custom"] as RangeMode[]).map((item) => (
                <Button key={item} size="sm" variant={range === item ? "default" : "secondary"} onClick={() => setRange(item)}>
                  {item === "custom" ? "Custom" : item}
                </Button>
              ))}
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {range === "custom" ? (
              <div className="grid gap-3 sm:grid-cols-2">
                <Input type="date" value={customFrom} onChange={(event) => setCustomFrom(event.target.value)} />
                <Input type="date" value={customTo} onChange={(event) => setCustomTo(event.target.value)} />
              </div>
            ) : null}
            <ClientChartFrame className="h-[340px]" height={340}>
              {(width, height) => (
                analytics?.dailyScans.length ? (
                  <AreaChart width={width} height={height} data={analytics.dailyScans}>
                    <defs>
                      <linearGradient id="clientScanGradient" x1="0" x2="0" y1="0" y2="1">
                        <stop offset="0%" stopColor="#1500f5" stopOpacity={0.52} />
                        <stop offset="100%" stopColor="#1500f5" stopOpacity={0.02} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid stroke="rgba(255,255,255,0.07)" vertical={false} />
                    <XAxis dataKey="date" stroke="#64748b" tickLine={false} axisLine={false} />
                    <YAxis stroke="#64748b" tickLine={false} axisLine={false} />
                    <Tooltip content={<ChartTooltip />} />
                    <Area type="monotone" dataKey="scans" stroke="#1500f5" strokeWidth={3} fill="url(#clientScanGradient)" />
                    <Line type="monotone" dataKey="unique" stroke="#ff7900" strokeWidth={2} dot={false} />
                  </AreaChart>
                ) : (
                  <EmptyChart />
                )
              )}
            </ClientChartFrame>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Device analytics</CardTitle>
            <CardDescription>Traffic quality by device and browser</CardDescription>
          </CardHeader>
          <CardContent>
            <ClientChartFrame className="h-[250px]" height={250}>
              {(width, height) => (
                analytics?.devices.length ? (
                  <PieChart width={width} height={height}>
                    <Pie data={analytics.devices} dataKey="value" nameKey="name" innerRadius={64} outerRadius={96} paddingAngle={4}>
                      {analytics.devices.map((entry, index) => (
                        <Cell key={entry.name} fill={chartColors[index % chartColors.length]} />
                      ))}
                    </Pie>
                    <Tooltip content={<ChartTooltip />} />
                  </PieChart>
                ) : (
                  <EmptyChart />
                )
              )}
            </ClientChartFrame>
            <div className="grid gap-2 sm:grid-cols-2">
              {(analytics?.browsers ?? []).slice(0, 4).map((browser, index) => (
                <div key={browser.name} className="rounded-2xl border border-white/10 bg-white/[0.045] p-3">
                  <span className="mb-2 block h-2 w-8 rounded-full" style={{ backgroundColor: chartColors[index % chartColors.length] }} />
                  <p className="truncate text-sm text-white">{browser.name}</p>
                  <p className="text-xs text-slate-500">{formatNumber(browser.value)}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="mt-5 grid gap-5 xl:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Geographic analytics</CardTitle>
            <CardDescription>Top countries and cities by scan volume</CardDescription>
          </CardHeader>
          <CardContent>
            <ClientChartFrame className="h-[300px]" height={300}>
              {(width, height) => (
                analytics?.locations.length ? (
                  <BarChart width={width} height={height} data={analytics.locations.slice(0, 8)}>
                    <CartesianGrid stroke="rgba(255,255,255,0.07)" vertical={false} />
                    <XAxis dataKey="name" stroke="#64748b" tickLine={false} axisLine={false} />
                    <YAxis stroke="#64748b" tickLine={false} axisLine={false} />
                    <Tooltip content={<ChartTooltip />} />
                    <Bar dataKey="value" fill="#ff7900" radius={[12, 12, 0, 0]} />
                  </BarChart>
                ) : (
                  <EmptyChart />
                )
              )}
            </ClientChartFrame>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Monthly performance</CardTitle>
            <CardDescription>Grouped lift for client reporting and campaign pacing</CardDescription>
          </CardHeader>
          <CardContent>
            <ClientChartFrame className="h-[300px]" height={300}>
              {(width, height) => (
                analytics?.weeklyTrends.length ? (
                  <LineChart width={width} height={height} data={analytics.weeklyTrends}>
                    <CartesianGrid stroke="rgba(255,255,255,0.07)" vertical={false} />
                    <XAxis dataKey="week" stroke="#64748b" tickLine={false} axisLine={false} />
                    <YAxis stroke="#64748b" tickLine={false} axisLine={false} />
                    <Tooltip content={<ChartTooltip />} />
                    <Line type="monotone" dataKey="scans" stroke="#1500f5" strokeWidth={3} dot={false} />
                    <Line type="monotone" dataKey="unique" stroke="#ff7900" strokeWidth={2} dot={false} />
                  </LineChart>
                ) : (
                  <EmptyChart />
                )
              )}
            </ClientChartFrame>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="assets" className="mt-5">
        <TabsList className="flex h-auto flex-wrap">
          <TabsTrigger value="assets">Asset management</TabsTrigger>
          <TabsTrigger value="campaigns">Campaign monitor</TabsTrigger>
          <TabsTrigger value="exports">Export center</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
        </TabsList>

        <TabsContent value="assets">
          <Card>
            <CardHeader className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
              <div>
                <CardTitle>Client assets</CardTitle>
                <CardDescription>Grid and table views for QR codes and NFC touchpoints</CardDescription>
              </div>
              <div className="flex flex-col gap-3 sm:flex-row">
                <div className="flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.05] px-4">
                  <Search className="h-4 w-4 text-slate-500" />
                  <Input
                    value={assetQuery}
                    onChange={(event) => setAssetQuery(event.target.value)}
                    placeholder="Search assets"
                    className="border-0 bg-transparent px-0 focus:bg-transparent"
                  />
                </div>
                <div className="flex rounded-full border border-white/10 bg-white/[0.05] p-1">
                  <Button size="icon" variant={view === "grid" ? "default" : "ghost"} onClick={() => setView("grid")} aria-label="Grid view">
                    <Grid3X3 className="h-4 w-4" />
                  </Button>
                  <Button size="icon" variant={view === "table" ? "default" : "ghost"} onClick={() => setView("table")} aria-label="Table view">
                    <List className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {view === "grid" ? (
                <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
                  {assets.map((asset) => (
                    <div
                      key={`${asset.kind}-${asset.id}`}
                      role="button"
                      tabIndex={0}
                      onClick={() => setSelectedAsset(asset)}
                      onKeyDown={(event) => {
                        if (event.key === "Enter" || event.key === " ") {
                          event.preventDefault();
                          setSelectedAsset(asset);
                        }
                      }}
                      className="group rounded-[18px] border border-white/10 bg-white/[0.045] p-4 text-left transition duration-300 hover:-translate-y-1 hover:border-[#ff7900]/35 hover:bg-white/[0.075]"
                    >
                      <div className="mb-4 grid grid-cols-[88px_1fr] gap-4">
                        {asset.kind === "QR" ? (
                          <ClientQrThumb value={`/r/${asset.shortId}`} />
                        ) : (
                          <div className="grid aspect-square place-items-center rounded-[18px] border border-white/10 bg-white/[0.06]">
                            <SmartphoneNfc className="h-8 w-8 text-[#ff7900]" />
                          </div>
                        )}
                        <div className="min-w-0">
                          <div className="mb-2 flex items-center gap-2">
                            <Badge variant={asset.kind === "QR" ? "cyan" : "warning"}>{asset.kind}</Badge>
                            <Badge variant={statusVariant(asset.status)}>{statusLabel(asset.status)}</Badge>
                          </div>
                          <p className="truncate font-display text-lg font-black text-white">{asset.name}</p>
                          <p className="mt-1 truncate text-sm text-slate-400">{asset.client?.name ?? selectedClient?.name ?? "Client"}</p>
                        </div>
                      </div>
                      <div className="grid gap-2">
                        <div className="flex items-end justify-between">
                          <div>
                            <p className="font-display text-2xl font-black text-white">{formatNumber(assetTotal(asset))}</p>
                            <p className="text-xs text-slate-500">{formatNumber(asset.uniqueVisitors ?? 0)} unique</p>
                          </div>
                          <p className="text-xs text-slate-400">{assetLastScan(asset)}</p>
                        </div>
                        <div className="h-2 rounded-full bg-white/[0.06]">
                          <div
                            className="h-full rounded-full bg-[#ff7900]"
                            style={{ width: `${Math.max(12, Math.min(100, assetTotal(asset) % 100))}%` }}
                          />
                        </div>
                      </div>
                      <div className="mt-4 flex flex-wrap gap-2">
                        <Button size="sm" variant="secondary" type="button" onClick={(event) => { event.stopPropagation(); setSelectedAsset(asset); }}>
                          <Eye className="h-4 w-4" />
                          View
                        </Button>
                        <Button size="sm" variant="ghost" type="button" onClick={(event) => { event.stopPropagation(); openEdit(asset); }}>
                          <Pencil className="h-4 w-4" />
                          Edit
                        </Button>
                        <Button size="sm" variant="ghost" type="button" onClick={(event) => { event.stopPropagation(); duplicateAsset(asset); }}>
                          <Copy className="h-4 w-4" />
                          Duplicate
                        </Button>
                        <Button size="sm" variant="ghost" type="button" onClick={(event) => { event.stopPropagation(); exportQrAsset(asset, "png"); }}>
                          <Download className="h-4 w-4" />
                          Export
                        </Button>
                        <Button size="sm" variant="ghost" type="button" onClick={(event) => { event.stopPropagation(); toggleAssetStatus(asset); }}>
                          {asset.status === "PAUSED" ? <Play className="h-4 w-4" /> : <Pause className="h-4 w-4" />}
                          {asset.status === "PAUSED" ? "Resume" : "Pause"}
                        </Button>
                        <Button size="sm" variant="destructive" type="button" onClick={(event) => { event.stopPropagation(); deleteAsset(asset); }}>
                          <Trash2 className="h-4 w-4" />
                          Delete
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full min-w-[900px] text-left text-sm">
                    <thead className="border-y border-white/10 text-xs uppercase tracking-[0.16em] text-slate-500">
                      <tr>
                        <th className="px-4 py-4">Asset</th>
                        <th className="px-4 py-4">Type</th>
                        <th className="px-4 py-4">Status</th>
                        <th className="px-4 py-4">Scans</th>
                        <th className="px-4 py-4">Last scan</th>
                        <th className="px-4 py-4 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {assets.map((asset) => (
                        <tr key={`${asset.kind}-${asset.id}`} className="border-b border-white/5 transition hover:bg-white/[0.04]">
                          <td className="px-4 py-4">
                            <p className="font-medium text-white">{asset.name}</p>
                            <p className="text-xs text-slate-500">/r/{asset.shortId}</p>
                          </td>
                          <td className="px-4 py-4 text-slate-400">{asset.kind}</td>
                          <td className="px-4 py-4"><Badge variant={statusVariant(asset.status)}>{statusLabel(asset.status)}</Badge></td>
                          <td className="px-4 py-4 text-slate-400">{formatNumber(assetTotal(asset))}</td>
                          <td className="px-4 py-4 text-slate-400">{assetLastScan(asset)}</td>
                          <td className="px-4 py-4">
                            <div className="flex justify-end gap-1">
                              <Button size="icon" variant="ghost" aria-label="View asset" onClick={() => setSelectedAsset(asset)}><Eye className="h-4 w-4" /></Button>
                              <Button size="icon" variant="ghost" aria-label="Edit asset" onClick={() => openEdit(asset)}><Pencil className="h-4 w-4" /></Button>
                              <Button size="icon" variant="ghost" aria-label="Duplicate asset" onClick={() => duplicateAsset(asset)}><Copy className="h-4 w-4" /></Button>
                              <Button size="icon" variant="ghost" aria-label="Export asset" onClick={() => exportQrAsset(asset, "png")}><Download className="h-4 w-4" /></Button>
                              <Button size="icon" variant="ghost" aria-label="Pause or resume asset" onClick={() => toggleAssetStatus(asset)}>
                                {asset.status === "PAUSED" ? <Play className="h-4 w-4" /> : <Pause className="h-4 w-4" />}
                              </Button>
                              <Button size="icon" variant="destructive" aria-label="Delete asset" onClick={() => deleteAsset(asset)}><Trash2 className="h-4 w-4" /></Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
              {assets.length === 0 ? (
                <div className="grid min-h-52 place-items-center text-center">
                  <div>
                    <Search className="mx-auto mb-3 h-7 w-7 text-slate-500" />
                    <p className="font-display text-xl font-black text-white">No assets match this view</p>
                    <p className="mt-2 text-sm text-slate-400">Create QR/NFC assets or clear the search filter.</p>
                  </div>
                </div>
              ) : null}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="campaigns">
          <div className="grid gap-4 xl:grid-cols-4">
            {[
              ["Draft", "PLANNED"],
              ["Active", "ACTIVE"],
              ["Paused", "PAUSED"],
              ["Completed", "COMPLETED"],
            ].map(([label, status]) => (
              <Card key={status}>
                <CardHeader>
                  <CardTitle>{label}</CardTitle>
                  <CardDescription>{(analytics?.campaigns ?? []).filter((campaign) => campaign.status === status).length} campaigns</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  {(analytics?.campaigns ?? [])
                    .filter((campaign) => campaign.status === status)
                    .map((campaign) => (
                      <div key={campaign.id} className="rounded-[18px] border border-white/10 bg-white/[0.045] p-4">
                        <Badge variant={statusVariant(campaign.status)}>{statusLabel(campaign.status)}</Badge>
                        <p className="mt-3 font-display text-lg font-black text-white">{campaign.name}</p>
                        <p className="mt-2 text-sm text-slate-400">{campaign.notes ?? "No notes"}</p>
                        <div className="mt-4 flex items-center justify-between text-xs text-slate-500">
                          <span>{(campaign.qrCodes?.length ?? 0) + (campaign.nfcTags?.length ?? 0)} assets</span>
                          <span>{campaign.endAt ? new Date(campaign.endAt).toLocaleDateString() : "No end date"}</span>
                        </div>
                      </div>
                    ))}
                  {(analytics?.campaigns ?? []).filter((campaign) => campaign.status === status).length === 0 ? (
                    <div className="rounded-[18px] border border-dashed border-white/10 p-6 text-center text-sm text-slate-500">No campaigns</div>
                  ) : null}
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="exports">
          <Card>
            <CardHeader>
              <CardTitle>Export center</CardTitle>
              <CardDescription>Download client reports and print-ready QR assets</CardDescription>
            </CardHeader>
            <CardContent className="grid gap-4 md:grid-cols-2 xl:grid-cols-5">
              <Button variant="secondary" onClick={() => firstQr ? exportQrAsset(firstQr, "png") : toast.error("No QR asset available")}>
                <QrCode className="h-4 w-4" />
                PNG
              </Button>
              <Button variant="secondary" onClick={() => firstQr ? exportQrAsset(firstQr, "svg") : toast.error("No QR asset available")}>
                <Paintbrush className="h-4 w-4" />
                SVG
              </Button>
              <Button variant="secondary" onClick={() => firstQr ? exportQrAsset(firstQr, "pdf") : toast.error("No QR asset available")}>
                <FileDown className="h-4 w-4" />
                PDF
              </Button>
              <Button variant="secondary" onClick={() => exportClientReport("csv")}>
                <Download className="h-4 w-4" />
                CSV report
              </Button>
              <Button onClick={() => exportClientReport("pdf")}>
                <BarChart3 className="h-4 w-4" />
                PDF report
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="settings">
          <div className="grid gap-5 xl:grid-cols-[1fr_0.8fr]">
            <Card>
              <CardHeader>
                <CardTitle>Client branding and permissions</CardTitle>
                <CardDescription>Brand layer used across exports and client-facing surfaces</CardDescription>
              </CardHeader>
              <CardContent>
                <form className="space-y-4" onSubmit={saveSettings}>
                  <label className="space-y-2">
                    <span className="text-sm text-slate-400">Brand color</span>
                    <input className="h-11 w-full rounded-full border border-white/10 bg-transparent p-1" type="color" value={brandColor} onChange={(event) => setBrandColor(event.target.value)} />
                  </label>
                  <label className="space-y-2">
                    <span className="text-sm text-slate-400">Logo URL</span>
                    <Input value={logoUrl} onChange={(event) => setLogoUrl(event.target.value)} placeholder="https://..." />
                  </label>
                  <div className="grid gap-3 sm:grid-cols-2">
                    <div className="flex items-center justify-between rounded-[18px] border border-white/10 bg-white/[0.045] p-4">
                      <div>
                        <p className="font-medium text-white">Destination edits</p>
                        <p className="text-xs text-slate-500">Client can update QR/NFC URLs</p>
                      </div>
                      <Switch checked={allowDestinationEdits} onCheckedChange={setAllowDestinationEdits} />
                    </div>
                    <div className="flex items-center justify-between rounded-[18px] border border-white/10 bg-white/[0.045] p-4">
                      <div>
                        <p className="font-medium text-white">Notifications</p>
                        <p className="text-xs text-slate-500">Send scan spike alerts</p>
                      </div>
                      <Switch checked={notificationsEnabled} onCheckedChange={setNotificationsEnabled} />
                    </div>
                  </div>
                  <Button type="submit" disabled={saving}>
                    <Settings className="h-4 w-4" />
                    {saving ? "Saving..." : "Save settings"}
                  </Button>
                </form>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Password</CardTitle>
                <CardDescription>Update the signed-in account password</CardDescription>
              </CardHeader>
              <CardContent>
                <form className="space-y-4" onSubmit={updatePassword}>
                  <Input name="currentPassword" type="password" placeholder="Current password" required />
                  <Input name="newPassword" type="password" placeholder="New password" minLength={10} required />
                  <Button type="submit" variant="secondary" disabled={saving}>
                    <KeyRound className="h-4 w-4" />
                    Update password
                  </Button>
                </form>
                <div className="mt-5 rounded-[18px] border border-white/10 bg-white/[0.045] p-4 text-sm text-slate-400">
                  <ShieldCheck className="mb-3 h-5 w-5 text-[#ff7900]" />
                  Session cookies are HTTP-only and API mutations are audited.
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      <Dialog open={Boolean(selectedAsset)} onOpenChange={(open) => !open && setSelectedAsset(null)}>
        <DialogContent className="max-h-[90vh] max-w-5xl overflow-y-auto">
          {selectedAsset ? (
            <>
              <DialogHeader>
                <DialogTitle className="font-display text-3xl font-black">{selectedAsset.name}</DialogTitle>
                <DialogDescription>
                  {selectedAsset.kind} asset /r/{selectedAsset.shortId} for {selectedAsset.client?.name ?? selectedClient?.name ?? "client"}
                </DialogDescription>
              </DialogHeader>
              <div className="mt-5 grid gap-5 xl:grid-cols-[0.75fr_1.25fr]">
                <div className="rounded-[26px] border border-white/10 bg-white/[0.045] p-4">
                  {selectedAsset.kind === "QR" ? (
                    <ClientQrThumb value={`/r/${selectedAsset.shortId}`} />
                  ) : (
                    <div className="grid aspect-square place-items-center rounded-[18px] border border-white/10 bg-white/[0.06]">
                      <SmartphoneNfc className="h-16 w-16 text-[#ff7900]" />
                    </div>
                  )}
                  <div className="mt-4 grid gap-2 sm:grid-cols-2">
                    <Button variant="secondary" onClick={() => navigator.clipboard.writeText(`${window.location.origin}/r/${selectedAsset.shortId}`).then(() => toast.success("Redirect link copied"))}>
                      <Copy className="h-4 w-4" />
                      Copy link
                    </Button>
                    <Button onClick={() => exportQrAsset(selectedAsset, "png")}>
                      <Download className="h-4 w-4" />
                      Export
                    </Button>
                  </div>
                </div>
                <div className="grid gap-4">
                  <div className="grid gap-4 sm:grid-cols-3">
                    <div className="rounded-[18px] border border-white/10 bg-white/[0.045] p-4">
                      <BarChart3 className="mb-5 h-5 w-5 text-[#ff7900]" />
                      <p className="text-xs uppercase tracking-[0.18em] text-slate-500">Total</p>
                      <p className="mt-2 font-display text-3xl font-black text-white">{formatNumber(assetTotal(selectedAsset))}</p>
                    </div>
                    <div className="rounded-[18px] border border-white/10 bg-white/[0.045] p-4">
                      <MapPin className="mb-5 h-5 w-5 text-[#ff7900]" />
                      <p className="text-xs uppercase tracking-[0.18em] text-slate-500">Top location</p>
                      <p className="mt-2 text-lg font-semibold text-white">{analytics?.locations[0]?.name ?? "Unknown"}</p>
                    </div>
                    <div className="rounded-[18px] border border-white/10 bg-white/[0.045] p-4">
                      <CalendarDays className="mb-5 h-5 w-5 text-[#ff7900]" />
                      <p className="text-xs uppercase tracking-[0.18em] text-slate-500">Last scan</p>
                      <p className="mt-2 text-lg font-semibold text-white">{assetLastScan(selectedAsset)}</p>
                    </div>
                  </div>
                  <div className="rounded-[18px] border border-white/10 bg-white/[0.045] p-4">
                    <p className="text-xs uppercase tracking-[0.18em] text-slate-500">Destination URL</p>
                    <p className="mt-2 break-words text-white">{selectedAsset.destinationUrl}</p>
                  </div>
                  <div className="grid gap-2 sm:grid-cols-3">
                    {analytics?.recentScans
                      .filter((scan) => scan.qrCodeId === selectedAsset.id || scan.nfcTagId === selectedAsset.id)
                      .slice(0, 6)
                      .map((scan) => (
                        <div key={scan.id} className="rounded-2xl border border-white/10 bg-white/[0.04] p-3 text-sm">
                          <p className="text-white">{scan.city ?? "Unknown city"}</p>
                          <p className="text-xs text-slate-500">{scan.deviceType ?? "Unknown device"} / {scan.browser ?? "Unknown browser"}</p>
                        </div>
                      ))}
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <Button variant="secondary" onClick={() => openEdit(selectedAsset)}><Pencil className="h-4 w-4" />Edit destination</Button>
                    <Button variant="secondary" onClick={() => duplicateAsset(selectedAsset)}><Copy className="h-4 w-4" />Duplicate</Button>
                    <Button variant="secondary" onClick={() => toggleAssetStatus(selectedAsset)}>
                      {selectedAsset.status === "PAUSED" ? <Play className="h-4 w-4" /> : <Pause className="h-4 w-4" />}
                      {selectedAsset.status === "PAUSED" ? "Resume" : "Pause"}
                    </Button>
                    <Button variant="destructive" onClick={() => deleteAsset(selectedAsset)}><Trash2 className="h-4 w-4" />Delete</Button>
                  </div>
                </div>
              </div>
            </>
          ) : null}
        </DialogContent>
      </Dialog>

      <Dialog open={Boolean(editingAsset)} onOpenChange={(open) => !open && setEditingAsset(null)}>
        <DialogContent className="max-w-xl">
          <DialogHeader>
            <DialogTitle>Edit destination</DialogTitle>
            <DialogDescription>Updates the destination while keeping short ID, analytics, and campaign history intact.</DialogDescription>
          </DialogHeader>
          <form className="mt-5 space-y-4" onSubmit={saveDestination}>
            <Input type="url" value={editDestination} onChange={(event) => setEditDestination(event.target.value)} required />
            <div className="grid gap-3 sm:grid-cols-2">
              <Button type="button" variant="secondary" onClick={() => setEditingAsset(null)}>Cancel</Button>
              <Button type="submit" disabled={saving}>{saving ? "Saving..." : "Save destination"}</Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog open={Boolean(duplicateNfcAsset)} onOpenChange={(open) => !open && setDuplicateNfcAsset(null)}>
        <DialogContent className="max-w-xl">
          <DialogHeader>
            <DialogTitle>Register duplicate NFC tag</DialogTitle>
            <DialogDescription>Enter the physical chip UID. The destination is copied and the tag stays dynamic.</DialogDescription>
          </DialogHeader>
          <form className="mt-5 space-y-4" onSubmit={registerNfcDuplicate}>
            <Input value={duplicateUid} onChange={(event) => setDuplicateUid(event.target.value)} placeholder="04:A2:19:7F:11:8B" required />
            <div className="grid gap-3 sm:grid-cols-2">
              <Button type="button" variant="secondary" onClick={() => setDuplicateNfcAsset(null)}>Cancel</Button>
              <Button type="submit" disabled={saving}>{saving ? "Registering..." : "Register tag"}</Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
