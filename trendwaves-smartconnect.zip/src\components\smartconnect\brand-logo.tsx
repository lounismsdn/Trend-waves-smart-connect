import { cn } from "@/lib/utils";

type BrandLogoProps = {
  className?: string;
  markClassName?: string;
  withText?: boolean;
  withTm?: boolean;
  textClassName?: string;
  tone?: "blue" | "orange" | "white";
};

const toneClass = {
  blue: "text-[#1500f5]",
  orange: "text-[#ff7900]",
  white: "text-white",
};

export function TrendWavesMark({
  className,
  tone = "blue",
  withTm = true,
}: {
  className?: string;
  tone?: BrandLogoProps["tone"];
  withTm?: boolean;
}) {
  return (
    <svg
      viewBox="0 0 337 99"
      aria-hidden="true"
      className={cn("h-8 w-28", toneClass[tone], className)}
      fill="currentColor"
    >
      <path
        d="M0 0H63L79 16V65L193 0L210 10V65L321 0L335 27L204 99L184 88V39L72 99L53 88V26H0V0Z"
        fill="currentColor"
      />
      {withTm ? (
        <text
          x="284"
          y="98"
          fill="currentColor"
          fontFamily="Arial Black, Arial, sans-serif"
          fontSize="38"
          fontWeight="900"
          letterSpacing="-2"
        >
          TM
        </text>
      ) : null}
    </svg>
  );
}

export function TrendWavesLogo({
  className,
  markClassName,
  textClassName,
  withText = true,
  withTm = true,
  tone = "blue",
}: BrandLogoProps) {
  return (
    <div className={cn("flex items-center gap-3", className)}>
      <TrendWavesMark tone={tone} withTm={withTm} className={markClassName} />
      {withText ? (
        <span className={cn("font-display text-xl font-black leading-none tracking-0", toneClass[tone], textClassName)}>
          Trend waves
        </span>
      ) : null}
    </div>
  );
}
