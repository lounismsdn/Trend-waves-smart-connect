-- CreateEnum
CREATE TYPE "NFCTagType" AS ENUM ('NTAG213', 'NTAG215', 'NTAG216', 'MIFARE_ULTRALIGHT', 'UNKNOWN');

-- CreateEnum
CREATE TYPE "NFCOperationalStatus" AS ENUM ('UNREGISTERED', 'REGISTERED', 'WRITABLE', 'WRITTEN', 'VERIFIED', 'LOCKED', 'INACTIVE', 'ERROR');

-- CreateEnum
CREATE TYPE "NFCWriteStatus" AS ENUM ('PENDING', 'WRITTEN', 'VERIFIED', 'FAILED', 'LOCKED');

-- CreateEnum
CREATE TYPE "ExportJobStatus" AS ENUM ('QUEUED', 'PROCESSING', 'COMPLETED', 'FAILED');

-- AlterTable
ALTER TABLE "Client" ADD COLUMN     "brandColor" TEXT,
ADD COLUMN     "branding" JSONB,
ADD COLUMN     "logoUrl" TEXT,
ADD COLUMN     "permissions" JSONB,
ADD COLUMN     "settings" JSONB;

-- AlterTable
ALTER TABLE "NFCTags" ADD COLUMN     "isWritable" BOOLEAN NOT NULL DEFAULT true,
ADD COLUMN     "lastWriteAt" TIMESTAMP(3),
ADD COLUMN     "memorySize" INTEGER NOT NULL DEFAULT 144,
ADD COLUMN     "operationalStatus" "NFCOperationalStatus" NOT NULL DEFAULT 'REGISTERED',
ADD COLUMN     "tagType" "NFCTagType" NOT NULL DEFAULT 'NTAG213',
ADD COLUMN     "writeMode" TEXT NOT NULL DEFAULT 'DYNAMIC_REDIRECT',
ADD COLUMN     "writtenPayload" TEXT;

-- AlterTable
ALTER TABLE "QRCodes" ADD COLUMN     "designChecksum" TEXT,
ADD COLUMN     "designVersion" INTEGER NOT NULL DEFAULT 1,
ADD COLUMN     "stylePresetId" TEXT;

-- CreateTable
CREATE TABLE "QRStylePreset" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "description" TEXT,
    "clientId" TEXT,
    "design" JSONB NOT NULL,
    "isSystem" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "QRStylePreset_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "QrDesignVersion" (
    "id" TEXT NOT NULL,
    "qrCodeId" TEXT NOT NULL,
    "version" INTEGER NOT NULL,
    "design" JSONB NOT NULL,
    "changes" JSONB,
    "editorId" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "QrDesignVersion_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "NFCWriteLog" (
    "id" TEXT NOT NULL,
    "tagId" TEXT NOT NULL,
    "writerId" TEXT,
    "payload" TEXT NOT NULL,
    "previousPayload" TEXT,
    "status" "NFCWriteStatus" NOT NULL DEFAULT 'PENDING',
    "verificationResult" JSONB,
    "errorMessage" TEXT,
    "metadata" JSONB,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "NFCWriteLog_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "AnalyticsSnapshot" (
    "id" TEXT NOT NULL,
    "clientId" TEXT,
    "campaignId" TEXT,
    "qrCodeId" TEXT,
    "nfcTagId" TEXT,
    "periodStart" TIMESTAMP(3) NOT NULL,
    "periodEnd" TIMESTAMP(3) NOT NULL,
    "totals" JSONB NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "AnalyticsSnapshot_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ExportJob" (
    "id" TEXT NOT NULL,
    "type" TEXT NOT NULL,
    "format" TEXT NOT NULL,
    "status" "ExportJobStatus" NOT NULL DEFAULT 'COMPLETED',
    "assetType" TEXT,
    "assetId" TEXT,
    "qrCodeId" TEXT,
    "nfcTagId" TEXT,
    "clientId" TEXT,
    "requesterId" TEXT,
    "fileUrl" TEXT,
    "metadata" JSONB,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "completedAt" TIMESTAMP(3),

    CONSTRAINT "ExportJob_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "QRStylePreset_clientId_idx" ON "QRStylePreset"("clientId");

-- CreateIndex
CREATE INDEX "QRStylePreset_isSystem_idx" ON "QRStylePreset"("isSystem");

-- CreateIndex
CREATE UNIQUE INDEX "QRStylePreset_clientId_name_key" ON "QRStylePreset"("clientId", "name");

-- CreateIndex
CREATE INDEX "QrDesignVersion_qrCodeId_idx" ON "QrDesignVersion"("qrCodeId");

-- CreateIndex
CREATE INDEX "QrDesignVersion_editorId_idx" ON "QrDesignVersion"("editorId");

-- CreateIndex
CREATE UNIQUE INDEX "QrDesignVersion_qrCodeId_version_key" ON "QrDesignVersion"("qrCodeId", "version");

-- CreateIndex
CREATE INDEX "NFCWriteLog_tagId_idx" ON "NFCWriteLog"("tagId");

-- CreateIndex
CREATE INDEX "NFCWriteLog_writerId_idx" ON "NFCWriteLog"("writerId");

-- CreateIndex
CREATE INDEX "NFCWriteLog_status_idx" ON "NFCWriteLog"("status");

-- CreateIndex
CREATE INDEX "NFCWriteLog_createdAt_idx" ON "NFCWriteLog"("createdAt");

-- CreateIndex
CREATE INDEX "AnalyticsSnapshot_clientId_idx" ON "AnalyticsSnapshot"("clientId");

-- CreateIndex
CREATE INDEX "AnalyticsSnapshot_campaignId_idx" ON "AnalyticsSnapshot"("campaignId");

-- CreateIndex
CREATE INDEX "AnalyticsSnapshot_qrCodeId_idx" ON "AnalyticsSnapshot"("qrCodeId");

-- CreateIndex
CREATE INDEX "AnalyticsSnapshot_nfcTagId_idx" ON "AnalyticsSnapshot"("nfcTagId");

-- CreateIndex
CREATE INDEX "AnalyticsSnapshot_periodStart_periodEnd_idx" ON "AnalyticsSnapshot"("periodStart", "periodEnd");

-- CreateIndex
CREATE INDEX "ExportJob_status_idx" ON "ExportJob"("status");

-- CreateIndex
CREATE INDEX "ExportJob_type_format_idx" ON "ExportJob"("type", "format");

-- CreateIndex
CREATE INDEX "ExportJob_qrCodeId_idx" ON "ExportJob"("qrCodeId");

-- CreateIndex
CREATE INDEX "ExportJob_nfcTagId_idx" ON "ExportJob"("nfcTagId");

-- CreateIndex
CREATE INDEX "ExportJob_clientId_idx" ON "ExportJob"("clientId");

-- CreateIndex
CREATE INDEX "ExportJob_requesterId_idx" ON "ExportJob"("requesterId");

-- CreateIndex
CREATE INDEX "NFCTags_operationalStatus_idx" ON "NFCTags"("operationalStatus");

-- CreateIndex
CREATE INDEX "QRCodes_stylePresetId_idx" ON "QRCodes"("stylePresetId");

-- AddForeignKey
ALTER TABLE "QRCodes" ADD CONSTRAINT "QRCodes_stylePresetId_fkey" FOREIGN KEY ("stylePresetId") REFERENCES "QRStylePreset"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "QRStylePreset" ADD CONSTRAINT "QRStylePreset_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES "Client"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "QrDesignVersion" ADD CONSTRAINT "QrDesignVersion_qrCodeId_fkey" FOREIGN KEY ("qrCodeId") REFERENCES "QRCodes"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "QrDesignVersion" ADD CONSTRAINT "QrDesignVersion_editorId_fkey" FOREIGN KEY ("editorId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "NFCWriteLog" ADD CONSTRAINT "NFCWriteLog_tagId_fkey" FOREIGN KEY ("tagId") REFERENCES "NFCTags"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "NFCWriteLog" ADD CONSTRAINT "NFCWriteLog_writerId_fkey" FOREIGN KEY ("writerId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "AnalyticsSnapshot" ADD CONSTRAINT "AnalyticsSnapshot_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES "Client"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "AnalyticsSnapshot" ADD CONSTRAINT "AnalyticsSnapshot_campaignId_fkey" FOREIGN KEY ("campaignId") REFERENCES "Campaign"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "AnalyticsSnapshot" ADD CONSTRAINT "AnalyticsSnapshot_qrCodeId_fkey" FOREIGN KEY ("qrCodeId") REFERENCES "QRCodes"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "AnalyticsSnapshot" ADD CONSTRAINT "AnalyticsSnapshot_nfcTagId_fkey" FOREIGN KEY ("nfcTagId") REFERENCES "NFCTags"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ExportJob" ADD CONSTRAINT "ExportJob_qrCodeId_fkey" FOREIGN KEY ("qrCodeId") REFERENCES "QRCodes"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ExportJob" ADD CONSTRAINT "ExportJob_nfcTagId_fkey" FOREIGN KEY ("nfcTagId") REFERENCES "NFCTags"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ExportJob" ADD CONSTRAINT "ExportJob_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES "Client"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ExportJob" ADD CONSTRAINT "ExportJob_requesterId_fkey" FOREIGN KEY ("requesterId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;
