import { AppShell } from "@/components/smartconnect/app-shell";
import { NFCManagerView } from "@/components/smartconnect/views";
import { requirePageAuth } from "@/lib/server-auth";

export default async function NFCManagerPage() {
  await requirePageAuth("/nfc-manager");

  return (
    <AppShell>
      <NFCManagerView />
    </AppShell>
  );
}
