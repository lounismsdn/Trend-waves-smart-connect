import { NextRequest } from "next/server";
import { fail, guardRateLimit, handleApiError, ok } from "@/lib/api";
import { getAuthUser } from "@/lib/auth";
import { batchPrepareNfcWrites } from "@/services/nfc";
import { nfcBatchWriteSchema } from "@/lib/validation";

export const runtime = "nodejs";

export async function POST(request: NextRequest) {
  const limited = guardRateLimit(request, "nfc:batch-write", 30);
  if (limited) return limited;

  try {
    const user = await getAuthUser(request);
    if (!user) return fail("Unauthorized", 401);

    const input = nfcBatchWriteSchema.parse(await request.json());
    const progress = await batchPrepareNfcWrites({ user, requestUrl: request.url, input });

    return ok({
      total: progress.length,
      completed: 0,
      pending: progress.length,
      progress,
    });
  } catch (error) {
    return handleApiError(error);
  }
}
