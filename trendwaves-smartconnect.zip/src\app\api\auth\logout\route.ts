import { NextRequest } from "next/server";
import { guardRateLimit, ok } from "@/lib/api";
import { clearSessionCookie } from "@/lib/auth";

export const runtime = "nodejs";

export async function POST(request: NextRequest) {
  const limited = guardRateLimit(request, "auth:logout", 60);
  if (limited) return limited;

  const response = ok({ loggedOut: true });
  clearSessionCookie(response);

  return response;
}
