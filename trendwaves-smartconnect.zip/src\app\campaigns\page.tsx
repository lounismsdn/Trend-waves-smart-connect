import { AppShell } from "@/components/smartconnect/app-shell";
import { CampaignsView } from "@/components/smartconnect/views";
import { requirePageAuth } from "@/lib/server-auth";

export default async function CampaignsPage() {
  await requirePageAuth("/campaigns");

  return (
    <AppShell>
      <CampaignsView />
    </AppShell>
  );
}
