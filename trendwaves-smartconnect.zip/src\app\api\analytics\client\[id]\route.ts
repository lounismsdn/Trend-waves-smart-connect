import { NextRequest } from "next/server";
import { fail, guardRateLimit, handleApiError, ok } from "@/lib/api";
import { getAuthUser } from "@/lib/auth";
import { getClientAnalytics } from "@/lib/analytics";

export const runtime = "nodejs";

type RouteContext = { params: Promise<{ id: string }> };

export async function GET(request: NextRequest, context: RouteContext) {
  const limited = guardRateLimit(request, "analytics:client", 160);
  if (limited) return limited;

  try {
    const user = await getAuthUser(request);
    if (!user) return fail("Unauthorized", 401);

    const { id } = await context.params;
    if (user.role === "CLIENT" && user.clientId && user.clientId !== id) return fail("Forbidden", 403);

    return ok(
      await getClientAnalytics(
        id,
        request.nextUrl.searchParams.get("range"),
        request.nextUrl.searchParams.get("from"),
        request.nextUrl.searchParams.get("to"),
      ),
    );
  } catch (error) {
    return handleApiError(error);
  }
}
