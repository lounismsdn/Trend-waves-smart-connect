import bcrypt from "bcryptjs";
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

const now = new Date();
const daysAgo = (days) => new Date(now.getTime() - days * 24 * 60 * 60 * 1000);

async function main() {
  const passwordHash = await bcrypt.hash("TrendWaves123!", 12);

  await prisma.scanEvent.deleteMany();
  await prisma.auditLog.deleteMany();
  await prisma.notification.deleteMany();
  await prisma.qrCode.deleteMany();
  await prisma.nfcTag.deleteMany();
  await prisma.campaign.deleteMany();
  await prisma.user.deleteMany();
  await prisma.client.deleteMany();

  const maison = await prisma.client.create({
    data: {
      name: "Maison Verve",
      slug: "maison-verve",
      industry: "Hospitality",
      contactName: "Nadia Bell",
      contactEmail: "nadia@maisonverve.example",
      notes: "Premium restaurant group using dynamic menus and NFC table tags.",
    },
  });

  const astra = await prisma.client.create({
    data: {
      name: "Astra Social",
      slug: "astra-social",
      industry: "Creator commerce",
      contactName: "Maya Sol",
      contactEmail: "maya@astrasocial.example",
      notes: "Creator cards, Instagram QR campaigns, and event activations.",
    },
  });

  const northline = await prisma.client.create({
    data: {
      name: "Northline Hotels",
      slug: "northline-hotels",
      industry: "Travel",
      contactName: "Omar Lane",
      contactEmail: "omar@northline.example",
      notes: "Hotel menus, maps, concierge links, and lobby smart posters.",
    },
  });

  await prisma.user.createMany({
    data: [
      {
        email: "admin@trendwaves.app",
        name: "Trend Waves Admin",
        passwordHash,
        role: "ADMIN",
        agencyName: "Trend Waves",
      },
      {
        email: "agency@trendwaves.app",
        name: "Agency Operator",
        passwordHash,
        role: "AGENCY",
        agencyName: "Trend Waves",
      },
      {
        email: "client@maisonverve.example",
        name: "Maison Verve Client",
        passwordHash,
        role: "CLIENT",
        clientId: maison.id,
      },
    ],
  });

  const retailDrop = await prisma.campaign.create({
    data: {
      name: "Retail Drop",
      clientId: astra.id,
      status: "ACTIVE",
      startAt: daysAgo(12),
      endAt: daysAgo(-18),
      notes: "Influencer cards and launch posters.",
    },
  });

  const hotelMenus = await prisma.campaign.create({
    data: {
      name: "Hotel Menus",
      clientId: northline.id,
      status: "ACTIVE",
      startAt: daysAgo(24),
      endAt: daysAgo(-45),
      notes: "Restaurant menus and lobby NFC tags.",
    },
  });

  const lookbook = await prisma.campaign.create({
    data: {
      name: "PDF Lookbook",
      clientId: maison.id,
      status: "PAUSED",
      startAt: daysAgo(6),
      endAt: daysAgo(-28),
      notes: "Awaiting final creative approval.",
    },
  });

  const qrCodes = await Promise.all([
    prisma.qrCode.create({
      data: {
        shortId: "mvmenu24",
        name: "Maison Verve Menu",
        category: "MENU",
        destinationUrl: "https://maisonverve.example/menu/spring",
        clientId: maison.id,
        campaignId: lookbook.id,
        scanCount: 48220,
        uniqueVisitors: 30180,
        lastScanAt: daysAgo(0),
        design: { dark: "#0f172a", accent: "#67e8f9", frame: "Scan to connect" },
      },
    }),
    prisma.qrCode.create({
      data: {
        shortId: "astraig",
        name: "Creator Instagram Card",
        category: "INSTAGRAM_SOCIAL",
        destinationUrl: "https://instagram.com/astra.studio",
        clientId: astra.id,
        campaignId: retailDrop.id,
        scanCount: 23140,
        uniqueVisitors: 17800,
        lastScanAt: daysAgo(0),
        design: { dark: "#111827", accent: "#34d399", frame: "Follow the drop" },
      },
    }),
    prisma.qrCode.create({
      data: {
        shortId: "nlmaps",
        name: "Property Maps Launcher",
        category: "GOOGLE_MAPS",
        destinationUrl: "https://maps.google.com/?q=northline",
        status: "PAUSED",
        clientId: northline.id,
        campaignId: hotelMenus.id,
        scanCount: 17420,
        uniqueVisitors: 12110,
        lastScanAt: daysAgo(1),
      },
    }),
  ]);

  const nfcTags = await Promise.all([
    prisma.nfcTag.create({
      data: {
        shortId: "vip12tap",
        chipUid: "04:A2:19:7F:11:8B",
        name: "VIP Table 12",
        destinationUrl: "https://trendwaves.app/r/mvmenu24",
        clientId: maison.id,
        campaignId: lookbook.id,
        tapCount: 8410,
        uniqueVisitors: 6210,
        lastTapAt: daysAgo(0),
      },
    }),
    prisma.nfcTag.create({
      data: {
        shortId: "lobbynl",
        chipUid: "04:B8:22:9C:45:10",
        name: "Lobby Smart Poster",
        destinationUrl: "https://trendwaves.app/r/nlmaps",
        clientId: northline.id,
        campaignId: hotelMenus.id,
        tapCount: 12440,
        uniqueVisitors: 8020,
        lastTapAt: daysAgo(0),
      },
    }),
  ]);

  const countries = [
    ["AE", "Dubai"],
    ["DZ", "Algiers"],
    ["FR", "Paris"],
    ["GB", "London"],
    ["QA", "Doha"],
  ];
  const devices = ["mobile", "desktop", "tablet"];
  const browsers = ["Chrome", "Safari", "Edge", "Firefox"];

  const events = Array.from({ length: 120 }).map((_, index) => {
    const isQr = index % 3 !== 0;
    const asset = isQr ? qrCodes[index % qrCodes.length] : nfcTags[index % nfcTags.length];
    const [country, city] = countries[index % countries.length];

    return {
      kind: isQr ? "QR" : "NFC",
      shortId: asset.shortId,
      visitorId: `visitor_${index % 62}`,
      ipHash: `seed_hash_${index % 48}`,
      deviceType: devices[index % devices.length],
      browser: browsers[index % browsers.length],
      country,
      city,
      referrer: index % 4 === 0 ? "https://instagram.com" : "direct",
      userAgent: "Seeded SmartConnect event",
      converted: index % 7 === 0,
      qrCodeId: isQr ? asset.id : null,
      nfcTagId: isQr ? null : asset.id,
      campaignId: asset.campaignId,
      clientId: asset.clientId,
      createdAt: daysAgo(index % 30),
    };
  });

  await prisma.scanEvent.createMany({ data: events });

  await prisma.notification.createMany({
    data: [
      {
        title: "Scan spike detected",
        message: "Retail Drop is trending 42% above the normal Friday baseline.",
        severity: "success",
      },
      {
        title: "Broken destination check",
        message: "Three QR destinations should be reviewed for SSL health.",
        severity: "warning",
      },
      {
        title: "Campaign expiration",
        message: "Maison Verve campaign expires soon.",
        severity: "info",
      },
    ],
  });

  console.log("Seed complete.");
  console.log("Admin login: admin@trendwaves.app / TrendWaves123!");
}

main()
  .catch((error) => {
    console.error(error);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
