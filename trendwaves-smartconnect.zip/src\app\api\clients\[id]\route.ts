import { NextRequest } from "next/server";
import { Prisma } from "@prisma/client";
import { fail, guardRateLimit, handleApiError, ok } from "@/lib/api";
import { getAuthUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { clientUpdateSchema } from "@/lib/validation";

export const runtime = "nodejs";

type RouteContext = { params: Promise<{ id: string }> };

export async function GET(request: NextRequest, context: RouteContext) {
  const limited = guardRateLimit(request, "clients:get", 240);
  if (limited) return limited;

  try {
    const user = await getAuthUser(request);
    if (!user) return fail("Unauthorized", 401);

    const { id } = await context.params;
    const client = await prisma.client.findUnique({
      where: { id },
      include: { users: true, campaigns: true, qrCodes: true, nfcTags: true },
    });

    if (!client) return fail("Client not found", 404);
    return ok(client);
  } catch (error) {
    return handleApiError(error);
  }
}

export async function PUT(request: NextRequest, context: RouteContext) {
  const limited = guardRateLimit(request, "clients:update", 120);
  if (limited) return limited;

  try {
    const user = await getAuthUser(request);
    if (!user) return fail("Unauthorized", 401);

    const { id } = await context.params;
    const input = clientUpdateSchema.parse(await request.json());
    const client = await prisma.client.update({
      where: { id },
      data: {
        ...input,
        branding: input.branding as Prisma.InputJsonValue | undefined,
        permissions: input.permissions as Prisma.InputJsonValue | undefined,
        settings: input.settings as Prisma.InputJsonValue | undefined,
      },
    });

    await prisma.auditLog.create({
      data: {
        actorId: user.sub,
        action: "CLIENT_UPDATED",
        entity: "Client",
        entityId: id,
        metadata: input as Prisma.InputJsonValue,
      },
    });

    return ok(client);
  } catch (error) {
    return handleApiError(error);
  }
}

export async function DELETE(request: NextRequest, context: RouteContext) {
  const limited = guardRateLimit(request, "clients:delete", 60);
  if (limited) return limited;

  try {
    const user = await getAuthUser(request);
    if (!user) return fail("Unauthorized", 401);

    const { id } = await context.params;
    await prisma.client.delete({ where: { id } });

    await prisma.auditLog.create({
      data: {
        actorId: user.sub,
        action: "CLIENT_DELETED",
        entity: "Client",
        entityId: id,
      },
    });

    return ok({ deleted: true });
  } catch (error) {
    return handleApiError(error);
  }
}
