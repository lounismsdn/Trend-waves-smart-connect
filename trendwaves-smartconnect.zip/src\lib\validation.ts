import { z } from "zod";

export const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8),
});

export const registerSchema = loginSchema.extend({
  name: z.string().min(2),
  role: z.enum(["ADMIN", "AGENCY", "CLIENT"]).default("AGENCY"),
  agencyName: z.string().optional(),
  clientId: z.string().optional(),
});

export const qrSchema = z.object({
  name: z.string().min(2),
  category: z.enum([
    "WEBSITE",
    "MENU",
    "INSTAGRAM_SOCIAL",
    "WHATSAPP",
    "PDF",
    "GOOGLE_MAPS",
    "CUSTOM_LANDING_PAGE",
  ]),
  destinationUrl: z.string().url(),
  clientId: z.string().optional(),
  campaignId: z.string().optional(),
  design: z.record(z.string(), z.unknown()).optional(),
});

export const qrUpdateSchema = qrSchema.partial().extend({
  status: z.enum(["ACTIVE", "PAUSED", "ARCHIVED", "EXPIRED"]).optional(),
});

export const qrStyleSchema = z.object({
  design: z.record(z.string(), z.unknown()),
  changes: z.record(z.string(), z.unknown()).optional(),
});

export const qrStylePresetSchema = z.object({
  name: z.string().min(2),
  description: z.string().optional(),
  clientId: z.string().optional(),
  design: z.record(z.string(), z.unknown()),
  isSystem: z.boolean().optional(),
});

export const qrBulkStyleSchema = z.object({
  qrCodeIds: z.array(z.string()).min(1),
  design: z.record(z.string(), z.unknown()),
  changes: z.record(z.string(), z.unknown()).optional(),
});

export const qrRollbackSchema = z.object({
  version: z.number().int().positive(),
});

export const nfcRegisterSchema = z.object({
  chipUid: z.string().min(4),
  name: z.string().min(2),
  destinationUrl: z.string().url(),
  clientId: z.string().optional(),
  campaignId: z.string().optional(),
  tagType: z.enum(["NTAG213", "NTAG215", "NTAG216", "MIFARE_ULTRALIGHT", "UNKNOWN"]).optional(),
  memorySize: z.number().int().positive().optional(),
  isWritable: z.boolean().optional(),
});

export const nfcUpdateSchema = nfcRegisterSchema.partial().extend({
  status: z.enum(["ACTIVE", "PAUSED", "ARCHIVED", "EXPIRED"]).optional(),
  isLocked: z.boolean().optional(),
  operationalStatus: z.enum(["UNREGISTERED", "REGISTERED", "WRITABLE", "WRITTEN", "VERIFIED", "LOCKED", "INACTIVE", "ERROR"]).optional(),
});

export const nfcWriteSchema = z.object({
  tagId: z.string().optional(),
  chipUid: z.string().optional(),
  destinationUrl: z.string().url().optional(),
  directWrite: z.boolean().optional(),
  payload: z.string().url().optional(),
}).refine((value) => value.tagId || value.chipUid, {
  message: "tagId or chipUid is required",
});

export const nfcWriteConfirmSchema = z.object({
  writeLogId: z.string(),
  success: z.boolean(),
  payload: z.string().optional(),
  errorMessage: z.string().optional(),
});

export const nfcVerifySchema = z.object({
  tagId: z.string().optional(),
  chipUid: z.string().optional(),
  payload: z.string().url(),
}).refine((value) => value.tagId || value.chipUid, {
  message: "tagId or chipUid is required",
});

export const nfcLockSchema = z.object({
  confirm: z.literal(true),
});

export const nfcBatchWriteSchema = z.object({
  clientId: z.string().optional(),
  campaignId: z.string().optional(),
  destinationUrl: z.string().url(),
  tags: z.array(z.object({
    chipUid: z.string().min(4),
    name: z.string().min(2).optional(),
    tagType: z.enum(["NTAG213", "NTAG215", "NTAG216", "MIFARE_ULTRALIGHT", "UNKNOWN"]).optional(),
    memorySize: z.number().int().positive().optional(),
  })).min(1),
});

export const campaignSchema = z.object({
  name: z.string().min(2),
  clientId: z.string(),
  status: z.enum(["PLANNED", "ACTIVE", "PAUSED", "COMPLETED", "EXPIRED"]).default("PLANNED"),
  startAt: z.string().datetime().optional(),
  endAt: z.string().datetime().optional(),
  notes: z.string().optional(),
});

export const campaignUpdateSchema = campaignSchema.partial();

export const clientSchema = z.object({
  name: z.string().min(2),
  slug: z.string().min(2).regex(/^[a-z0-9-]+$/),
  industry: z.string().optional(),
  contactName: z.string().optional(),
  contactEmail: z.string().email().optional(),
  notes: z.string().optional(),
  brandColor: z.string().optional(),
  logoUrl: z.string().url().optional(),
  branding: z.record(z.string(), z.unknown()).optional(),
  permissions: z.record(z.string(), z.unknown()).optional(),
  settings: z.record(z.string(), z.unknown()).optional(),
});

export const clientUpdateSchema = clientSchema.partial();
