import { AppShell } from "@/components/smartconnect/app-shell";
import { QRAnalyticsDetailView } from "@/components/smartconnect/qr-analytics-page";
import { requirePageAuth } from "@/lib/server-auth";

type PageProps = { params: Promise<{ id: string }> };

export default async function QRAnalyticsPage({ params }: PageProps) {
  const { id } = await params;
  await requirePageAuth(`/qr/${id}/analytics`);

  return (
    <AppShell>
      <QRAnalyticsDetailView id={id} />
    </AppShell>
  );
}
