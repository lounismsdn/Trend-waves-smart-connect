import { NextRequest } from "next/server";
import { Prisma } from "@prisma/client";
import { fail, guardRateLimit, handleApiError, ok, parseBody } from "@/lib/api";
import { getAuthUser, signRedirect } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { createShortId } from "@/lib/qr";
import { checksumDesign } from "@/lib/qr-style";
import { qrSchema } from "@/lib/validation";

export const runtime = "nodejs";

export async function POST(request: NextRequest) {
  const limited = guardRateLimit(request, "qr:create", 80);
  if (limited) return limited;

  try {
    const user = await getAuthUser(request);
    if (!user) return fail("Unauthorized", 401);

    const input = await parseBody(request, qrSchema);
    let shortId = createShortId();

    while (await prisma.qrCode.findUnique({ where: { shortId } })) {
      shortId = createShortId();
    }

    const design = input.design as Prisma.InputJsonValue | undefined;
    const qrCode = await prisma.qrCode.create({
      data: {
        shortId,
        name: input.name,
        category: input.category,
        destinationUrl: input.destinationUrl,
        clientId: input.clientId ?? user.clientId ?? undefined,
        campaignId: input.campaignId,
        design,
        designChecksum: design ? checksumDesign(design) : undefined,
        designVersions: design
          ? {
              create: {
                version: 1,
                design,
                changes: { created: true } as Prisma.InputJsonValue,
                editorId: user.sub,
              },
            }
          : undefined,
      },
      include: {
        client: { select: { id: true, name: true, slug: true } },
        campaign: { select: { id: true, name: true, status: true } },
      },
    });

    const signature = await signRedirect(shortId);
    const origin = process.env.APP_URL ?? new URL(request.url).origin;

    await prisma.auditLog.create({
      data: {
        actorId: user.sub,
        action: "QR_CREATED",
        entity: "QrCode",
        entityId: qrCode.id,
        metadata: { shortId, category: input.category },
      },
    });

    return ok(
      {
        ...qrCode,
        shortUrl: `${origin}/r/${shortId}?s=${signature}`,
      },
      { status: 201 },
    );
  } catch (error) {
    return handleApiError(error);
  }
}
