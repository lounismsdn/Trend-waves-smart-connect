import { NextRequest } from "next/server";
import { Prisma } from "@prisma/client";
import { fail, guardRateLimit, handleApiError, ok } from "@/lib/api";
import { getAuthUser, signRedirect } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { createShortId } from "@/lib/qr";

export const runtime = "nodejs";

type RouteContext = { params: Promise<{ id: string }> };

export async function POST(request: NextRequest, context: RouteContext) {
  const limited = guardRateLimit(request, "qr:duplicate", 80);
  if (limited) return limited;

  try {
    const user = await getAuthUser(request);
    if (!user) return fail("Unauthorized", 401);

    const { id } = await context.params;
    const source = await prisma.qrCode.findUnique({ where: { id }, include: { client: true, campaign: true } });
    if (!source) return fail("QR code not found", 404);
    if (user.role === "CLIENT" && user.clientId && source.clientId !== user.clientId) return fail("Forbidden", 403);

    let shortId = createShortId();
    while (await prisma.qrCode.findUnique({ where: { shortId } })) {
      shortId = createShortId();
    }

    const copy = await prisma.qrCode.create({
      data: {
        shortId,
        name: `${source.name} copy`,
        category: source.category,
        destinationUrl: source.destinationUrl,
        status: "ACTIVE",
        design: source.design as Prisma.InputJsonValue | undefined,
        designChecksum: source.designChecksum,
        designVersion: source.designVersion,
        clientId: source.clientId,
        campaignId: source.campaignId,
        stylePresetId: source.stylePresetId,
        designVersions: source.design
          ? {
              create: {
                version: 1,
                design: source.design as Prisma.InputJsonValue,
                changes: { duplicatedFrom: source.id } as Prisma.InputJsonValue,
                editorId: user.sub,
              },
            }
          : undefined,
      },
      include: {
        client: { select: { id: true, name: true, slug: true } },
        campaign: { select: { id: true, name: true, status: true } },
      },
    });

    await prisma.auditLog.create({
      data: {
        actorId: user.sub,
        action: "QR_DUPLICATED",
        entity: "QrCode",
        entityId: copy.id,
        metadata: { duplicatedFrom: source.id, shortId } as Prisma.InputJsonValue,
      },
    });

    const signature = await signRedirect(shortId);
    const origin = process.env.APP_URL ?? new URL(request.url).origin;

    return ok({ ...copy, shortUrl: `${origin}/r/${shortId}?s=${signature}` }, { status: 201 });
  } catch (error) {
    return handleApiError(error);
  }
}
