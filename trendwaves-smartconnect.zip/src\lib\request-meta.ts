import { createHash } from "crypto";
import type { NextRequest } from "next/server";
import { UAParser } from "ua-parser-js";
import { getIp } from "@/lib/api";

export function hashIp(ip: string) {
  return createHash("sha256")
    .update(`${ip}:${process.env.JWT_SECRET ?? "trendwaves-dev-secret-change-me"}`)
    .digest("hex");
}

export function extractScanMetadata(request: NextRequest) {
  const ip = getIp(request);
  const userAgent = request.headers.get("user-agent") ?? "";
  const parsed = new UAParser(userAgent).getResult();

  return {
    ip,
    ipHash: hashIp(ip),
    userAgent,
    referrer: request.headers.get("referer"),
    deviceType: parsed.device.type ?? "desktop",
    browser: parsed.browser.name ?? "Unknown",
    country:
      request.headers.get("x-vercel-ip-country") ??
      request.headers.get("cf-ipcountry") ??
      "Unknown",
    city: request.headers.get("x-vercel-ip-city") ?? "Unknown",
  };
}
