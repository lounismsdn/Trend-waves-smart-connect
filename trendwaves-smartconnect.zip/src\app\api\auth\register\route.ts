import { NextRequest } from "next/server";
import { guardRateLimit, handleApiError, ok, parseBody } from "@/lib/api";
import { hashPassword, setSessionCookie, signAccessToken } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { registerSchema } from "@/lib/validation";

export const runtime = "nodejs";

export async function POST(request: NextRequest) {
  const limited = guardRateLimit(request, "auth:register", 10);
  if (limited) return limited;

  try {
    const input = await parseBody(request, registerSchema);
    const passwordHash = await hashPassword(input.password);

    const user = await prisma.user.create({
      data: {
        email: input.email,
        name: input.name,
        passwordHash,
        role: input.role,
        agencyName: input.agencyName,
        clientId: input.clientId,
      },
    });

    const token = await signAccessToken({
      sub: user.id,
      email: user.email,
      role: user.role,
      clientId: user.clientId,
    });

    const response = ok(
      {
        token,
        user: {
          id: user.id,
          email: user.email,
          name: user.name,
          role: user.role,
          clientId: user.clientId,
        },
      },
      { status: 201 },
    );
    setSessionCookie(response, token);

    return response;
  } catch (error) {
    return handleApiError(error);
  }
}
