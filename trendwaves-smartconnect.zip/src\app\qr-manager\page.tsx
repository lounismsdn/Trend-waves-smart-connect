import { AppShell } from "@/components/smartconnect/app-shell";
import { QRManagerView } from "@/components/smartconnect/views";
import { requirePageAuth } from "@/lib/server-auth";

export default async function QRManagerPage() {
  await requirePageAuth("/qr-manager");

  return (
    <AppShell>
      <QRManagerView />
    </AppShell>
  );
}
