import bcrypt from "bcryptjs";
import { SignJWT, jwtVerify } from "jose";
import type { NextRequest, NextResponse } from "next/server";

type TokenPayload = {
  sub: string;
  email: string;
  role: "ADMIN" | "AGENCY" | "CLIENT";
  clientId?: string | null;
};

const secret = new TextEncoder().encode(process.env.JWT_SECRET ?? "trendwaves-dev-secret-change-me");
export const AUTH_COOKIE_NAME = "tw_session";
export const AUTH_COOKIE_MAX_AGE = 60 * 60 * 12;

export async function hashPassword(password: string) {
  return bcrypt.hash(password, 12);
}

export async function verifyPassword(password: string, hash: string) {
  return bcrypt.compare(password, hash);
}

export async function signAccessToken(payload: TokenPayload) {
  return new SignJWT({ email: payload.email, role: payload.role, clientId: payload.clientId ?? null })
    .setProtectedHeader({ alg: "HS256" })
    .setSubject(payload.sub)
    .setIssuedAt()
    .setExpirationTime("12h")
    .sign(secret);
}

export async function verifyAccessToken(token: string) {
  const { payload } = await jwtVerify(token, secret);

  return {
    sub: String(payload.sub),
    email: String(payload.email),
    role: payload.role as TokenPayload["role"],
    clientId: payload.clientId ? String(payload.clientId) : null,
  };
}

export function getBearerToken(request: NextRequest) {
  const header = request.headers.get("authorization");
  if (header?.startsWith("Bearer ")) {
    return header.slice("Bearer ".length);
  }

  return request.cookies.get(AUTH_COOKIE_NAME)?.value ?? null;
}

export async function getAuthUser(request: NextRequest) {
  const token = getBearerToken(request);
  if (!token) {
    return null;
  }

  try {
    return await verifyAccessToken(token);
  } catch {
    return null;
  }
}

export function setSessionCookie(response: NextResponse, token: string) {
  response.cookies.set(AUTH_COOKIE_NAME, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: AUTH_COOKIE_MAX_AGE,
  });
}

export function clearSessionCookie(response: NextResponse) {
  response.cookies.set(AUTH_COOKIE_NAME, "", {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: 0,
  });
}

export async function signRedirect(shortId: string) {
  return new SignJWT({ shortId })
    .setProtectedHeader({ alg: "HS256" })
    .setSubject(shortId)
    .setIssuedAt()
    .setExpirationTime("365d")
    .sign(secret);
}

export async function verifyRedirectSignature(shortId: string, signature: string | null) {
  if (!signature) {
    return false;
  }

  try {
    const { payload } = await jwtVerify(signature, secret);
    return payload.sub === shortId || payload.shortId === shortId;
  } catch {
    return false;
  }
}
