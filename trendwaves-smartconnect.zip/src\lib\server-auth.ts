import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { AUTH_COOKIE_NAME, verifyAccessToken } from "@/lib/auth";

export async function requirePageAuth(nextPath: string) {
  const cookieStore = await cookies();
  const token = cookieStore.get(AUTH_COOKIE_NAME)?.value;

  if (!token) {
    redirect(`/login?next=${encodeURIComponent(nextPath)}`);
  }

  try {
    return await verifyAccessToken(token);
  } catch {
    redirect(`/login?next=${encodeURIComponent(nextPath)}`);
  }
}
