import { subDays, subMonths } from "date-fns";
import { prisma } from "@/lib/prisma";

export type AnalyticsRange = "today" | "7d" | "30d" | "month";

export function rangeToDates(range: string | null, fromParam?: string | null, toParam?: string | null) {
  const now = new Date();
  if (range === "custom" && fromParam && toParam) {
    const from = new Date(fromParam);
    const to = new Date(toParam);
    if (!Number.isNaN(from.valueOf()) && !Number.isNaN(to.valueOf())) {
      to.setHours(23, 59, 59, 999);
      return { from, to };
    }
  }
  if (range === "today") return { from: subDays(now, 1), to: now };
  if (range === "7d") return { from: subDays(now, 7), to: now };
  if (range === "month") return { from: subMonths(now, 1), to: now };
  return { from: subDays(now, 30), to: now };
}

export function bucketByDay(events: Array<{ createdAt: Date; visitorId: string | null }>) {
  const buckets = new Map<string, { date: string; scans: number; unique: Set<string> }>();

  for (const event of events) {
    const date = event.createdAt.toISOString().slice(0, 10);
    const current = buckets.get(date) ?? { date, scans: 0, unique: new Set<string>() };
    current.scans += 1;
    if (event.visitorId) current.unique.add(event.visitorId);
    buckets.set(date, current);
  }

  return Array.from(buckets.values())
    .sort((a, b) => a.date.localeCompare(b.date))
    .map((bucket) => ({ date: bucket.date.slice(5), scans: bucket.scans, unique: bucket.unique.size || bucket.scans }));
}

export function countBy<T extends string | null | undefined>(values: T[], fallback: string) {
  const counts = new Map<string, number>();

  for (const value of values) {
    const key = value || fallback;
    counts.set(key, (counts.get(key) ?? 0) + 1);
  }

  return Array.from(counts, ([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value);
}

export function bucketWeekly(days: Array<{ date: string; scans: number; unique: number }>) {
  return days.reduce<Array<{ week: string; scans: number; unique: number }>>((weeks, day, index) => {
    const label = `W${Math.floor(index / 7) + 1}`;
    const current = weeks.find((week) => week.week === label);
    if (current) {
      current.scans += day.scans;
      current.unique += day.unique;
    } else {
      weeks.push({ week: label, scans: day.scans, unique: day.unique });
    }
    return weeks;
  }, []);
}

export async function getClientAnalytics(clientId: string, range: string | null, fromParam?: string | null, toParam?: string | null) {
  const { from, to } = rangeToDates(range, fromParam, toParam);
  const where = { clientId, createdAt: { gte: from, lte: to } };

  const [client, qrAssets, nfcTags, campaigns, events, conversions] = await Promise.all([
    prisma.client.findUnique({ where: { id: clientId } }),
    prisma.qrCode.findMany({ where: { clientId }, include: { client: true, campaign: true }, orderBy: { updatedAt: "desc" } }),
    prisma.nfcTag.findMany({ where: { clientId }, include: { client: true, campaign: true }, orderBy: { updatedAt: "desc" } }),
    prisma.campaign.findMany({ where: { clientId }, include: { qrCodes: true, nfcTags: true }, orderBy: { updatedAt: "desc" } }),
    prisma.scanEvent.findMany({ where, orderBy: { createdAt: "desc" }, take: 1000 }),
    prisma.scanEvent.count({ where: { ...where, converted: true } }),
  ]);

  const dailyScans = bucketByDay(events).slice(-30);
  const qrEvents = events.filter((event) => event.kind === "QR");
  const nfcEvents = events.filter((event) => event.kind === "NFC");

  return {
    client,
    totals: {
      scans: events.length,
      unique: new Set(events.map((event) => event.visitorId).filter(Boolean)).size,
      qrScans: qrEvents.length,
      nfcTaps: nfcEvents.length,
      activeQrAssets: qrAssets.filter((asset) => asset.status === "ACTIVE").length,
      activeNfcTags: nfcTags.filter((tag) => tag.status === "ACTIVE").length,
      activeCampaigns: campaigns.filter((campaign) => campaign.status === "ACTIVE").length,
      conversions,
      conversionRate: events.length ? Math.round((conversions / events.length) * 1000) / 10 : 0,
    },
    dailyScans,
    weeklyTrends: bucketWeekly(dailyScans),
    monthlyPerformance: dailyScans.map((day, index) => ({ ...day, month: `M${Math.floor(index / 10) + 1}` })),
    devices: countBy(events.map((event) => event.deviceType), "Unknown device"),
    locations: countBy(events.map((event) => [event.city, event.country].filter(Boolean).join(", ")), "Unknown location"),
    browsers: countBy(events.map((event) => event.browser), "Unknown browser"),
    sources: countBy(events.map((event) => event.referrer), "Direct"),
    recentScans: events.slice(0, 25),
    assets: [
      ...qrAssets.map((asset) => ({ kind: "QR" as const, ...asset })),
      ...nfcTags.map((tag) => ({ kind: "NFC" as const, ...tag })),
    ],
    campaigns,
  };
}
