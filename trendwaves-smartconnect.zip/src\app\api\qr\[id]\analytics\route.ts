import { NextRequest } from "next/server";
import { fail, guardRateLimit, handleApiError, ok } from "@/lib/api";
import { getAuthUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export const runtime = "nodejs";

type RouteContext = { params: Promise<{ id: string }> };

function bucketByDay(events: Array<{ createdAt: Date; visitorId: string | null }>) {
  const buckets = new Map<string, { date: string; scans: number; unique: Set<string> }>();

  for (const event of events) {
    const date = event.createdAt.toISOString().slice(0, 10);
    const current = buckets.get(date) ?? { date, scans: 0, unique: new Set<string>() };
    current.scans += 1;
    if (event.visitorId) current.unique.add(event.visitorId);
    buckets.set(date, current);
  }

  return Array.from(buckets.values())
    .sort((a, b) => a.date.localeCompare(b.date))
    .map((bucket) => ({ date: bucket.date.slice(5), scans: bucket.scans, unique: bucket.unique.size || bucket.scans }));
}

function countBy<T extends string | null | undefined>(values: T[], fallback: string) {
  const counts = new Map<string, number>();
  for (const value of values) {
    const key = value || fallback;
    counts.set(key, (counts.get(key) ?? 0) + 1);
  }
  return Array.from(counts, ([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value);
}

export async function GET(request: NextRequest, context: RouteContext) {
  const limited = guardRateLimit(request, "qr:analytics", 160);
  if (limited) return limited;

  try {
    const user = await getAuthUser(request);
    if (!user) return fail("Unauthorized", 401);

    const { id } = await context.params;
    const qrCode = await prisma.qrCode.findUnique({
      where: { id },
      include: { client: true, campaign: true },
    });

    if (!qrCode) return fail("QR code not found", 404);
    if (user.role === "CLIENT" && user.clientId && qrCode.clientId !== user.clientId) {
      return fail("Forbidden", 403);
    }

    const events = await prisma.scanEvent.findMany({
      where: { qrCodeId: id },
      orderBy: { createdAt: "desc" },
      take: 500,
    });

    const dailyScans = bucketByDay(events).slice(-30);
    const weeklyTrends = bucketByDay(events).reduce<Array<{ week: string; scans: number; unique: number }>>((weeks, day, index) => {
      const weekIndex = Math.floor(index / 7) + 1;
      const label = `W${weekIndex}`;
      const current = weeks.find((item) => item.week === label);
      if (current) {
        current.scans += day.scans;
        current.unique += day.unique;
      } else {
        weeks.push({ week: label, scans: day.scans, unique: day.unique });
      }
      return weeks;
    }, []);

    const recentScans = events.slice(0, 20).map((event) => ({
      id: event.id,
      timestamp: event.createdAt,
      city: event.city ?? "Unknown",
      country: event.country ?? "Unknown",
      device: event.deviceType ?? "Unknown",
      browser: event.browser ?? "Unknown",
      referrer: event.referrer ?? "Direct",
      converted: event.converted,
    }));

    return ok({
      asset: qrCode,
      totals: {
        scans: qrCode.scanCount,
        unique: qrCode.uniqueVisitors,
        lastScanAt: qrCode.lastScanAt,
      },
      dailyScans,
      weeklyTrends,
      devices: countBy(events.map((event) => event.deviceType), "Unknown device"),
      locations: countBy(events.map((event) => [event.city, event.country].filter(Boolean).join(", ")), "Unknown location"),
      browsers: countBy(events.map((event) => event.browser), "Unknown browser"),
      sources: countBy(events.map((event) => event.referrer), "Direct"),
      recentScans,
    });
  } catch (error) {
    return handleApiError(error);
  }
}
