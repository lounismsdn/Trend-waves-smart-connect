import { AppShell } from "@/components/smartconnect/app-shell";
import { DashboardView } from "@/components/smartconnect/views";
import { requirePageAuth } from "@/lib/server-auth";

export default async function DashboardPage() {
  await requirePageAuth("/dashboard");

  return (
    <AppShell>
      <DashboardView />
    </AppShell>
  );
}
