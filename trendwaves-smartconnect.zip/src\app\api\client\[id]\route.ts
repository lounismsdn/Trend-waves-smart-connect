export { GET, PUT } from "@/app/api/clients/[id]/route";
