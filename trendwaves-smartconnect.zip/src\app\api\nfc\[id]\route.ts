import { NextRequest } from "next/server";
import { fail, guardRateLimit, handleApiError, ok } from "@/lib/api";
import { getAuthUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { signedNfcRedirectUrl } from "@/services/nfc";

export const runtime = "nodejs";

type RouteContext = { params: Promise<{ id: string }> };

export async function GET(request: NextRequest, context: RouteContext) {
  const limited = guardRateLimit(request, "nfc:get", 240);
  if (limited) return limited;

  try {
    const user = await getAuthUser(request);
    if (!user) return fail("Unauthorized", 401);

    const { id } = await context.params;
    const nfcTag = await prisma.nfcTag.findUnique({
      where: { id },
      include: { client: true, campaign: true, writeLogs: { orderBy: { createdAt: "desc" }, take: 20 } },
    });

    if (!nfcTag) return fail("NFC tag not found", 404);

    return ok({ ...nfcTag, shortUrl: await signedNfcRedirectUrl(nfcTag.shortId, request.url) });
  } catch (error) {
    return handleApiError(error);
  }
}

export async function DELETE(request: NextRequest, context: RouteContext) {
  const limited = guardRateLimit(request, "nfc:delete", 60);
  if (limited) return limited;

  try {
    const user = await getAuthUser(request);
    if (!user) return fail("Unauthorized", 401);

    const { id } = await context.params;
    const where =
      user.role === "CLIENT" && user.clientId
        ? { id, clientId: user.clientId }
        : { id };

    const deleted = await prisma.nfcTag.deleteMany({ where });
    if (deleted.count === 0) return ok({ deleted: false, missing: true });

    await prisma.auditLog.create({
      data: {
        actorId: user.sub,
        action: "NFC_DELETED",
        entity: "NfcTag",
        entityId: id,
      },
    });

    return ok({ deleted: true, missing: false });
  } catch (error) {
    return handleApiError(error);
  }
}
